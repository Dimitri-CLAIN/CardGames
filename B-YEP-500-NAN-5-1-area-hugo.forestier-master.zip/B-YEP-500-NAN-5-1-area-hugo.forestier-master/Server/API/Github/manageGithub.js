const axios = require('axios');
const qs = require('querystring');

exports.auth = function(req, response) {
    console.log(req.body.code);
    const rqBody = {
        code: req.body.code,
        client_id: "80b5848ec7a4c1a8e63a",
        client_secret: "b240c0cdb750e0f6183a3023ce123f1608792b8d", //TODO mettre dans l'env
        redirect_uri: "http://localhost:8081/",
    }
    axios.post("https://github.com/login/oauth/access_token", qs.stringify(rqBody))
    .then(res => {
        var returnValue = res.data.split('=')[1].split('&')[0]
        response.send(returnValue);
    }).catch(e => {
        res.statusCode = 400;
        console.log(e)
        res.send(e)
    });
}