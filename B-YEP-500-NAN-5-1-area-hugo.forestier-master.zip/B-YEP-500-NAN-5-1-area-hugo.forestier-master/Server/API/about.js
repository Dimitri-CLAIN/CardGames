const fetch = require("node-fetch");

exports.getAbout = function(request, response) {
    const date = new Date().getTime()
    const aboutJson = {
        client: {"host": '127.0.0.1'},
        server: {
            current_time: date,
            services: [
                {
                    name: "Trello",
                    actions: [{
                            name: "createCard",
                            description : "A new card is created"
                        }, {
                            name: "addMemberToCard",
                            description: "A new member is added on a card"
                        }, {
                            name: "updateCard",
                            description: "An update on a card"
                        }, {
                            name: "RemoveMemberFromBoard",
                            description: "A Member is removed from a board"
                        }, {
                            name: "addMemberToBoard",
                            description: "A Member is added from a board"
                        }
                    ],
                    reactions : [{
                            name: "createChecklist",
                            description: "Create a new checklist"
                        }, {
                            name: "addComment",
                            description: "Add a comment to a board/card"   
                        }, {
                            name: "addMember",
                            description: "Add a member to a board/card"
                    }]
                }, {
                    name: "Gmail",
                    actions: [
                    ],
                    reactions: [{
                            name: "sendMail",
                            description: "Send to mail to someone"
                    }],
                }, {
                    name: "Github",
                    actions: [ 
                    ],
                    reactions: [{
                            name: "updateIssue",
                            description: "Update an Issue"
                        }, {
                            name: "updatePullRequest",
                            description: "Update a pull Request"
                        }, {
                            name: "commentIssue",
                            description: "Add a comment on a issue"
                        }
                    ],
                }, {
                    name: "Twitter",
                    actions: [
                    ],
                    reactions: [{
                            name: "Tweet",
                            description: "Tweet on your account"
                    }]
                }
            ]
        }
    };
    response.status(200).json(aboutJson);
}
