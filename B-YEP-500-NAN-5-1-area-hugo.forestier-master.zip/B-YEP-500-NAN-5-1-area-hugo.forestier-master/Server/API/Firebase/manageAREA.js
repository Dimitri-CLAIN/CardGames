var admin = require("firebase");

exports.getActions = function(req, res) {
    var db = admin.database();
    var ref = db.ref("/data_area");
    refChild = ref.child("actions");
    refChild.once("value", function(snapshot) {
        var data = snapshot.val();
        res.status(200).json(data);
    });
}

exports.getREactionsFromAction = function(req, res) {
    var db = admin.database();
    var ref = db.ref("/data_area");
    refChild = ref.child(`actions/0/${req.params.action}/compatibleReaction`);
    refChild.once("value", function(snapshot) {
        var data = snapshot.val();
        res.status(200).json(data);
    });
}

exports.getREactions = function(req, res) {
    var db = admin.database();
    var ref = db.ref("/data_area");
    refChild = ref.child("reactions");
    refChild.once("value", function(snapshot) {
        var data = snapshot.val();
        res.status(200).json(data);
    });
}

exports.getConfiguration = function(req, res) {
    var db = admin.database();
    var ref = db.ref("/data_area");
    refChild = ref.child("actions");
    refChild.once("value", function(snapshot) {
        var data = snapshot.val();
        res.status(200).json(data[0][req.params.action].neededConfig);
    });
}