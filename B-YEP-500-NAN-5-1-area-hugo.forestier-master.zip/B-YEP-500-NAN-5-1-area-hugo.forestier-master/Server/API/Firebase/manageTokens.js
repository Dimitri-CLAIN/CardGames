var admin = require("firebase");
const axios = require('axios');

var firebaseConfig = {
    apiKey: process.env.API_KEY,
    authDomain: process.env.AUTH_DOMAIN,
    databaseURL: process.env.DATABASE_URL,
    projectId: process.env.PROJECT_ID,
    storageBucket: process.env.STORAGE_BUCKET,
    messagingSenderId: process.env.MESSAGING_SENDER_ID,
    appId: process.env.APP_ID,
    measurementId: process.env.MEASUREMENT_ID
};

admin.initializeApp(firebaseConfig);

exports.addToken = function(req, res) {
    var db = admin.database();
    var ref = db.ref("/user_data/");
    var clientSecret = "";
    var id = "";
    var refTmpChild = ref.child("tokens/" + req.params.id);
    refChild = refTmpChild.push();
    if (req.body.clientSecret) {
        clientSecret = req.body.clientSecret;
    }
    refChild.set([
        {
            Type: req.body.type,
            ClientToken: req.body.clientToken,
            ClientSecret: clientSecret
        },
        ]);
    res.status(200).json();
}

exports.getToken = function(req, res) {
    var db = admin.database();
    var ref = db.ref("/user_data/tokens");
    refChild = ref.child(req.params.id);
    refChild.once("value", function(snapshot) {
        var data = snapshot.val();
        res.status(200).json(data);
    });
}