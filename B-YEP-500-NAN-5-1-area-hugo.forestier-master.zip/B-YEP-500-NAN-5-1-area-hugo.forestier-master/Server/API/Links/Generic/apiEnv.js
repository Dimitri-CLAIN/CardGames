var cardREaction = require('../Trello/REaction/REactionCardManager');
var gmail = require('../Gmail/REaction/reactionGMail');
var github = require('../Github/REaction/reactionGithub');
var twitter = require('../Twitter/REaction/reactionTwitter');

exports.callREaction = function (type, request, response)
{
    const REaction = {
        "createCard": cardREaction.create,
        "createChecklist": cardREaction.createChecklist,
        "addComment": cardREaction.addComment,
        "addMember": cardREaction.addMember,
        "removeMember": cardREaction.removeMember,
        "sendMail": gmail.sendMail,
        "commentIssue": github.commentIssue,
        "updateIssue": github.updateIssue,
        "updatePullRequest": github.updatePullRequest,
        "tweet": twitter.add,
    };

    console.log(`Une REaction de type ${type} a été appellé`);
    REaction[type](request, response);
}