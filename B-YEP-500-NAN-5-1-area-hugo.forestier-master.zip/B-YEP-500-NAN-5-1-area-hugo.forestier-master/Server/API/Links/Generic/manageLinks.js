var admin = require("firebase");
const { getBoards } = require("../Trello/Action/actionTrello");

function areObjectIdentical(json1, json2) {

    for (i in Object.keys(json1)) {
        if (Object.keys(json2).includes(Object.keys(json1)[i]) == false) {
            return(false)
        } else {
            if (typeof(json1[Object.keys(json1)[i]]) == "object") {
                if (json1[Object.keys(json1)[i]].length == 1) {
                    if (JSON.stringify(json1[Object.keys(json1)[i]]) != JSON.stringify(json2[Object.keys(json1)[i]])) {
                        return(false)
                    }
                } else {
                    if (areObjectIdentical(json1[Object.keys(json1)[i]], json2[Object.keys(json1)[i]]) == false) {
                        return (false)
                    }
                }
            } else {
                if (json1[Object.keys(json1)[i]] != json2[Object.keys(json1)[i]]) {
                    return(false)
                }
            }
        }
    }
    for (i in Object.keys(json2)) {
        if (Object.keys(json1).includes(Object.keys(json2)[i]) == false) {
            return(false)
        } else {
            if (typeof(json1[Object.keys(json2)[i]]) == "object") {
                if (json1[Object.keys(json2)[i]].length == 1) {
                    if (JSON.stringify(json1[Object.keys(json2)[i]]) != JSON.stringify(json2[Object.keys(json2)[i]])) {
                        return(false)
                    }
                } else {
                    if (areObjectIdentical(json1[Object.keys(json2)[i]], json2[Object.keys(json2)[i]]) == false) {
                        return (false)
                    }
                }
            } else {
                if (json1[Object.keys(json2)[i]] != json2[Object.keys(json2)[i]]) {
                    return(false)
                }
            }
        }
    }
    return (true)
}

exports.addLinkToDB = async function(req, res) {
    var db = admin.database();
    var ref = db.ref("/user_data/");
    var refTmpChild = ref.child(`links/${req.params.clientToken}`);
    var alreadyExist = false
    await refTmpChild.once("value", function(snapshot) {
        var data = snapshot.val();
        for (var i in data) {
            if (areObjectIdentical(data[i][0].Action, JSON.parse(req.body.action)) === true && areObjectIdentical(data[i][0].REaction, JSON.parse(req.body.reaction)) === true) {
                alreadyExist = true
            }
        }
    });
    if (alreadyExist != true) {
        refChild = refTmpChild.push();
        refChild.set([
            {
                ARname: req.body.arname,
                Activated: req.body.activated,
                Action: JSON.parse(req.body.action),
                REaction: JSON.parse(req.body.reaction)
            },
        ]);
    }
    res.status(200).json();
}


exports.getPlatformAction = function(req, res) {
    var platform = "";
    var db = admin.database();
    var ref = db.ref("/data_area/actions");
    ref.once("value", function(snapshot) {
        var data = snapshot.val();
        for (let card in data[0]) {
            if (card == req.query.action) {
                platform = data[0][card].platform;
            }
        }
        res.status(200).json(platform);
    });
}

exports.getPlatformREaction = function(req, res) {
    var db = admin.database();
    var platform = "";
    var ref = db.ref("/data_area/reactions");
    ref.once("value", function(snapshot) {
        var data = snapshot.val();
        for (let card in data[0]) {
            if (card == req.query.reaction) {
                platform = data[0][card].platform;
            }
        }
        res.status(200).json(platform);
    });
}

exports.getREactionFromAction = async function(id, action) {
    var db = admin.database();
    var ref = db.ref("/user_data/links");
    var returnValue = []
    refChild = ref.child(id);
    await refChild.once("value", function(snapshot) {
        var data = snapshot.val();
        for (let card in data) {
            for (let key in data[card]) {
                if (data[card][key].Action.name === action.name) {
                    if ('trelloBoard' in data[card][key].Action.config && "trelloBoard" in action) {
                        if (data[card][key].Action.config.trelloBoard === action.trelloBoard) {
                            if ('trelloCard' in data[card][key].Action.config && "trelloCard" in action) {
                                if (data[card][key].Action.config.trelloCard === action.trelloCard) {
                                    returnValue.push(data[card][key].REaction);
                                }
                            } else {
                                returnValue.push(data[card][key].REaction);
                            }
                        }
                    }
                }
            }
        }
    });
    return (returnValue);
}

// exports.addLinkToDB = function(req, res) {
//     var db = admin.database();
//     var ref = db.ref("/data_area");
//     refChild = ref.child("reactions"); // Changer id par uuid du user auth !
//     //refChild = refOldChild.push();
//     refChild.set([
//         {
//             createChecklist: {
//                 platform: "Trello"
//             },
//             addComment: {
//                 platform: "Trello",
//             },
//             addMember: {
//                 platform: "Trello",
//             },
//             addComment: {
//                 platform: "Trello"
//             },
//             sendMail: {
//                 platform: "Gmail"
//             }
//         },
//         ]);
//     res.status(200).json();
// }

exports.getLinks = function(req, res) {
    var db = admin.database();
    var ref = db.ref("/user_data/links");
    refChild = ref.child(req.query.id);
    refChild.once("value", function(snapshot) {
        var data = snapshot.val();
        res.status(200).json(data);
    });
}

exports.getCardConfigs = async function(req, res) {
    let data = [];
    const { platform, id, clientToken } = req.params;

    if (platform === 'Trello') {
        data.push([{
            type: "list",
            data: await getBoards({id, clientToken}),
            id: "boardsList"
        },
            {
                type: "text",
                label: "Description",
                id: "webhookDescription",
            }
        ]);
    }
    res.status(200).json(data);
}