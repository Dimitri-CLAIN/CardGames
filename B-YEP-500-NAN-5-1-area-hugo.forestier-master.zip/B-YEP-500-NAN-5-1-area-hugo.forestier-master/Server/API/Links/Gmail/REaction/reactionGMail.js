const axios = require('axios');
const base64url = require('base64url');

async function getGoogleToken(id) {
    const url = `http://localhost:8080/api/firebase/${id}/token/`;
    var clientToken;

    var res = await axios.get(url)
    console.log("res", res.data);
    for (let element in res.data) {
        for (let i in res.data[element]) {
            var connection = res.data[element][i];
            if (connection.Type === "Gmail" || connection.Type === "Google") {
                clientToken = connection.ClientToken;
            }
        }
    }
    return(clientToken);
}

exports.sendMail = async function(req, response) {
    // console.log("FIREBASE CLIENT TOKEN FOR GMAIL =>", req.query.clientToken)
    // console.log("FIREBASE CLIENT TOKEN FOR GMAIL =>", req.body.clientToken)
    var clientTokenGoogle = null;
    if (!req.body.clientToken) {
        console.log("QUERY CLIENT TOKEN =>", req.query.clientToken)
        clientTokenGoogle = await getGoogleToken(req.query.clientToken);

    } else {
        console.log("BODY CLIENT TOKEN =>", req.body.clientToken)
        clientTokenGoogle = await getGoogleToken(req.body.clientToken);
    }
    console.log("GMAIL TOKEN =>", clientTokenGoogle)
    const url = `https://content.googleapis.com/gmail/v1/users/me/messages/send`;
    let message = `From: AREA\nTo: ${req.body.textReceiver}\nSubject: ${req.body.textSubject}\nContent-Type: text/html; charset=UTF-8\n\n${req.body.textEmailContent}`;
    let encodedMessage = base64url(message);

    axios.post(url, {
        raw: encodedMessage
    }, {
        headers: {
            'Authorization':  `Bearer ${clientTokenGoogle}`,
            'Content-Type': 'application/json'
        },
    })
    .then(res => {
        console.log("response SendMail: ", res.data);
        if ("isAReaction" in req.body && req.body.isAReaction) {
            console.log("Reaction mail");
        } else
            response.send(res.data);
    })
    .catch(err => {
        console.log("err:", err)
    });
}