var admin = require("firebase");

exports.addToken = function(req, res) {
    var db = admin.database();
    var ref = db.ref("/user_data/");
    var refTmpChild = ref.child("tokens/" + req.params.id);
    refChild = refTmpChild.push();
    refChild.set([
        {
            Type: req.body.type,
            ClientToken: req.body.clientToken,
            ClientSecret: req.body.clientSecret
        },
        ]);
    res.status(200).json();
}