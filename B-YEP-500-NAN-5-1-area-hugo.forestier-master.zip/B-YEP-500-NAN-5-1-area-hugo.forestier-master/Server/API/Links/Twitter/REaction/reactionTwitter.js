const axios = require('axios');
var crypto = require('crypto');
var btoa = require('btoa');
const Twitter = require('twitter');

function random32bit() {
    return crypto.randomBytes(4).readUInt32BE(0, true);
  }

async function getTwitterToken(id) {
    const url = `http://localhost:8080/api/firebase/${id}/token/`;
    var clientToken;

    var res = await axios.get(url)
    for (let element in res.data) {
        for (let i in res.data[element]) {
            var connection = res.data[element][i];
            console.log("type ", connection.Type);
            if (connection.Type === "Twitter") {
                clientToken = connection.ClientToken;
            }
        }
    }
    return(clientToken);
}

async function getTwitterTokenSecret(id) {
    const url = `http://localhost:8080/api/firebase/${id}/token/`;
    var clientToken;

    var res = await axios.get(url)
    for (let element in res.data) {
        for (let i in res.data[element]) {
            var connection = res.data[element][i];
            console.log("type ", connection.Type);
            if (connection.Type === "Twitter") {
                clientToken = connection.ClientSecret;
            }
        }
    }
    return(clientToken);
}

exports.add = async function(req, response) {
    var clientToken = req.body.clientToken;

    var access_token_key = await getTwitterToken(clientToken);
    var access_token_secret = await getTwitterTokenSecret(clientToken);

    var consummer_key = process.env.APP_TWITTER_KEY;
    var consummer_secret = process.env.APP_TWITTER_SECRET;

    let client = new Twitter({
        consumer_key: consummer_key,
        consumer_secret: consummer_secret,
        access_token_key: access_token_key,
        access_token_secret: access_token_secret
    });

    console.log("CONSUMMER KEY =>", consummer_key)
    console.log("CONSUMMER SECRET =>", consummer_secret)
    console.log("ACCESS TOKEN KEY =>", access_token_key)
    console.log("ACCESS TOKEN SECRET =>", access_token_secret)
    console.log("MESSAGE TO TWEET =>", req.body.textMessage)

    let params = {
        status: req.body.textMessage
    }

    await client.post('/statuses/update', params)
    .then(res => {
        console.log(res.id_str, res.created_at, res.text);
        response.send(res.text);
    })
    .catch(err => response.send(err));
}