const axios = require('axios');

async function getGithubToken(id) {
    const url = `http://localhost:8080/api/firebase/${id}/token/`;
    var clientToken;

    var res = await axios.get(url)
    for (let element in res.data) {
        for (let i in res.data[element]) {
            var connection = res.data[element][i];
            if (connection.Type === "Github") {
                clientToken = connection.ClientToken;
            }
        }
    }
    return(clientToken);
}

async function getRepoById(id, clientTokenGithub) {
    const url = `https://api.github.com/repositories/${id}`;
    var name = "";

    await axios.get(url, {
        headers: {
            'Authorization': 'token ' + clientTokenGithub,
            'Content-Type': 'application/vnd.github.v3+json',
        }
    })
    .then(res => {
        name = res.data.full_name;
    })
    .catch(err => console.error(err));
    return (name);
}

exports.listRepositoryIssues = async function(req, response) {
    var id = req.params.repo;
    var clientToken = req.params.clientToken;
    var clientTokenGithub = await getGithubToken(clientToken);
    var repo = await getRepoById(id, clientTokenGithub);
    console.log("ici", repo);
    const url = `https://api.github.com/repos/${repo}/issues`;

    axios.get(url, {
        headers: {
            'Authorization': 'token ' + clientTokenGithub,
            'Content-Type': 'application/vnd.github.v3+json',
        }
    })
    .then(res => {
        var newJson = res.data
        for (var i in newJson) {
            newJson[i]["name"] = newJson[i].title;
            newJson[i].id = newJson[i].number;
        }
        console.log("newjson:", newJson);
        response.send(newJson);
    })
    .catch(err => console.error(err));
}

exports.listRepositories = async function(req, response) {
    var clientToken = req.params.clientToken;
    var clientTokenGithub = await getGithubToken(clientToken);
    console.log(clientTokenGithub);
    const url = `https://api.github.com/user/repos`;

    axios.get(url, {
        headers: {
            'Authorization': `Bearer ${clientTokenGithub}`,
            'Content-Type': 'application/vnd.github.v3+json',
        }
    })
    .then(res => {
        response.status(res.status).json(res.data);
        response.send()
    })
    .catch(err => console.error(err));
}

exports.listPullRequests = async function(req, response) {
    var clientToken = req.params.clientToken;
    var id = req.params.repo;
    var clientTokenGithub = await getGithubToken(clientToken);
    var repo = await getRepoById(id, clientTokenGithub);
    const url = `https://api.github.com/repos/${repo}/pulls`;

    axios.get(url, {
        headers: {
            'Authorization': 'token ' + clientTokenGithub,
            'Content-Type': 'application/vnd.github.v3+json',
        }
    })
    .then(res => {
        var newJson = res.data
        console.log(res.data)
        for (var i in newJson) {
            newJson[i]["name"] = newJson[i].title
            newJson[i].id = newJson[i].number;
        }
        response.send(newJson);
    })
    .catch(err => console.error(err));
}