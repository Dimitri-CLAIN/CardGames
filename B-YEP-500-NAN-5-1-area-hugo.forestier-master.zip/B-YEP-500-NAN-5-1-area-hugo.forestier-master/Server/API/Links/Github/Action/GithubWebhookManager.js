const axios = require('axios');

exports.webhookHead = function (request, response)
{
    console.log(`This is webhook head ${request}`);
}

exports.webhookCallBack = function (request, response)
{
    console.log(`This is Callback request ${request}`);
}

exports.createWebhook = function (request, response)
{
    const { clientToken, callbackURL, owner, repo } = request.body;
    const url = `https://api.github.com/repos/${owner}/${repo}/hooks`;

    console.log(`request body is : ${request.body}`);

    axios.post(url, {
        config: {
            url: callbackURL,
            content_type: 'json',
            secret: 'secret',
            insecure_ssl: 'insecure_ssl',
            token: clientToken,
            digest: 'digest'
        }
    })
    .then(res => {
        console.log(
            `Response webhook is active:${res.active} with id:${res.id}`
        );
        if (res.active === true)
            response.status(200);
        else
            response.status(400);
    })
    .catch(err => console.error("err: ", err));
}

exports.getWebhook = function (request, response)
{
    const { hookID, owner, repo } = request.body;
    const url = `https://api.github.com/repos/${owner}/${repo}/hooks/${hookID}`;

    axios.get(url, {
        owner: owner,
        repo: repo,
        hook_id: hookID
    })
    .then(response => {
        console.log(`Webhook status: ${response.status}`);
    })
}

exports.updateWebhook = function (request, response)
{
    const { clientToken, hookID, owner, repo } = request.body;
    const url = `https://api.github.com/repos/${owner}/${repo}/hooks/${hookID}`;

    axios.patch(url, {
        owner: owner,
        repo: repo,
        hook_id: hookID,
        config: {
            url: callbackURL,
            content_type: 'json',
            secret: 'secret',
            insecure_ssl: 'insecure_ssl',
            token: clientToken,
            digest: 'digest'
        }
    })
    .then(response => {
        console.log(`Webhook status: ${response.status}`);
    })
}

exports.getWebhook = function (request, response)
{
    const {hookID, owner, repo } = request.body;
    const url = `https://api.github.com/repos/${owner}/${repo}/hooks/${hookID}`;

    axios.get(url, {
        owner: owner,
        repo: repo,
        hook_id: hookID
    })
    .then(response => {
        console.log(`Webhook status: ${response.status}`);
    })
}

exports.deleteWebhook = function (request, response)
{
    const { hookID, owner, repo } = request.body;
    const url = `https://api.github.com/repos/${owner}/${repo}/hooks/${hookID}`;

    axios.patch(url, {
        owner: owner,
        repo: repo,
        hook_id: hookID
    })
    .then(response => {
        console.log(`Webhook status: ${response.status}`);
    })
}