const axios = require('axios');
const qs = require('qs')

async function getGithubToken(id) {
    const url = `http://localhost:8080/api/firebase/${id}/token/`;
    var clientToken;

    var res = await axios.get(url)
    for (let element in res.data) {
        for (let i in res.data[element]) {
            var connection = res.data[element][i];
            if (connection.Type === "Github") {
                clientToken = connection.ClientToken;
            }
        }
    }
    return(clientToken);
}

async function getRepoById(id, clientTokenGithub) {
    const url = `https://api.github.com/repositories/${id}`;
    var name = "";

    await axios.get(url, {
        headers: {
            'Authorization': 'token ' + clientTokenGithub,
            'Content-Type': 'application/vnd.github.v3+json',
        }
    })
    .then(res => {
        name = res.data.full_name;
    })
    .catch(err => console.error(err));
    return (name);
}

exports.updateIssue = async function(req, response) {
    let clientToken = req.body.clientToken;
    let id = req.body.githubRepo;
    let issue_number = req.body.githubIssueNumber;
    let message = req.body.textTitleIssue;

    var clientTokenGithub = await getGithubToken(clientToken);
    var repo = await getRepoById(id, clientTokenGithub);
    console.log("ee", req.body);
    const url = `https://api.github.com/repos/${repo}/issues/${issue_number}`;

    const config = {
        headers: {
            'Authorization': 'token ' + clientTokenGithub,
            'Content-Type': 'application/vnd.github.v3+json',
        }
    }

    const body = {
        "body": message
    }

    axios.post(url, body, config)
    .then(res => {
        console.log(`Response: ${res.status}`);
        if ("isAReaction" in req.body && req.body.isAReaction) {
            console.log("Reaction update issue");
        } else
            response.status(res.status).json({status: res.statusText});
    })
    .catch(err => console.error(err));
}

exports.updatePullRequest = async function(req, response) {
    let clientToken = req.body.clientToken;
    let id = req.body.githubRepo;
    let pull_number = req.body.githubPullNumber;
    let title_pullRequest = req.body.textTitlePullRequest;
    var clientTokenGithub = await getGithubToken(clientToken);
    var repo = await getRepoById(id, clientTokenGithub);
    const url = `https://api.github.com/repos/${repo}/pulls/${pull_number}`;

    const config = {
        headers: {
            'Authorization': 'token ' + clientTokenGithub,
            'Content-Type': 'application/vnd.github.v3+json',
        }
    }

    const body = {
        "body": title_pullRequest
    }

    axios.post(url, body, config)
    .then(res => {
        console.log(`Response: ${res.status}`);
        if ("isAReaction" in req.body && req.body.isAReaction) {
            console.log("Reaction comment issue");
        } else
            response.status(res.status).json({status: res.statusText});
    })
    .catch(err => console.error(err));
}

exports.commentIssue = async function(req, response) {
    let clientToken = req.body.clientToken;
    let id = req.body.githubRepo;
    let issue_number = req.body.githubIssueNumber;
    let message = req.body.textMessage;
    var clientTokenGithub = await getGithubToken(clientToken);
    var repo = await getRepoById(id, clientTokenGithub);
    const url = `https://api.github.com/repos/${repo}/issues/${issue_number}/comments`;

    const config = {
        headers: {
            'Authorization': 'token ' + clientTokenGithub,
            'Content-Type': 'application/vnd.github.v3+json',
        }
    }

    const body = {
        "body": message
    }

    axios.post(url, body, config)
    .then(res => {
        console.log(`Response: ${res.status}`);
        if ("isAReaction" in req.body && req.body.isAReaction) {
            console.log("Reaction comment issue");
        } else
            response.status(res.status).json({status: res.statusText});
        response.send("ok")
    })
    .catch(err => response.send("not ok"));
}