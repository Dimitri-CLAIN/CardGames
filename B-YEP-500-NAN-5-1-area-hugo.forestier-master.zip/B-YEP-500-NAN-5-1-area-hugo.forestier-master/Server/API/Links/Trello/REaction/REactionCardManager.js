const axios = require('axios');

async function getTrelloToken(id) {
    const url = `http://localhost:8080/api/firebase/${id}/token/`;
    var clientToken;

    var res = await axios.get(url)
    for (let element in res.data) {
        for (let i in res.data[element]) {
            var connection = res.data[element][i];
            if (connection.Type === "Trello") {
                clientToken = connection.ClientToken;
            }
        }
    }
    return(clientToken);
}

/**
 * [createCard description]
 * @param  {[object]} request body contain { clientToken, name, desc, idList }
 * @param  {[object]} response
 */
exports.create = async function (request, response)
{
    let { clientToken, name, desc, idList } = request.body;
    var clientTokenTrello = await getTrelloToken(clientToken);
    const url = `https://api.trello.com/1/cards/?key=${process.env.APP_KEY_TRELLO}&token=${clientTokenTrello}&name=${name}&desc=${desc}&idList=${idList}`;

    axios.post(url)
    .then(res => {
        console.log(`Response: ${res.status} ${res.statusText}`);
        if ("isAReaction" in request.body && request.body.isAReaction) {
            console.log("Reaction create card");
        } else
            response.status(res.status).json({status: res.statusText});
    })
    .catch(err => console.error(err));
}

/**
 * [createChecklist description]
 * @param  {[object]} request body contain { cardId, clientToken, name }
 * @param  {[object]} response
 */
exports.createChecklist = async function (request, response)
{
    let { cardId, clientToken, name } = request.body;
    var clientTokenTrello = await getTrelloToken(clientToken);
    const url = `https://api.trello.com/1/cards/${cardId}/checklists?key=${process.env.APP_KEY_TRELLO}&token=${clientTokenTrello}&name=${name}`;

    axios.post(url)
    .then(res => {
        console.log(`Response: ${res.status} ${res.statusText}`);
        if ("isAReaction" in request.body && request.body.isAReaction) {
            console.log("Reaction createChecklist");
        } else
            response.status(res.status).json({status: res.statusText});
    })
    .catch(err => console.error(err));
}

/**
 * [addComment description]
 * @param  {[object]} request body contain { cardId, clientToken, text }
 * @param  {[object]} response
 */
exports.addComment = async function (request, response)
{
    let { cardId, clientToken, text } = request.body;
    var clientTokenTrello = await getTrelloToken(clientToken);
    const url = `https://api.trello.com/1/cards/${cardId}/actions/comments?key=${process.env.APP_KEY_TRELLO}&token=${clientTokenTrello}&text=${text}`;

    axios.post(url)
    .then(res => {
        console.log(`Response: ${res.status} ${res.statusText}`);
        if ("isAReaction" in request.body && request.body.isAReaction) {
            console.log("Reaction addComment");
        } else
            response.status(res.status).json({status: res.statusText});
    })
    .catch(err => console.error(err));
}

/**
 * [addMember description]
 * @param  {[object]} request body contain { cardId, clientToken, value } value is the IdMember
 * @param  {[object]} response
 */
exports.addMember = async function (request, response)
{
    let { cardId, clientToken, value } = request.body;
    var clientTokenTrello = await getTrelloToken(clientToken);
    const url = `https://api.trello.com/1/cards/${cardId}/idMembers?key=${process.env.APP_KEY_TRELLO}&token=${clientTokenTrello}&value=${value}`;

    axios.post(url)
    .then(res => {
        console.log(`Response: ${res.status} ${res.statusText}`);
        if ("isAReaction" in request.body && request.body.isAReaction) {
            console.log("Reaction addMember");
        } else
            response.status(res.status).json({status: res.statusText});
    })
    .catch(err => console.error(err));
}

/**
 * [removeMember description]
 * @param  {[object]} request body contain { cardId, clientToken, idMember }
 * @param  {[object]} response
 */
exports.removeMember = async function (request, response)
{
    let { cardId, clientToken, idMember } = request.body;
    var clientTokenTrello = await getTrelloToken(clientToken);
    const url = `https://api.trello.com/1/cards/${cardId}/idMembers/${idMember}?key=${process.env.APP_KEY_TRELLO}&token=${clientTokenTrello}`;

    axios.post(url)
    .then(res => {
        console.log(`Response: ${res.status} ${res.statusText}`);
        if ("isAReaction" in request.body && request.body.isAReaction) {
            console.log("Reaction removeMember");
        } else
            response.status(res.status).json({status: res.statusText});
    })
    .catch(err => console.error(err));
}