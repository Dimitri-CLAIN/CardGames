const Trello = require('trello');
const axios = require('axios');

async function getTrelloToken(id) {
    const url = `http://localhost:8080/api/firebase/${id}/token/`;
    var clientToken;

    var res = await axios.get(url)
    for (let element in res.data) {
        for (let i in res.data[element]) {
            var connection = res.data[element][i];
            if (connection.Type === "Trello") {
                clientToken = connection.ClientToken;
            }
        }
    }
    return(clientToken);
}

exports.createWebhook = async function(req, response) {
    var app_key = process.env.APP_KEY_TRELLO;
    var trello_token = await getTrelloToken(req.params.clientToken);

    var trello = new Trello(app_key, trello_token);

    console.log(req);
    trello.addWebhook(req.body.desc, `${ngrokURL}/callback/trello/card/${req.params.clientToken}`, req.body.idModel,
        function(error) {
            if (error) {
                console.log(error);
            }
            console.log("OkcreateWebhook");
            response.status(200).send("Ok");
        }
    );
}
