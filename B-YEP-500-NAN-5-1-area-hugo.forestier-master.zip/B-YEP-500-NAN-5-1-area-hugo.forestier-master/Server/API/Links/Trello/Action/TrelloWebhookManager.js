const axios = require('axios');
const FirebaseLinks = require('../../../Links/Generic/manageLinks');
const { callREaction } = require('../../../Links/Generic/apiEnv');

exports.updateWebhook = function (webhookID, config)
{
    const { clientToken, callbackURL, idIWatch, description } = config;

    axios.put(`https://api.trello.com/1/webhooks/${webhookID}?key=${process.env.APP_KEY_TRELLO}&token=${clientToken}&description=${description}&callbackURL=${callbackURL}&idModel=${idIWatch}`)
    .then(response => {
        console.log(
            `Response status: ${response.status}, webhook is active:${response.body.active} with id:${response.body.id}`
        );
    })
    .catch(err => console.error(err));
}

exports.getWebhook = function (webhookID, config)
{
    const { clientToken } = config;

    axios.get(`https://api.trello.com/1/webhooks/${webhookID}?key=${process.env.APP_KEY_TRELLO}&token=${clientToken}`)
    .then(response => {
        console.log(
            `Response status: ${response.status}`
        );
    })
    .catch(err => console.error(err));
}


exports.deleteWebhook = function (webhookID, config)
{
    const { clientToken } = config;

    axios.get(`https://api.trello.com/1/token/${clientToken}/webhooks/?key=${process.env.APP_KEY_TRELLO}`)
    .then(res => {
        console.log(res);
    })
    .catch(err => console.error(err));
}

exports.webhookCallBack = async function (request, response)
{
    var req = null;
    var clientToken = request.params.clientToken;
    var action = {
        name: request.body.action.type,
        trelloBoard: ('board' in request.body.action.data) ? request.body.action.data.board.id : null,
        trelloCard: ('card' in request.body.action.data) ? request.body.action.data.card.id : null
    }

    var reactions = await FirebaseLinks.getREactionFromAction(clientToken, action);
    for (reaction in reactions) {
        req = {
            body : {
                isAReaction: true,
                clientToken: clientToken,
                name: reactions[reaction].name,
                desc: ('desc' in reactions[reaction].config) ? reactions[reaction].config.desc : null,
                idList: ('trelloList' in reactions[reaction].config) ? reactions[reaction].config.trelloList : null,
                value: ('idMember' in reactions[reaction].config) ? reactions[reaction].config.idMember : null,
                cardId: ('trelloCard' in reactions[reaction].config) ? reactions[reaction].config.trelloCard : null,
                text: ('textComment' in reactions[reaction].config) ? reactions[reaction].config.textComment : null,
                textEmailContent: ('textEmailContent' in reactions[reaction].config) ? reactions[reaction].config.textEmailContent : null,
                textSubject: ('textSubject' in reactions[reaction].config) ? reactions[reaction].config.textSubject : null,
                textReceiver: ('textReceiver' in reactions[reaction].config) ? reactions[reaction].config.textReceiver : null,
                owner: ('owner' in reactions[reaction].config) ? reactions[reaction].config.owner : null,
                githubRepo: ('githubRepo' in reactions[reaction].config) ? reactions[reaction].config.githubRepo : null,
                githubIssueNumber: ('githubIssueNumber' in reactions[reaction].config) ? reactions[reaction].config.githubIssueNumber : null,
                textTitleIssue: ('textTitleIssue' in reactions[reaction].config) ? reactions[reaction].config.textTitleIssue : null,
                githubPullNumber: ('githubPullNumber' in reactions[reaction].config) ? reactions[reaction].config.githubPullNumber : null,
                textTitlePullRequest: ('textTitlePullRequest' in reactions[reaction].config) ? reactions[reaction].config.textTitlePullRequest : null,
                textMessage: ('textMessage' in reactions[reaction].config) ? reactions[reaction].config.textMessage : null
            }
        };
        console.log("My body is composed of: ", req);
        callREaction(reactions[reaction].name, req, null);
    }
    response.status(200);
    response.send("webhookCallBack");
}

exports.webhookHead = function (request, response)
{
    console.log("HEAD");
    response.status(200);
    response.send("ok");
}