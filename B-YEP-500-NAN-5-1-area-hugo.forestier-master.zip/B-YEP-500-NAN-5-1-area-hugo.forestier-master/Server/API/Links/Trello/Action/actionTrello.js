const axios = require('axios');

async function getTrelloToken(id) {
    const url = `http://localhost:8080/api/firebase/${id}/token/`;
    var clientToken;

    var res = await axios.get(url)
    for (let element in res.data) {
        for (let i in res.data[element]) {
            var connection = res.data[element][i];
            if (connection.Type === "Trello") {
                clientToken = connection.ClientToken;
            }
        }
    }
    return(clientToken);
}

exports.getBoards = async function(req, response) {
    var boards = [];
    let clientTokenTrello = await getTrelloToken(req.params.clientToken);
    const url = `https://api.trello.com/1/members/me/boards?key=${process.env.APP_KEY_TRELLO}&token=${clientTokenTrello}`;

    await axios.get(url)
    .then( res => {
        for (let i = 0; res.data[i]; i++) {
            boards.push({
                name: res.data[i].name,
                id: res.data[i].id
            });
        }
        response.send(boards);
    })
    .catch(err => console.log(err));
}

exports.getCards = async function(req, response) {
    var boardId = req.params.boardId;
    var clientTokenTrello = await getTrelloToken(req.params.clientToken);
    var cards = [];
    const url = `https://api.trello.com/1/boards/${boardId}/cards?key=${process.env.APP_KEY_TRELLO}&token=${clientTokenTrello}`;

    axios.get(url)
    .then(res => {
        for(let i = 0; res.data[i]; i++) {
            cards.push({
                name: res.data[i].name,
                id: res.data[i].id
            });
        }
        response.status(res.status).json(cards);
    })
    .catch(err => response.send(err));
}

exports.getMembersOfABoard = async function(req, response) {
    var boardId = req.params.boardId;
    var clientTokenTrello = await getTrelloToken(req.params.clientToken);
    const url = `https://api.trello.com/1/boards/${boardId}/members?key=${process.env.APP_KEY_TRELLO}&token=${clientTokenTrello}`;

    axios.get(url)
    .then(res => {
        response.status(res.status).json(res.data);
    })
    .catch(err => response.send(err));
}
