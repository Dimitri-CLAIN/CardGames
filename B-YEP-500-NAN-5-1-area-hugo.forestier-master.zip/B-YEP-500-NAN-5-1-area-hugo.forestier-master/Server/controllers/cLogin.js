const express = require('express');
const app = express();

exports.Login = function(req, res) {
    res.statusCode = 200;
    res.render("login.html");
}

exports.Signup = function(req, res) {
    res.statusCode = 200;
    res.render("signup.html");
}