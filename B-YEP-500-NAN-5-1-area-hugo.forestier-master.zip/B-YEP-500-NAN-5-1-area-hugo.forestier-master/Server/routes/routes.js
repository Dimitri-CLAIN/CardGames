module.exports = function(app) {
  const TrelloWebhookManager = require('../API/Links/Trello/Action/TrelloWebhookManager');
  const TrelloREactionCardManager = require('../API/Links/Trello/REaction/REactionCardManager');

  const manageLinks = require('../API/Links/Generic/manageLinks.js');
  const manageTokens = require('../API/Firebase/manageTokens.js');
  const manageAREA = require('../API/Firebase/manageAREA.js');
  const actionTrello = require('../API/Links/Trello/Action/actionTrello.js');
  const manageTrello = require('../API/Links/Trello/Action/manageTrello.js');

  const reactionGithub = require('../API/Links/Github/REaction/reactionGithub.js');
  const actionGithub = require('../API/Links/Github/Action/actionGithub.js');
  const GithubWebhookManager = require('../API/Links/Github/Action/GithubWebhookManager');

  const reactionTwitter = require('../API/Links/Twitter/REaction/reactionTwitter.js');
  const reactionGmail = require('../API/Links/Gmail/REaction/reactionGMail.js');
  const manageGithub = require('../API/Github/manageGithub.js');
  const passport = require('passport');
  const about = require('../API/about');

  app.route('/test')
    .get(function (req, res) {
        res.send('Holala you past the test');
    });

  app.route('/api/gmail/sendMail/:clientToken')
    .post(reactionGmail.sendMail);

  app.route('/api/trello/createWebhookCard/:clientToken')
    .post(manageTrello.createWebhook);

  app.route('/auth/google/')
    .get(passport.authorize('google', { scope: ['https://www.googleapis.com/auth/plus.login', 'https://www.googleapis.com/auth/gmail.send'] }))

  app.route('/auth/google/callback')
    .get(passport.authenticate('google', { failureRedirect: '/login' }),
    function(req, res) {
      console.log("GOOGLE rq =>", req)
      res.redirect('http://localhost:8081/googleauth/' + req.user.google_access_token);
    });

  app.route('/auth/twitter')
    .get(passport.authorize('twitter'))

  app.route('/twitter/callback')
  .get(passport.authorize('twitter', { failureRedirect: '/auth/error' }),
  function(req, res) {
    console.log("TWITTER rq =>", req)
    res.redirect('http://localhost:8081/authtwittertoken/' + req.account.twitter_access_token + '/' + req.account.twitter_token_secret);
  });

  app.route('/api/twitter/tweet')
    .post(reactionTwitter.add);

  app.route('/api/trello/boards/get/:clientToken')
    .get(actionTrello.getBoards);

  app.route('/api/trello/cards/get/:boardId/:clientToken')
    .get(actionTrello.getCards)

  app.route('/api/trello/board/member/get/:boardId/:clientToken')
    .get(actionTrello.getMembersOfABoard)
    .post(actionTrello.getCards)

  app.route('/callback/trello/card/:clientToken')
    .head(TrelloWebhookManager.webhookHead)
    .post(TrelloWebhookManager.webhookCallBack);

  app.route('/api/trello/card/create')
    .post(TrelloREactionCardManager.create);

  app.route('/api/trello/boards/get/:id/:clientToken')
    .get(actionTrello.getBoards);

  app.route('/api/trello/cards/get/:boardId/:clientToken')
    .get(actionTrello.getCards);

  app.route('/api/trello/checklist/create')
    .post(TrelloREactionCardManager.createChecklist);

  app.route('/api/trello/comment/add')
    .post(TrelloREactionCardManager.addComment);

  app.route('/api/trello/member/add')
    .post(TrelloREactionCardManager.addComment);

    app.route('/api/trello/member/remove')
    .post(TrelloREactionCardManager.removeMember);

  app.route('/api/generic/link/create/:clientToken')
    .post(manageLinks.addLinkToDB);

  app.route('/api/generic/link/getPlatformAction')
    .get(manageLinks.getPlatformAction);

  app.route('/api/generic/link/getPlatformREaction')
    .get(manageLinks.getPlatformREaction);

  app.route('/api/generic/webhook/getREaction')
    .get(manageLinks.getREactionFromAction)

  app.route('/api/generic/link/get')
    .get(manageLinks.getLinks);

  app.route('/api/github/webhook/create')
    .post(GithubWebhookManager.createWebhook);

  app.route('/callback/github')
    .head(GithubWebhookManager.webhookHead)
    .post(GithubWebhookManager.webhookCallBack);

  app.route('/api/link/github/updateIssue')
    .post(reactionGithub.updateIssue);

  app.route('/api/link/github/updatePullRequest')
    .post(reactionGithub.updatePullRequest);

  app.route('/api/link/github/commentIssue')
    .post(reactionGithub.commentIssue);

  app.route('/api/link/github/listRepositories/:clientToken')
    .get(actionGithub.listRepositories);

  app.route('/api/link/github/listRepositoryIssues/:clientToken/:repo')
    .get(actionGithub.listRepositoryIssues);

  app.route('/api/link/github/listPullRequests/:clientToken/:repo')
    .get(actionGithub.listPullRequests);

  app.route('/api/firebase/:id/token/')
    .post(manageTokens.addToken)
    .get(manageTokens.getToken);

  app.route('/api/generic/link/getActions')
    .get(manageAREA.getActions);

  app.route('/api/generic/link/getREactionsFrom/:action')
    .get(manageAREA.getREactionsFromAction);

  app.route('/api/generic/link/getREactions')
    .get(manageAREA.getREactions);

  app.route('/api/firebase/getConfiguration/:action')
    .get(manageAREA.getConfiguration);

  app.route('/about.json')
    .get(about.getAbout);

  app.route('/api/generic/link/:platform/Configs/:id/:clientToken')
    .get(manageLinks.getCardConfigs);

  app.route('/api/github/auth')
    .post(manageGithub.auth);
}
