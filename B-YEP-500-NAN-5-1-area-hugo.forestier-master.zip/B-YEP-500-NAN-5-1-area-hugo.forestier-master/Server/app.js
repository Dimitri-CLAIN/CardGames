const express = require('express');
const bodyParser = require('body-parser');
const passport = require('passport');
const TwitterStrategy = require('passport-twitter').Strategy;
var GoogleStrategy = require('passport-google-oauth').OAuth2Strategy;
const ngrok = require('ngrok');
const app = express();
const cookieSession = require('cookie-session')

app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
  );

app.use(cookieSession({
  name: 'twitter-auth-session',
  keys: ['key1', 'key2']
}))

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
  app.options('*', (req, res) => {
    res.header('Access-Control-Allow-Methods', 'GET, PATCH, PUT, POST, DELETE, OPTIONS');
    res.send();
  });
});

app.use(passport.initialize());
app.use(passport.session());

passport.use(new TwitterStrategy({
    consumerKey: process.env.APP_TWITTER_KEY,
    consumerSecret: process.env.APP_TWITTER_SECRET,
    callbackURL: "http://localhost:8080/twitter/callback",
  },
  function(accessToken, tokenSecret, profile, done) {
    tokens = {
      twitter_access_token: accessToken,
      twitter_token_secret: tokenSecret
    }
    return done(null, tokens);
  }
));

passport.use(new GoogleStrategy({
  clientID: process.env.APP_GOOGLE_CLIENT_ID,
  clientSecret: process.env.APP_GOOGLE_CLIENT_SECRET,
  callbackURL: "http://localhost:8080/auth/google/callback"
},
function(accessToken, refreshToken, profile, done) {
    tokens = {
      google_access_token: accessToken,
      google_refresh_token: refreshToken,
    }
    return done(null, tokens);
}
));

passport.serializeUser(function(user, done) {
  done(null, user);
});

passport.deserializeUser(function(user, done) {
  done(null, user);
});

var routes = require('./routes/routes');
routes(app);

const port = process.env.PORT || 8080;
ngrok.connect({
  proto: 'http', // http|tcp|tls, defaults to http
  addr: 8080, // port or network address, defaults to 80
  region: 'eu', // one of ngrok regions (us, eu, au, ap, sa, jp, in), defaults to us
  host_header: 'rewrite',
  onStatusChange: status => {console.log("Status = " + status)}, // 'closed' - connection is lost, 'connected' - reconnected
  onLogEvent: data => {console.log("Log: " + data)}, // returns stdout messages from ngrok process
})
.then(url => {
  global.ngrokURL = url
  app.listen(port);
  console.log('App is listening on port ' + port);
})
