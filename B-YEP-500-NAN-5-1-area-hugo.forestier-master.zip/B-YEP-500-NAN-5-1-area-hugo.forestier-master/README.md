# AREA
## Installation
You need to install docker compose -> https://github.com/Yelp/docker-compose/blob/master/docs/install.md
### `Start with Docker compose`
    ``` docker-compose -f docker-compose-dev.yaml up --build ```
### `Delete all dockers`
    ``` docker rm -f $(docker ps -a -q) ```
    ```
