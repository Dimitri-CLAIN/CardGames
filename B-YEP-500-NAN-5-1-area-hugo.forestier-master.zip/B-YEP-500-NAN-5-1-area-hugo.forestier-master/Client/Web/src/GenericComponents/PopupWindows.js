import { toParams, toQuery } from './utils';

class PopupWindow {
  constructor(id, url, options = {}) {
    this.id = id;
    this.url = url;
    this.options = options;
  }

  open() {
    const { url, id, options } = this;

    this.window = window.open(url, id, toQuery(options, ','));
  }

  close() {
    this.cancel();
    this.window.close();
  }

  poll() {
    this.promise = new Promise((resolve, reject) => {
      this._iid = window.setInterval(() => {
        try {
          const popup = this.window;
          if (!popup || popup.closed !== false) {
            resolve(popup.location.href)
            this.close();
            reject(new Error('The popup was closed'));
            return;
          }

          if (popup.location.href === this.url || popup.location.pathname === 'blank') {
            return;
          }
          // if (popup.location.href.split("/")[3] === "authtwittertoken") {
          //     console.log("URL GOOD");
          //     resolve(popup.location.href)
          //     this.close();
          // }

          //const params = toParams(popup.location.hash.replace(/^#/, ''));
          resolve(popup.location.href)
          
          //this.close();
        } catch (error) {
          /*
           * Ignore DOMException: Blocked a frame with origin from accessing a
           * cross-origin frame.
           */
        }
      }, 2000);
    });
  }

  cancel() {
    if (this._iid) {
      window.clearInterval(this._iid);
      this._iid = null;
    }
  }

  listen(...args) {
    return window.location.href;
  }

  then(...args) {
    return this.promise.then(...args);
  }

  catch(...args) {
    return this.promise.then(...args);
  }

  static open(...args) {
    const popup = new this(...args);

    popup.open();
    popup.poll();

    return popup;
  }
}

export default PopupWindow;
