import React from 'react';
import "./MySwitch.css";
import Switch from 'rc-switch';
import "rc-switch/assets/index.css";

const MySwitch = (props) => {
    return (
        <div className="slider-container">
            <Switch onChange={props.onChange}
            disabled={false}
            defaultChecked={true}
            className="basic-switch"/>
        </div>
    );
}

export default MySwitch;