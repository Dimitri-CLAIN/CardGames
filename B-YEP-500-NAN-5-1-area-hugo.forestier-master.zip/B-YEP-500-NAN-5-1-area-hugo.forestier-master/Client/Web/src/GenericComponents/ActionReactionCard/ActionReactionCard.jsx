import React from 'react';
import MySwitch from '../MySwitch/MySwitch';
import "./ActionReactionCard.css"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faGithub, faTrello, faTwitter } from "@fortawesome/free-brands-svg-icons"
import {faArrowRight, faEnvelope} from "@fortawesome/free-solid-svg-icons"
import { useEffect } from 'react';

const ActionReactionCard = (props) => {
    var icons = {
        Trello: faTrello,
        Github: faGithub,
        Gmail: faEnvelope,
        Twitter: faTwitter
    }
    function onChangeActivate(toActivate) {
        if (toActivate === true) {
            console.log("Activate action")
        } else {
            console.log("Deactivate Action")
        }
    }

    useEffect(() => {
        // console.log("PROPS IN CARD =>", props)
    }, [])

    return (
        <div className="action-reaction-card-container">
            {console.log("Plateforme Action => ", props.PlatformAction)}
            {console.log("Plateforme REAction => ", props.PlatformREaction)}
            <div className="action-reaction-card-title">
                <h3>{props.infos[0].ARname}</h3>
                <MySwitch onChange={onChangeActivate}/>
            </div>
            <div className="action-reaction-card-ar">
                <div className="action-reaction-card-ar-info">
                    <FontAwesomeIcon icon={icons[props.PlatformAction]} className="ar-icon"/>
                    <p className="ar-desc">{props.infos[0].Action.name}</p>
                </div>
                <FontAwesomeIcon icon={faArrowRight} className="ar-icon" />
                <div className="action-reaction-card-ar-info" >
                    <FontAwesomeIcon icon={icons[props.PlatformREaction]} className="ar-icon"/>
                    <p className="ar-desc">{props.infos[0].REaction.name}</p>
                </div>
            </div>
        </div>
    );
}

export default ActionReactionCard;