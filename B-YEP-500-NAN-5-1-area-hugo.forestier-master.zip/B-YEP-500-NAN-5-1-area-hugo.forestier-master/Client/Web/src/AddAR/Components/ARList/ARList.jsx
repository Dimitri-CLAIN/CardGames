import React, { useState, useEffect, useContext } from 'react';
import ARCard from '../ARCard/ARCard';
import "./ARList.css";
import History from "../../../GenericComponents/History/History";
import axios from 'axios';
import { AuthContext } from '../../../GenericComponents/Auth/Auth';

const ARList = (props) => {
    const { currentUser } = useContext(AuthContext);
    const [ cards, setCards ] = useState([]);

    async function isLoggedIn(service) {
        console.log("CHEKING IF USER IS CONNECTED")
        var clientToken = undefined
        await axios.get(process.env.REACT_APP_API_URL + `/api/firebase/${currentUser.uid}/token/`)
        .then(res => {
            for (let element in res.data) {
                for (let i in res.data[element]) {
                    var connection = res.data[element][i];
                    if (connection.Type === service) {
                        console.log("USER IS LOGGED IN")
                        clientToken = connection.ClientToken;
                    }
                    console.log("USER IS NOT LOGGED IN")
                }
            }
        });
        return clientToken;
    }

    useEffect(() => {
        display()
    }, [])

    useEffect(() => {
        display()
    }, [props.whichType])

    async function handler(platform, label, neededConfig) {
        console.log("CARD ", label, " has been clicked and their config is ", neededConfig)
        var login = await isLoggedIn(platform)
        if (props.whichType === 0 && login !== undefined) {
            props.handler(4, null, neededConfig, label)
        } else if(props.whichType === 1 && login !== undefined) {
            props.handler(4, null, neededConfig, label)
        } else {
            props.handler(3, platform, neededConfig, label)
        }
    }

    function display() {
        if (props.whichType === 0) {
            axios.get(process.env.REACT_APP_API_URL + `/api/generic/link/getActions`)
            .then(res => {
                let cards = [];
                for (let card in res.data[0]) {
                    cards.push(<ARCard platform={res.data[0][card].platform} label={card} handler={handler} config={res.data[0][card].neededConfig}/>);
                }
                setCards(cards);
                return cards;
            });
        } else if (props.whichType === 1) { // call back end list de tous les REActions
            axios.get(process.env.REACT_APP_API_URL + `/api/generic/link/getREactionsFrom/${props.choosedAction}`)
            .then(res => {
                let cards = [];
                for (let card in res.data) {
                    cards.push(<ARCard platform={res.data[card].platform} label={card} handler={handler} config={res.data[card].neededConfig} />);
                }
                setCards(cards);
                return cards;
            }); // Add configuration !
        } else {
            History.push("/")
            window.location.reload()
        }
    }

    return (
        <div className="arlist-container">
            <h1>List of {!props.whichType ? "action" : "reaction"}</h1>
            <div className="arlist-card-container">
                {cards}
            </div>
        </div>
    );
}

export default ARList;