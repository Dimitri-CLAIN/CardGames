import "./CustomTextInput.css"

const CustomTextInput = (props) => {

    function saveChange(event) {
        props.variables[props.data.id].value = event.target.value
        props.updateVariables(props.variables)
    }

    return (
        <div className="custom-text-input-container">
            <h1 className="custom-text-input-label">{props.data.label}:</h1>
            <input className="custom-text-input" type="text" onChange={saveChange} placeholder={props.data.label}/>
        </div>
    );
}

export default CustomTextInput;