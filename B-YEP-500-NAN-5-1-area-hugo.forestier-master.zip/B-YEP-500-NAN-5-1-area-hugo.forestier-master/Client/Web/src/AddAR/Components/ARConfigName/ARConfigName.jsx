import React, { useState } from 'react';
import { toast } from 'react-toastify';
import { faArrowRight } from '@fortawesome/free-solid-svg-icons';
import IconButton from './../../../GenericComponents/IconButton/IconButton';
import "./ARConfigName.css"

const ARConfigName = (props) => {
    const [value, setValue] = useState(null)

    function next() {
        if (value === null) {
            toast.error("You need to fill all the fields before going to the next step")
        } else {
            props.onFinish(value)
        }
    }
    return (
        <div className="arconfigname-container">
            <h1>Name of action</h1>
            <input className="arconfigname-text-input" type="text" onChange={event => setValue(event.target.value)} placeholder={"Link name"}/>
            <IconButton className="arconfigname-next" icon={faArrowRight} size={"mid"} onClick={next} bgColor="#fff" iconColor="#000"/>
        </div>
    );
}
 
export default ARConfigName;