import React, { useState, useEffect } from 'react';
import "./ARCard.css"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faGithub, faTrello, faTwitter } from "@fortawesome/free-brands-svg-icons"
import {faArrowRight, faEnvelope} from "@fortawesome/free-solid-svg-icons"
import ARconfigs from '../ARConfig/ARConfigs';

const ARCard = (props) => {
    var icons = {
        Trello: faTrello,
        Github: faGithub,
        Gmail: faEnvelope,
        Twitter: faTwitter
    }
    const [fields, setFields] = useState([])

    function getFields() {
        var tmpFields = []
        if (props.config === undefined)
            return
        for(var i = 0; i < props.config.length; i++) {
            // console.log("NEEDED CONFIG [i] =>", props.config[i])
            if (props.config[i] === "trelloBoard") {
                tmpFields.push(ARconfigs.trello.board)
            }
            if (props.config[i] === "trelloCard") {
                tmpFields.push(ARconfigs.trello.card)
            }
            if (props.config[i] === "githubRepo") {
                tmpFields.push(ARconfigs.github.githubRepo)
            }
            if (props.config[i] === "githubIssueNumber") {
                tmpFields.push(ARconfigs.github.githubIssueNumber)
            }
            if (props.config[i] === "githubPullNumber") {
                tmpFields.push(ARconfigs.github.githubPullNumber)
            }
            if (props.config[i].includes("text")) {
                var copyField = {...ARconfigs.basic.text}
                copyField.id = props.config[i]
                copyField.label = props.config[i].split('text')[1]
                tmpFields.push(copyField)
            }
        }
        // console.log("FIELDS =>", tmpFields)
        setFields(tmpFields)
    }

    useEffect(() => {
        // console.log(props.label)
        // console.log("FOR", props.label, " PLATFORM IS ", props.platform)
        getFields()
    }, [])

    return (
        <div className="arcard-container" onClick={() => props.handler(props.platform, props.label, fields)}>
            <FontAwesomeIcon icon={icons[props.platform]} className="arcard-icon"/>
            <p className="arcard-label">{props.label}</p>
        </div>
    );
}

export default ARCard;