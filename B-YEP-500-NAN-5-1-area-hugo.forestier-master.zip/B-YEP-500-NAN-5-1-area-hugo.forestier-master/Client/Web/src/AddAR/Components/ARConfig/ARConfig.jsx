import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../../../GenericComponents/Auth/Auth';
import CustomList from '../CustomList/CustomList';
import "./ARConfig.css"
import ARconfigs from './ARConfigs';
import { faArrowRight } from '@fortawesome/free-solid-svg-icons';
import IconButton from '../../../GenericComponents/IconButton/IconButton';
import CustomTextInput from '../CustomTextInput/CustomTextInput';
import ConfigContext from '../ARConfigContext/ARConfigContext';
import { toast } from 'react-toastify';

const ARConfig = (props) => {
    const {currentUser} = useContext(AuthContext)
    const [myVariables, setMyVariables] = useState({})
    const { contextVariables, setContextVariables} = useContext(ConfigContext)

    function createList(data, variables) {
        variables[data.id] = {}
        variables[data.id].dependency = []
        variables[data.id].value = null
        variables[data.id].element = null
        if (data.toCall === true) {
            for (var i = 0; i < data.argsForCall.length; i++) {
                if (Object.keys(data.argsForCall[i])[0] === "userId") {
                    data.argsForCall.userId = currentUser.uid
                } else {
                    for (let j in ARconfigs) {
                        for (let n in ARconfigs[j]) {
                            if (ARconfigs[j][n].id === Object.keys(data.argsForCall[i])[0]) {
                                variables[data.id].dependency.push(ARconfigs[j][n].id)
                                variables = createList(ARconfigs[j][n], variables)
                            }
                        }
                    }
                }
            }
        }
        variables[data.id].element = <CustomList data={data} variables={{...variables}} updateVariables={setMyVariables}/>
        return(variables)
    }

    function createTextInput(data, variables) {
        variables[data.id] = {}
        variables[data.id].dependency = []
        variables[data.id].value = null
        variables[data.id].element = null
        variables[data.id].element = <CustomTextInput data={data} variables={{...variables}} updateVariables={setMyVariables} />
        return variables;
    }

    function getFields() {
        console.log("FIELDS =>", props.fields)
        var variables = {...contextVariables}
        for (var i = 0; i < props.fields.length; i++) {
            if (props.fields[i].type === "list") {
                variables = createList(props.fields[i], variables)
            } else if (props.fields[i].type === "text") {
                variables = createTextInput(props.fields[i], variables)
            }
        }
        setContextVariables(variables)
        setMyVariables(variables)
    }

    useEffect(() => {
        console.log("----------------------------------- IN ARCONFIG --------------------------------------")
        getFields()
        return() => {
            setContextVariables({})
        }
    }, [])

    function displayFields() {
        let display = []
        for (var i in contextVariables) {
            if (contextVariables[i].dependency.length === 0) {
                display.push(contextVariables[i].element)
            } else {
                let anyDependencyLeft = false
                for (var n = 0; n < contextVariables[i].dependency.length; n++) {
                    if (contextVariables[contextVariables[i].dependency[n]].value === null)
                        anyDependencyLeft = true
                }
                if (anyDependencyLeft === false)
                    display.push(contextVariables[i].element)
            }
        }
        return (display)
    }

    function next() {
        var someFieldNull = false
        for (var i in contextVariables) {
            if (contextVariables[i].value === null) {
                someFieldNull = true
            }
        }
        if (someFieldNull === true) {
            toast.error("You need to complete all fields before continuing to the next step")
            return;
        }
        var toReturn = {
            name: props.cardName,
            config : {},
        }
        for (var n in contextVariables) {
            toReturn.config[n] = contextVariables[n].value
        }
        console.log("TO RETURN =>", toReturn)
        props.handler(toReturn)
    }

    return (
        <div className="config-container">
            <h1>Configuration</h1>
            <div className="config-fields-container">
                {displayFields()}
            </div>
            <IconButton icon={faArrowRight} onClick={() => next()} size="mid" bgColor="#fff" iconColor="#000" className="config-next-button"/>
        </div>
    );
}

export default ARConfig;