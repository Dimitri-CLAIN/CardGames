import React, { useState, useEffect } from 'react';
import DropdownList from 'react-widgets/lib/DropdownList';
import 'react-widgets/dist/css/react-widgets.css';
import ARconfigs from './../ARConfig/ARConfigs';
import { useContext } from 'react';
import { AuthContext } from '../../../GenericComponents/Auth/Auth';
import axios from 'axios';
import "./CustomList.css";
import ConfigContext from '../ARConfigContext/ARConfigContext';

const CustomList = (props) => {
    const [isLoading, setIsLoading] = useState(true)
    const [fieldData, setfieldData] = useState([])
    const [rawData, setRawData] = useState({})
    const {currentUser} = useContext(AuthContext)
    const [defaultValue, setDefaultValue] = useState(props.variables[props.data.id].value)
    const [disabled, setDisabled] = useState(false)
    const { contextVariables, setContextVariables} = useContext(ConfigContext)

    function updateValue(value) {
        var newVars = {...contextVariables}
        for (var i in rawData) {
            if (rawData[i].name === value) {
                props.variables[props.data.id].value = rawData[i].id
                newVars[props.data.id].value = rawData[i].id
            }
        }
        setContextVariables(newVars)
        props.updateVariables(props.variables)
    }

    useEffect(() => {
        setDefaultValue(props.variables[props.data.id].value)
        if (props.variables[props.data.id].value !== null) {
            setDisabled(true)
        }
        if (props.data.toCall === true) {
            var url = props.data.callUrl
            for (var i = 0; i < props.data.argsForCall.length; i++) {
                if (Object.keys(props.data.argsForCall[i])[0] === "userId") {
                    url = url.replace(props.data.argsForCall[i][Object.keys(props.data.argsForCall[i])[0]], currentUser.uid)
                } else {
                    for (let j in ARconfigs) {
                        for (let n in ARconfigs[j]) {
                            if (ARconfigs[j][n].id === Object.keys(props.data.argsForCall[i])[0]) {
                                if (props.variables[ARconfigs[j][n].id].value !== null)
                                    url = url.replace(props.data.argsForCall[i][Object.keys(props.data.argsForCall[i])[0]], props.variables[ARconfigs[j][n].id].value)
                            }
                        }
                    }
                }
            }
            if (!url.includes(":")) {
                axios.get(process.env.REACT_APP_API_URL + url)
                .then(res => {
                    var data = []
                    for(var i in res.data) {
                        data.push(res.data[i].name)
                    }
                    setRawData(res.data)
                    setfieldData(data)
                    setIsLoading(false)
                })
            }
        }
    }, [props.data, props.variables])

    return (
        <div className="custom-list-container">
            <h1>{props.data.id}</h1>
            <DropdownList busy={isLoading} data={fieldData} onChange={updateValue} defaultValue={defaultValue} disabled={disabled}/>
        </div>
    );
}

export default CustomList;