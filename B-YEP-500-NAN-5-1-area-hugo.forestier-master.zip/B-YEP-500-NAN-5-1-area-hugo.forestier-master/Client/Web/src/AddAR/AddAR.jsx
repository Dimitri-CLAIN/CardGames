import React from 'react';
import "./AddAr.css"
import ARList from './Components/ARList/ARList';
import { useState, useContext } from 'react';
import { toast } from 'react-toastify';
import ARConfig from './Components/ARConfig/ARConfig.jsx';
import ConfigContext from './Components/ARConfigContext/ARConfigContext';
import axios from "axios";
import { AuthContext } from '../GenericComponents/Auth/Auth';
import History from '../GenericComponents/History/History';
import LoginButton from '../LoginComponent/LoginButton';
import ARConfigName from './Components/ARConfigName/ARConfigName';

const AddAr = () => {
    const [actionOrReaction, setActionOrReaction] = useState(0)
    const [serviceToLogInto, setServiceToLogInto] = useState(null)
    const [lastStep, setLastStep] = useState(null)
    const [neededConfig, setneededConfig] = useState(null)
    const [selectedAction, setSelectedAction] = useState(null)
    const [action, setAction] = useState(null)
    const [reaction, setReaction] = useState(null)
    const {currentUser} = useContext(AuthContext)
    const [alreadySent, setAlreadySent] = useState(false);
    const [linkName, setLinkName] = useState("Default Name")

    function handler(newValue, service, neededConfig, selectedCardLabel) {
        if (selectedCardLabel !== null)
            setSelectedAction(selectedCardLabel)
        if (newValue >= 3) {
            setLastStep(actionOrReaction)
        }
        if (newValue === 3) {
            setServiceToLogInto(service)
        }
        if (neededConfig !== null)
            setneededConfig(neededConfig)
        setActionOrReaction(newValue)
    }

    function createWebhook(service, action) {
        var createWebhookUrl = null;
        var body = {};
        if (service === 'Trello') {
            createWebhookUrl = `${process.env.REACT_APP_API_URL}/api/trello/createWebhookCard/${currentUser.uid}`; // TODO rendre modulable !
            var idModel = null;
            if (action.config.trelloBoardMember !== undefined) {
                idModel = action.config.trelloBoardMember;
            } else if (action.config.trelloCard !== undefined) {
                idModel = action.config.trelloCard;
            } else if (action.config.trelloBoard !== undefined)
                idModel = action.config.trelloBoard;
            body = {
                idModel: idModel,
                desc: `Webhook for ${action.name}`
            };
        }
        axios.post(createWebhookUrl, body)
        .then(res => {
            console.log(res);
        })
        .catch(err => {
            console.log(err);
            toast.error('Error while creating the webhook!');
        })

    }

    function whatToDisplay() {
        let toDisplay = []
        if (actionOrReaction < 2 && actionOrReaction >= 0) {
            toDisplay.push(<ARList whichType={actionOrReaction} handler={handler} choosedAction={selectedAction}/>)
        } else if (actionOrReaction === 3) {
            console.log("LOGING INTO ", serviceToLogInto)
            toDisplay.push(
                <LoginButton currentUser={currentUser} LoginKey={serviceToLogInto} handler={(code) => {
                    if (code === 1) {
                        if (lastStep === 0 && neededConfig === null)
                            setActionOrReaction(1)
                        else if (lastStep === 1 && neededConfig === null)
                            setActionOrReaction(5)
                        else
                            setActionOrReaction(4)
                    } else {
                        toast.error("Error while connecting to " + serviceToLogInto)
                    }
            }}/>);
        } else if (actionOrReaction === -1) {
            if (alreadySent === true) {
                return
            } else {
                setAlreadySent(true)
            }
            const params = new URLSearchParams()
                params.append('activated', true)
                params.append('action', JSON.stringify(action))
                params.append('reaction', JSON.stringify(reaction))
                params.append('arname', linkName)
            const config = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                }
            }
            createWebhook("Trello", action)
            var url = process.env.REACT_APP_API_URL + `/api/generic/link/create/${currentUser.uid}`
            async function saveLink() {
                try {
                    // Success 🎉
                    const response = await axios.post(url, params, config);
                    // console.log(response);
                    History.push("/")
                    window.location.reload()
                } catch (error) {
                    // Error 😨
                    // console.log(error);
                    toast.error("Error while creating the action reaction. Try again in a few minutes");
                    History.push("/");
                    window.location.reload()
                }
            }
            saveLink()

        } else if (actionOrReaction === 4) {
            toDisplay.push(
                <ARConfig fields={neededConfig} cardName={selectedAction} handler={(data) => {
                    if (lastStep === 0) {
                        setActionOrReaction(1)
                        setAction(data)
                    } else if (lastStep === 1) {
                        setActionOrReaction(5)
                        setReaction(data)
                    }
                }}/>
            )
        } else if (actionOrReaction === 5) {
            toDisplay.push(
                <ARConfigName onFinish={value => {
                    setLinkName(value)
                    setActionOrReaction(-1)
                }} />
            )
        }
        return (toDisplay)
    }

    const [contextVariables, setContextVariables] = useState({});
    const value = { contextVariables, setContextVariables };

    return (
        <div className="addar-container">
            <ConfigContext.Provider value={value}>
                {whatToDisplay()}
            </ConfigContext.Provider>
        </div>
    );
}

export default AddAr;
