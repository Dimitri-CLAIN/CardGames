import TrelloClient, { Trello } from 'react-trello-client';

const TrelloLogin = ({ success, failure }) => {
        return(
            <TrelloClient
            apiKey="3078e1294a43c6ac75348ecf15dce4cf"
            clientVersion={1}
            apiEndpoint="https://api.trello.com"
            authEndpoint="https://trello.com"
            intentEndpoint="https://trello.com"
            authorizeName="React Trello Client"
            authorizeType="popup"
            authorizePersist={true}
            authorizeInteractive={true}
            authorizeScopeRead={false}
            authorizeScopeWrite={true}
            authorizeScopeAccount={true}
            authorizeExpiration="never"
            authorizeOnSuccess={() => success(Trello.token())}
            authorizeOnError={(err) => failure(err)}
            autoAuthorize={false}
            authorizeButton={true}
            buttonStyle="metamorph"
            buttonColor="green"
            buttonText="Login with Trello"
            />
        );
}

export default TrelloLogin;