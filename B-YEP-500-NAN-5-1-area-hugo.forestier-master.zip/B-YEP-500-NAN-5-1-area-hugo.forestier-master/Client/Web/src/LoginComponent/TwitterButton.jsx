// import NewWindow from 'rc-new-window';
import Popout from 'react-popout'
import React from 'react';
import axios from 'axios';
import { AuthContext } from '../GenericComponents/Auth/Auth';

class TwitterButton extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          showComponent: false,
        };
        this._onButtonClick = this._onButtonClick.bind(this);
        this._onClosePopup = this._onClosePopup.bind(this);
    }

    _onButtonClick() {
        this.setState({
          showComponent: true,
        });
    }

    _onClosePopup () {
        this.setState({showComponent: false});
    }

    render() {
        return (
            <div>
                <button onClick={this._onButtonClick}>Login to Twitter</button>
                {this.state.showComponent ? <PopupCmp success={this.props.success} failure={this.props.failure} closePopup={this._onClosePopup}/> : null}
            </div>
        )
    }
}

class PopupCmp extends React.Component {
  static contextType = AuthContext;
    constructor(props) {
        super(props);
        this.popout = this.popout.bind(this);
        this.popoutClosed = this.popoutClosed.bind(this);
        this.state = { isPoppedOut: false };
      }

      async isLoggedIn(service) {
        const {currentUser} = this.context;
        var clientToken = undefined
        await axios.get(process.env.REACT_APP_API_URL + `/api/firebase/${currentUser.uid}/token/`)
        .then(res => {
            for (let element in res.data) {
                for (let i in res.data[element]) {
                    var connection = res.data[element][i];
                    if (connection.Type === service) {
                        clientToken = connection.ClientToken;
                    }
                }
            }
        });
        return clientToken;
      }
      popout() {
        this.setState({isPoppedOut: true});
      }
      async popoutClosed() {
        this.setState({isPoppedOut: false});
        this.props.closePopup()
        var userToken = await this.isLoggedIn("Twitter");
        if (userToken)
          this.props.success();
        else {
          this.props.failure("USER IS NOT LOGGED IN");
        }
      }

      render() {
        var popup = <Popout url={`${process.env.REACT_APP_API_URL}/auth/twitter`} title='Login to twitter' onClosing={this.popoutClosed} >
                      <div>Redirecting to Twitter.</div>
                    </Popout>
          return (
            popup
          );
      }
}

export default TwitterButton;