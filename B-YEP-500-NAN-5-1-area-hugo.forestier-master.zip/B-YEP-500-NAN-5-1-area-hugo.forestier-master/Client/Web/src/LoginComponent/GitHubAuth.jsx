import GitHubLogin from 'github-login';
import axios from 'axios';
import { toast } from 'react-toastify';

const GitHubAuth = ({ success, failure }) => {
    var clientId = "80b5848ec7a4c1a8e63a";

    var onSuccess = (data) => {
        axios.post(`${process.env.REACT_APP_API_URL}/api/github/auth`, {
            code: data.code
        })
        .then(res => {
            success(res.data);
        }).catch(err => {
            console.log(err);
            toast.error('Error while connecting to GitHub!');
        });
    }
    var onFailure = (err) => {
        failure(err);
    }
    return(
        <GitHubLogin
        clientId={clientId}
        redirectUri="http://localhost:8081/"
        scope={"repo, admin:repo_hook, admin:org, admin:ublic_key, gist, notifications, user, delete_repo, write:discussion, write:packages, read:packages, delete:packages, admin:gpg_key, workflow"}
        onSuccess={onSuccess}
        onFailure={onFailure}/>
    );
}

export default GitHubAuth;