import { GoogleLogin } from 'react-google-login';

const GoogleButton = ({success, failure}) => {
    var onSuccess = (response) => {
        if (response.tokenObj.access_token !== undefined) {
             success(response.tokenObj.access_token);
        }
    }

    var onFailure = (response) => {
        failure(response.error);
    }
    return(
        <GoogleLogin
            clientId={process.env.REACT_APP_GOOGLE_CLIENT_ID}
            buttonText="Login"
            onSuccess={onSuccess}
            onFailure={onFailure}
            cookiePolicy={'single_host_origin'}
            scope={"https://www.googleapis.com/auth/gmail.send"}
        />
    );
}

export default GoogleButton;
