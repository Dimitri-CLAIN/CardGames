import { useState, useEffect } from 'react';
import axios from 'axios';
import TrelloLogin from './TrelloLogin';
import GitHubAuth from './GitHubAuth';
import GoogleButton from './GoogleButton';
import TwitterButton from './TwitterButton';

const LoginButton = ({currentUser, LoginKey, handler}) => {
    var [button, setButton] = useState(null);

    useEffect(() => {
        if (LoginKey === "Trello") {
            setButton(<TrelloLogin success={onSuccess} failure={onFailure} />);
        } else if (LoginKey === "Github") {
            setButton(<GitHubAuth success={onSuccess} failure={onFailure} />);
        } else if (LoginKey === "Gmail") {
            setButton(<GoogleButton success={onSuccess} failure={onFailure} />);
        } else if (LoginKey === "Twitter") {
            setButton(<TwitterButton success={onSuccess} failure={onFailure}/>);
        }
    }, [LoginKey]);

    var onSuccess = (token) => {
        if (token) {
            axios.post(`${process.env.REACT_APP_API_URL}/api/firebase/${currentUser.uid}/token/`, {
                type: LoginKey,
                clientToken: token
            });
        }
        console.log("TESTING ON SUCCESS");
        handler(1);
    }

    var onFailure = (error) => {
        handler(-1);
    }

    return (
        <div>
            {button}
        </div>
    )
}

export default LoginButton;
