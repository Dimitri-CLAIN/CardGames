import React, { Component } from 'react';
import axios from 'axios';
import { AuthContext } from '../GenericComponents/Auth/Auth';



class TwitterInfos extends Component {
    static contextType = AuthContext;
    SaveToken = () => {
        const {currentUser} = this.context;
        var location = window.location.href;
        location = location.split("/")
        if (location.length === 6) {
            axios.post(`${process.env.REACT_APP_API_URL}/api/firebase/${currentUser.uid}/token/`, {
                type: "Twitter",
                clientToken: location[4],
                clientSecret: location[5]
            });
        }
    }

    render() {
      return (
        <div>
            {this.SaveToken()}
            <p>Successfully connected to Twitter.
                You can now close this window.</p>
        </div>
        );
    }
}

export default TwitterInfos;