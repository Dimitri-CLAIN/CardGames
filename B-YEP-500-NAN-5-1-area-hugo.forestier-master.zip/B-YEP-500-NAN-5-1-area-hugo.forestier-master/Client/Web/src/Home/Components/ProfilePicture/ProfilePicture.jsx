import React, { useEffect, useRef } from 'react';
import "./ProfilePicture.css"
import { AuthContext } from '../../../GenericComponents/Auth/Auth';
import { useContext } from 'react';
import { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {faEdit} from '@fortawesome/free-solid-svg-icons'
import { toast } from 'react-toastify';
import firebase from "firebase/app";
import "firebase/storage";

const ProfilePicture = () => {
    const {currentUser} = useContext(AuthContext);
    const [profilePicUrl, setProfilePicUrl] = useState(process.env.PUBLIC_URL + "/defaultProfilePic.png")
    const inputFile = useRef(null)

    useEffect(() => {
        if (currentUser.photoURL !== null) {
            setProfilePicUrl(currentUser.photoURL)
        }
      }, [])

    function uploadPicture() {
        inputFile.current.click();
    }

    async function fileHandler(event) {
        let reader = new FileReader()
        reader.readAsDataURL(event.target.files[0])
        reader.onload = () => {
            setProfilePicUrl(reader.result)
        }
        const storage = firebase.storage()
        .then( () => {
            storage
                .ref("images")
                .child(event.target.files[0].name)
                .getDownloadURL()
                .then(url => {
                    currentUser.updateProfile({
                        photoURL: url
                    })
                    .then(() => {
                        toast.success("Profile picture changed successfully !")
                    })
                });
        })
    }

    return (
        <div className="profile-picture-container">
            <img src={profilePicUrl} alt="profilePicture" className="profile-picture"/>
            <div className="profile-picture-edit-container" onClick={uploadPicture}>
                <FontAwesomeIcon icon={faEdit} className="profile-picture-edit"/>
            </div>
            <input type='file' id='file' ref={inputFile} style={{display: 'none'}} onChange={fileHandler}/>
        </div>
    );
}

export default ProfilePicture;