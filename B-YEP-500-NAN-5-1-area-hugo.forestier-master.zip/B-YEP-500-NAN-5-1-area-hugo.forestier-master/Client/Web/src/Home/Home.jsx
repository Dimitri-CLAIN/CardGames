import React from 'react';
import "./Home.css";
import app from '../base';
import axios from "axios";
import { AuthContext } from '../GenericComponents/Auth/Auth';
import { useContext, useState } from 'react';
import ProfilePicture from './Components/ProfilePicture/ProfilePicture';
import ActionReactionCard from '../GenericComponents/ActionReactionCard/ActionReactionCard';
import IconButton from '../GenericComponents/IconButton/IconButton';
import { faPlus, faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
import History from "../GenericComponents/History/History"
import { useEffect } from 'react';

const Home = () => {
    const [ cards, setCards ] = useState([]);
    const {currentUser} = useContext(AuthContext);

    useEffect(() => {
        displayCards();
    }, [])

    async function displayCards() {
        var link = await axios.get(process.env.REACT_APP_API_URL + '/api/generic/link/get', {
            params: {
                id: currentUser.uid
            }
        })
        let cards = [];
        for (let card in link.data) {
            console.log("card and action", link.data[card][0].Action.name, link.data[card])
            var platformAction = await axios.get(process.env.REACT_APP_API_URL + '/api/generic/link/getPlatformAction', {
                params: {
                    action: link.data[card][0].Action.name
                }
            });
            var platformREaction = await axios.get(process.env.REACT_APP_API_URL + '/api/generic/link/getPlatformREaction', {
                params: {
                    reaction: link.data[card][0].REaction.name
                }
            });

            cards.push(
                <ActionReactionCard PlatformAction={platformAction.data} PlatformREaction={platformREaction.data} infos={link.data[card]}/>
            );
        }
        setCards(cards);
        console.log(cards);
    }

    function addAction(params) {
        History.push("/addlink")
        window.location.reload()
    }

    return (
        <div className="home-container">
            <div className="profile-infos-container">
                <ProfilePicture />
                <p className="profile-name">{currentUser.email.split('@')[0]}</p>
            </div>
            <div className="home-action-cards-container">
                {cards}
            </div>
            <IconButton icon={faPlus} onClick={addAction} size="mid" bgColor="#fff" iconColor="#000" className="add-action-button"/>
            <IconButton icon={faSignOutAlt} onClick={() => app.auth().signOut()} size="mid" bgColor="#fff" iconColor="#FF5F58" className="logout-button"/>
        </div>
    );
}

export default Home;
