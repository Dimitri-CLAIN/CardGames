//import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Route, Switch, Redirect} from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import Page404 from './Page404/Page404';
import PrivateRoute from './GenericComponents/PrivateRoute/PrivateRoute';
import Home from './Home/Home';
import Login from './Login/Login';
import Signup from './Signup/Signup';
import 'react-toastify/dist/ReactToastify.css';
import { AuthProvider } from './GenericComponents/Auth/Auth';
import AddAr from './AddAR/AddAR';
import History from "./GenericComponents/History/History";
import TwitterInfos from './LoginComponent/TwitterInfos'

function App() {
  return (
    <div>
      <ToastContainer />
      <AuthProvider>
        <ToastContainer />
        <Router history={History}>
          <Switch>
            <PrivateRoute exact path="/" component={Home} />
            <PrivateRoute exact path="/addlink" component={AddAr} />
            <Route path="/authtwittertoken/" component={TwitterInfos} />
            <Route exact path="/login" component={Login} />
            <Route exact path="/signup" component={Signup} />
            <Route exact path="/404" component={Page404} />
            <Redirect to="/404" />
          </Switch>
        </Router>
      </AuthProvider>
    </div>
  );
}

export default App;
