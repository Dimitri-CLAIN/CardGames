import React, { useCallback, useContext } from "react";
import { withRouter, Redirect } from "react-router";
import app from "../base.js";
import "./Login.css"
import { AuthContext } from '../GenericComponents/Auth/Auth';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import firebase from 'firebase';

const Login = ({ history }) => {
  const handleGoogleLogin = useCallback(
    async event => {
      event.preventDefault();
      var provider = new firebase.auth.GoogleAuthProvider();
      try {
        await app
          .auth()
          .signInWithPopup(provider)
        history.push("/");
      } catch (error) {
        alert(error);
      }
    },
    [history]
  );
  const handleLogin = useCallback(
    async event => {
      event.preventDefault();
      const { email, password } = event.target.elements;
      try {
        await app
          .auth()
          .signInWithEmailAndPassword(email.value, password.value);
        history.push("/");
      } catch (error) {
        alert(error);
      }
    },
    [history]
  );

  const { currentUser } = useContext(AuthContext);

  if (currentUser) {
    return <Redirect to="/" />;
  }

  return (
    <div className="background-image" style={{ backgroundImage: "url(/mountains.jpg)" }}>
      <div className="container-login">
        <img className="area-logo" src={process.env.PUBLIC_URL + '/area-logo/vector/default-monochrome-white.svg'} alt="logo" />
        <h3 className="login-text">Login Now.</h3>
          <form onSubmit={handleLogin}>
            <div className="font-email">
              <input className="email-login" name="email" type="email" placeholder="Email" />
              <i><FontAwesomeIcon icon="envelope" color="white" size="sm" opacity="50%"/></i>
            </div>
            <div className="font-password">
              <input className="password-login" name="password" type="password" placeholder="Password" />
              <i><FontAwesomeIcon icon="lock" color="white" size="sm" opacity="50%"/></i>
            </div>
            <p id="message-create-account">Don't have an account ? <a href="/signup">Create one</a></p>
            <button className="button-login" type="submit">LOGIN</button>
            <hr className="separator"/>
            <h3 className="login-google-text">Or Login With</h3>
            <div className="button-google" onClick={handleGoogleLogin}><img className="google-image" src={process.env.PUBLIC_URL + '/google-icon.png'} alt="logo" /></div>
            {/* <img className="area-montains" src={process.env.PUBLIC_URL + '/area-logo/vector/montagne.svg'} alt="logo" /> */}
        </form>
      </div>
    </div>
  );
};

export default withRouter(Login);
