import React, { useCallback } from "react";
import { withRouter } from "react-router";
import app from "../base";
import "./Signup.css"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'

const SignUp = ({ history }) => {
  const handleSignUp = useCallback(async event => {
    event.preventDefault();
    const { email, password } = event.target.elements;
    try {
      await app
        .auth()
        .createUserWithEmailAndPassword(email.value, password.value);
      history.push("/");
    } catch (error) {
      alert(error);
    }
  }, [history]);


  return (
    <div className="background-image" style={{ backgroundImage: "url(/mountains.jpg)" }}>
      <div className="container-register">
        <img className="area-logo" src={process.env.PUBLIC_URL + '/area-logo/vector/default-monochrome-white.svg'} alt="logo" />
        <h3 className="register-text">Register Now.</h3>
        <form onSubmit={handleSignUp}>
            <div className="font-email">
              <input className="email-register" name="email" type="email" placeholder="Email" />
              <i><FontAwesomeIcon icon="envelope" color="white" size="sm" opacity="50%"/></i>
            </div>
            <div className="font-password">
              <input className="password-register" name="password" type="password" placeholder="Password" />
              <i><FontAwesomeIcon icon="lock" color="white" size="sm" opacity="50%"/></i>
            </div>
            <div className="font-password">
              <input className="conf-password-register" name="password-confirmation" type="password" placeholder="Password Confirmation" />
              <p id="message-already-have-account">Already have an account ? <a href="/login">Login Here</a></p>
              <i><FontAwesomeIcon icon="lock" color="white" size="sm" opacity="50%"/></i>
            </div>
          <button className="button-register" type="submit">CREATE ACCOUNT</button>
          <img className="area-montains" src={process.env.PUBLIC_URL + '/area-logo/vector/montagne.svg'} alt="logo" />
        </form>
      </div>
    </div>
  );
};

export default withRouter(SignUp);