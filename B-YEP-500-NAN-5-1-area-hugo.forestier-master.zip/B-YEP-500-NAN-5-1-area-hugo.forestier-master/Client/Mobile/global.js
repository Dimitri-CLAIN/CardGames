module.export = {
    user: null,
    googleSignIn: false,
    ip: '',
};