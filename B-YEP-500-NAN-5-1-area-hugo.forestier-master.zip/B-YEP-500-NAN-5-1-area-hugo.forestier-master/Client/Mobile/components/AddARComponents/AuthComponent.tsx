import * as React from 'react';
import { Button } from 'react-native';
import { WebView } from 'react-native-webview';
import { View } from '../../components/Themed';

import { LoginContext } from "../../Context/contextLogin.js";

import {useContext, useEffect, useState, Component} from 'react';
import axios from "axios";
import GLOBAL from '../../global.js'

export const AuthComponent = (props) => {
    let WebViewRef;
    const [ displayUrl, setDisplayUrl ] = useState('https://google.com');
    const { Login_data, update_Tokens } = useContext(LoginContext);
    const [ stopLoding, setStopLoding ] = useState(false);
    const [ code, setCode ] = useState('');
    const [ state, setState ] = useState('');
    const [ token, setToken ] = useState('');
    const [ verifier, setVerifier ] = useState('');
    const [webviewKey, setWebviewKey] = useState(0)

    const config = () => {
        if (!stopLoding) {
            console.log("LOGIN KEY =>", props.loginKey)
            var id = -1;
            if (props.loginKey == 'Trello') {
                id = 0;
            } else if (props.loginKey == 'Github') {
                // console.log('hey')
                id = 1;
            } else if (props.loginKey == 'Twitter') {
                setDisplayUrl("http://" + GLOBAL.ip + ":8080/auth/twitter");
                id = 3;
            } else if (props.loginKey == 'Google') {
                console.log("IN GOOGLE")
                setDisplayUrl("http://" + GLOBAL.ip + ":8080/auth/google");
                id = 4;
            }
            var params = new URLSearchParams;
            if (Login_data[id] !== undefined) {
                for (let arg in Login_data[id].args) {
                    params.append(arg, Login_data[id].args[arg]);
                }
                if (id < 3) {
                    console.log("IN ID < 3")
                    setDisplayUrl(Login_data[id].url + params.toString());
                }
            }
            WebViewRef.reload();
        }
    };

    useEffect(() => {
        config()
    }, []);

    // useEffect(()=> {
    //     config();
    // }, [displayUrl])

    useEffect(() => {
        if (token != '') {
            // console.log('hum')
            update_Tokens(props.loginKey, token);
            var params = new URLSearchParams;
            params.append('type', props.loginKey);
            params.append('clientToken', token);
            if (props.loginKey === 'Twitter')
                params.append('clientSecret', verifier);
            axios.post("http://" + GLOBAL.ip + `:8080/api/firebase/${GLOBAL.user.uid}/token/`, params)
                .catch((error) => {
                    console.log(error, "error 1");
                    // props.handler(0);
                })
            props.handler(1);
        }
    }, [token])

    const handleUrl = (syntheticEvent) => {
        const { nativeEvent } = syntheticEvent;
        const  url = nativeEvent.url;
        if (!url || url === 'about:blank') return;
        // console.log(url, 'url')

        if (!stopLoding) {
            if ((url.includes("http://localhost:8081/") || url.includes("http://localhost:8080/")) && !url.includes("return_url=http://localhost:8081/") && !url.includes("redirect_uri=http://localhost:8081/") && !url.includes("redirect_uri=http://localhost:8080/")) {
                WebViewRef.clearFormData();
                WebViewRef.clearCache();
                setDisplayUrl('');
                WebViewRef.reload();
                // if (props.loginKey == 'Trello') {
                //     var params = url.split('#');
                //     if (params[1]) {
                //         var tokenArg = params[1].split('=');
                //         // console.log(tokenArg)
                //         if (tokenArg[0] === 'token' && tokenArg[1]) {
                //             setToken(tokenArg[1]);
                //             WebViewRef.stopLoading();
                //             setStopLoding(true);
                //             return;
                //         }
                //     }
                // } else if (props.loginKey == 'Github') {
                //     var args = url.split('?')[1];
                //     if (args !== undefined) {
                //         var args = args.split('&');
                //         // console.log(args, 'args');
                //         if (args[1]) {
                //             var codeArg = args[0].split('=');
                //             var stateArg = args[1].split('=');
                //             if (codeArg[0] === 'code' && stateArg[0] === 'state')
                //                 setCode(codeArg[1]);
                //             setState(stateArg[1]);
                //             if (code && state) {
                //                 var params = new URLSearchParams;
                //                 for (let arg in Login_data[2].args) {
                //                     params.append(arg, Login_data[2].args[arg]);
                //                 }
                //                 params.append('code', code);
                //                 params.append('state', state);
                //                 axios.post(Login_data[2].url, params)
                //                     .then((res) => {
                //                         args = res.data.split('&')
                //                         for (let i = 0; i < args.length; i++) {
                //                             let arg = args[i].split('=');
                //                             if (arg[0] == 'access_token') {
                //                                 setToken(arg[1]);
                //                             }
                //                         }
                //                     })
                //                     .catch((error) => {
                //                         console.log(error.message, "Error Message")
                //                         props.handle(0);
                //                     });
                //                 setStopLoding(true);
                //                 WebViewRef.stopLoading();
                //                 return;
                //             }
                //         }
                //     }
                // } else if (props.loginKey == 'Twitter') {
                //     // if (url.includes("localhost")) {
                //     //     var tmp = url
                //     //     tmp.replace("localhost", GLOBAL.ip)
                //     //     console.log(tmp)
                //     //     setDisplayUrl(tmp)
                //     // }
                //     // var args = url.split('?')[1];
                //     // if (args !== undefined) {
                //     //     var params = args.split('&');
                //     //     if (params.length === 2) {
                //     //         var tokenArg = params[0].split('=')
                //     //         var verifierArg = params[1].split('=')
                //     //         if (tokenArg[0] === 'oauth_token' && verifierArg[0] === 'oauth_verifier') {
                //     //             setVerifier(verifierArg[1])
                //     //             setToken(tokenArg[1]);
                //     //             setStopLoding(true);
                //     //             WebViewRef.stopLoading();
                //     //             return;
                //     //         }
                //     //     }
                //     // }
                //     if (url.includes("/authtwittertoken/")) {
                //         WebViewRef.stopLoading()
                //         setStopLoding(true);
                //     }
                // } else if (props.loginKey == "Google") {
                //     if (url.includes("/googleauth/")) {
                //         WebViewRef.stopLoading()
                //         setStopLoding(true);
                //     }
                // }
            }
        }
    }

    useEffect(() => {
        console.log("DISPLAY URL =>", displayUrl)
        if (displayUrl === "" || displayUrl === null || displayUrl === undefined)
            WebViewRef.reload()
    }, [displayUrl]);

    const parseToken = (url) => {
        console.log("IN PARSE TOKEN URL =>", url)
        WebViewRef.stopLoading()
        setStopLoding(true);
        if (props.loginKey === 'Google') {
            var tmp = url.split('googleauth/')[1]
            tmp = tmp.slice(0, -1)
            setToken(tmp)
        }
        if (props.loginKey === 'Twitter') {
            var tmp = url.split('authtwittertoken')[1].split('/')
            console.log("TWITTER TOKENS =>", tmp)
            setVerifier(tmp[2])
            setToken(tmp[1])
        }
        if (props.loginKey === 'Trello') {
            setToken(url.split("#token=")[1])
        }
        if (props.loginKey === 'Github') {
            var code = url.split("?code=")[1].split("&")[0]
            console.log("IN CODE URL =>", code)
            const body = {
                code: code
            }
            axios.post('http://' + GLOBAL.ip + ':8080/api/github/auth', body)
            .then(res => {
                console.log("GITHUB TOKEN =>", res.data)
                // alert("GITHUB TOKEN = " + res.data)
                if (res.data != "bad_verification_code") {
                    setToken(res.data)
                }
            })
            .catch(e => console.log(e))
        }
    }

    const errorManagement = (syntheticEvent) => {
        console.log("--------------------------------------------------------------------------------------")
        console.log("IN ERROR MANAGEMENT")
        const { nativeEvent } = syntheticEvent;
        var url = nativeEvent.url
        console.log("TRYING TO GO TO", url)
        if (url.includes("localhost") && !displayUrl.includes(GLOBAL.ip) && ((props.loginKey === 'Twitter') || (props.loginKey === 'Google'))) {
            var tmp = url;
            tmp = tmp.replace("localhost", GLOBAL.ip);
            console.log("TMP =>", tmp);
            setDisplayUrl(tmp);
            WebViewRef.reload();
        }
        if (url.includes("/googleauth/") || url.includes("/authtwittertoken/") || url.includes("#token") || url.includes("http://localhost:8081/?code=")) {
            parseToken(url);
        }
    }

    return (
        <WebView
            key={ webviewKey }
            userAgent={"thisisauseragent"}
            style={{ height: '100%',  width: '100%'}}
            ref={(r) => (WebViewRef = r)}
            startInLoadingState={true}
            onLoad={handleUrl}
            source={{uri :displayUrl}}
            isSignedIn={true}
            uxMode='redirect'
            onLoadStart={errorManagement}
            onError={errorManagement}
            onRenderProcessGone={errorManagement}
            onHttpError={errorManagement}
        />
    );
}
