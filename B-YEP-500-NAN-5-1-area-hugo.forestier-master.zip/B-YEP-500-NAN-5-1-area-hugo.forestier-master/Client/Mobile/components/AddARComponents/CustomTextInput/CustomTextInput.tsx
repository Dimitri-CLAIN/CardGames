import * as React from 'react';
import { TextInput } from "react-native-gesture-handler";

const CustomTextInput = (props) => {

    function saveChange(text) {
        props.variables[props.data.id].value = text
        props.updateVariables(props.variables)
    }

    return (
        <TextInput
            style={{
                borderRadius: 10,
                textAlign: 'center',
                margin: 15,
                height: 40,
                borderColor: 'grey',
                backgroundColor: 'grey',
                color: 'white',
                borderWidth: 1,
            }}
            onChangeText={saveChange}
            placeholder={props.data.id}
            placeholderTextColor='lightgrey'
        />
    );
}
 
export default CustomTextInput;