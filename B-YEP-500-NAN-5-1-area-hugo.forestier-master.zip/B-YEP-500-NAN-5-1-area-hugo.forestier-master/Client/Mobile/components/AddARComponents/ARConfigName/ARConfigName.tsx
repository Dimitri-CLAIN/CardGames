import React, { useState } from 'react';

import {Image, TouchableOpacity} from 'react-native';
import { TextInput } from 'react-native-gesture-handler';

import { StylesARConfigName } from "./StylesARConfigName";
import { View, Text } from '../../Themed';

const ARConfigName = (props) => {
    const [name, setName] = useState(null)

    function next() {
        if (name === null) {
            console.error("You need to fill all the fields before going to the next step")
        } else {
            props.onFinish(name)
        }
    }
    return (
        <View style={StylesARConfigName.arConfigNameContainer}>
            <Text style={StylesARConfigName.arConfigTitle}>Name of action</Text>
            <TextInput
                style={StylesARConfigName.arConfigNameTextInput}
                placeholder="Link Name"
                placeholderTextColor='lightgrey'
                onChangeText={text => {if (text != name) setName(text)}}
                value={name}
            />
            <TouchableOpacity style={StylesARConfigName.arConfigNameNext} onPress={next}>
                <Image style={[{ width: 25, height: 25 }]} source={require('../../../images/arrow-right.png')}/>
            </TouchableOpacity>
        </View>
    );
}

export default ARConfigName;