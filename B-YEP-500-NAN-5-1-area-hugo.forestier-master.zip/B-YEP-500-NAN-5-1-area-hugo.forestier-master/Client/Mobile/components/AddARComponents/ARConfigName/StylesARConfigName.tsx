import { StyleSheet } from 'react-native';

export const StylesARConfigName = StyleSheet.create({
    arConfigNameContainer: {
        width: '100%',
        height: '100%',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#202020',
        color: 'white',
    },
    arConfigNameNext: {
        borderRadius: 10,
        paddingTop: 10,
        paddingBottom: 10,
        paddingRight: 8,
        paddingLeft: 10,
        backgroundColor: 'white',
        marginTop: 10,
        color: 'white',
    },
    arConfigTitle: {
        fontSize: 20,
        color: 'white',
        fontWeight: 'bold',
    },
    arConfigNameTextInput: {
        marginTop: 10,
        borderRadius: 10,
        color: 'white',
        backgroundColor: 'grey',
        textAlign: 'center',
        justifyContent: 'center',
        width: '60%',
        fontSize: 15,
    },
});