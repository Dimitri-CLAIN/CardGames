import { StyleSheet } from 'react-native';

export const StylesCustomList = StyleSheet.create({
    customListContainer: {
        width: '100%',
        marginTop: 37,
        backgroundColor: '#202020',
    },
    dropdownContainer: {
        borderWidth: 1,
        marginVertical: 15,
        borderRadius: 10,
        margin: 15,
        padding: 10,
        textAlign: 'center',
        borderColor: 'grey',
        color: 'black',
    }
});