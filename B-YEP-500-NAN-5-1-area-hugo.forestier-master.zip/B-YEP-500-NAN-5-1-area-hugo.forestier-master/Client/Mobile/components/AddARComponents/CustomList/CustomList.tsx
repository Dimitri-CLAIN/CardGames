import React, { useState, useEffect } from 'react';

import { Picker } from 'react-native';

import { View, Text } from '../../Themed';

import { StylesCustomList } from './StylesCustomList';

import ARconfigs from '../ARConfig/ARConfigs.js';
import { useContext } from 'react';
import GLOBAL from '../../../global.js';
import axios from 'axios';
import ConfigContext from '../ARConfigContext/ARConfigContext.js';

const CustomList = (props) => {
    const [isLoading, setIsLoading] = useState(true)
    const [fieldData, setfieldData] = useState([''])
    const [rawData, setRawData] = useState({})
    const currentUser = GLOBAL.user;
    const [defaultValue, setDefaultValue] = useState(props.variables[props.data.id].value)
    const [disabled, setDisabled] = useState(false)
    const {contextVariables, setContextVariables} = useContext(ConfigContext)
    const [index, setIndex] = useState(-1);

    function updateValue(id) {
        if (id == -1)
            return;
        var value = fieldData[id]
        setIndex(id);

        var newVars = {...contextVariables}
        for (var i in rawData) {
            if (rawData[i].name === value) {
                props.variables[props.data.id].value = rawData[i].id
                newVars[props.data.id].value = rawData[i].id
            }
        }
        setContextVariables(newVars)
        props.updateVariables(props.variables)
    }

    useEffect(() => { const temp = async () => {
            setIndex(-1);
            setDefaultValue(props.variables[props.data.id].value)
            if (props.data.toCall === true) {
                var url = props.data.callUrl
                for (var i = 0; i < props.data.argsForCall.length; i++) {
                    if (Object.keys(props.data.argsForCall[i])[0] === "userId") {
                        url = url.replace(props.data.argsForCall[i][Object.keys(props.data.argsForCall[i])[0]], currentUser.uid)
                    } else {
                        for (let j in ARconfigs) {
                            for (let n in ARconfigs[j]) {
                                if (ARconfigs[j][n].id === Object.keys(props.data.argsForCall[i])[0]) {
                                    if (props.variables[ARconfigs[j][n].id].value !== null)
                                        url = url.replace(props.data.argsForCall[i][Object.keys(props.data.argsForCall[i])[0]], props.variables[ARconfigs[j][n].id].value)
                                }
                            }
                        }
                    }
                }
                if (!url.includes(":")) {
                    try {
                        var res = await axios.get("http://" + GLOBAL.ip + ':8080' + url)
                        var data = []
                        for (var i in res.data) {
                            data.push(res.data[i].name)
                        }
                        setRawData(res.data)
                        setfieldData(data)
                        setIsLoading(false)
                        if (props.variables[props.data.id].value !== null) {
                            setDisabled(true)
                            let id = 0
                            for (let arg in res.data) {
                                var item = res.data[arg].id;
                                if (item == props.variables[props.data.id].value) {
                                    setIndex(id);
                                }
                                id += 1;
                            }
                        }

                    } catch(e) {
                        console.log(e)
                    }
                }
            }
        }
        temp();
    }, [props.data, props.variables])

    const list = () => {
        const array = fieldData.map((item, index) => {
            return (
                <Picker.Item label={item} value={index}/>)
        })
        array.unshift(<Picker.Item label={'Selected an element'} value={-1}/>)
        return (array);
    }

    return (
        <View style={StylesCustomList.customListContainer}>
            <Text>{props.data.ip}</Text>
            <View style={[StylesCustomList.dropdownContainer, disabled ? { backgroundColor: 'grey' } : { backgroundColor: 'lightgrey' }]}>
                <Picker
                    enabled={!disabled}
                    style={!disabled ? { color: 'black' } : { color: 'lightgrey' }}
                    selectedValue={index}
                    onValueChange={updateValue}
                >
                    {list()}
                </Picker>
            </View>
        </View>
    );
}
 
export default CustomList;