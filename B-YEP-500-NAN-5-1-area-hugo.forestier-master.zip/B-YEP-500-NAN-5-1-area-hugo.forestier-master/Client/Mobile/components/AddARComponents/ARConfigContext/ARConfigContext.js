import React from "react";

const ConfigContext = React.createContext({
    contextVariables: {},
    setContextVariables: () => {}
});

export default ConfigContext;
