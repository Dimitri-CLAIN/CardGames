import { StyleSheet } from 'react-native';

export const StylesAddAR = StyleSheet.create({
    container: {
        marginTop: 37,
        height: '100%',
        backgroundColor: '#202020',
    },
    buttonStyle: {
        alignSelf: 'flex-start',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white',
        margin: 15,
        borderRadius: 10,
        padding: 10,
        borderColor: 'grey',
        borderWidth: 1,
    },
    buttonView: {
        backgroundColor: '#202020',
        flexDirection: 'row'
    },
});
