import { StyleSheet } from 'react-native';

export const StylesARCard = StyleSheet.create({
    arcardContainer: {
        padding: 10,
        flexDirection: 'row',
        alignItems: 'center',
        color: 'white',
        borderRadius:  10,
        paddingVertical: 10,
        margin: 10,
        backgroundColor: 'lightgrey'
    },
    arcardIcon: {
        fontSize: 15,
        marginBottom: 2,
        marginRight: 10,
    },
    arcardLabel: {
        alignSelf: 'center',
        fontSize: 15
    },
});