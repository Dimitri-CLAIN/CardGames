import * as React from 'react';

import { TouchableOpacity, Image } from "react-native";
import { Text } from '../../Themed';

import { StylesARCard } from "./StylesARCard";

import { useState, useEffect } from 'react';
import ARconfigs from '../ARConfig/ARConfigs';

const ARCard = (props) => {
    const [fields, setFields] = useState([]);
    const [touched, setTouched] = useState(false);

    function getFields() {
        var tmpFields = []
        if (props.config === undefined)
            return
        for(var i = 0; i < props.config.length; i++) {
            if (props.config[i] === "trelloBoard") {
                tmpFields.push(ARconfigs.trello.board)
            }
            if (props.config[i] === "trelloCard") {
                tmpFields.push(ARconfigs.trello.card)
            }
            if (props.config[i] === "githubRepo") {
                tmpFields.push(ARconfigs.github.githubRepo)
            }
            if (props.config[i] === "githubIssueNumber") {
                tmpFields.push(ARconfigs.github.githubIssueNumber)
            }
            if (props.config[i] === "githubPullNumber") {
                tmpFields.push(ARconfigs.github.githubPullNumber)
            }
            if (props.config[i].includes("text")) {
                var copyField = {...ARconfigs.basic.text}
                copyField.id = props.config[i]
                copyField.label = props.config[i].split('text')[1]
                tmpFields.push(copyField)
            }
        }
        setFields(tmpFields)
    }

    useEffect(() => {
        getFields();
    }, [])

    const whatLogo = (text) => {
        if (text === 'Trello') {
            return (require('../../../images/trello-log.png'));
        } else if (text === 'Github') {
            return (require('../../../images/github-logo.png'));
        } else if (text === 'Twitter') {
            return (require('../../../images/twitter-logo.png'))
        } else if (text === 'Gmail') {
            return (require('../../../images/gmail-logo.png'))
        }
        return (require('../../../images/logo-not-found.png'))
    };

    return (
        <TouchableOpacity
            style={[
                StylesARCard.arcardContainer,
                (touched) ? (StylesARCard.arcardContainerNotTouched) : (StylesARCard.arcardContainerTouched)
            ]}
            onPress={() => {
                setTouched(true);
                setTouched(false);
                if (props.platform === "Gmail") {
                    props.handler("Google", props.label, fields)
                } else {
                    props.handler(props.platform, props.label, fields)
                }
            }}
        >
            <Image style={[StylesARCard.arcardIcon, { width: 50, height: 50}]} source={whatLogo(props.platform)}/>
            <Text style={StylesARCard.arcardLabel}>{props.label}</Text>
        </TouchableOpacity>
    );
}

export default ARCard;