const ARconfigs = {
    trello: {
        board: {
            type: "list",
            toCall: true,
            callUrl: '/api/trello/boards/get/:clientToken',
            argsForCall: [{"userId": ":clientToken"}],
            id: "trelloBoard"
        },
        card: {
            type: "list",
            toCall: true,
            callUrl: '/api/trello/cards/get/:boardId/:clientToken',
            argsForCall: [{"userId": ":clientToken"}, {"trelloBoard": ":boardId"}],
            id: "trelloCard"
        },
        boardMember: {
            type: "list",
            toCall: true,
            callUrl: '/api/trello/board/member/get/:boardId/:clientToken',
            argsForCall: [{"userId": ":clientToken"}, {"trelloBoard": ":boardId"}],
            id: "trelloBoardMember"
        }
    },
    github: {
        githubRepo: {
            type: "list",
            toCall: true,
            callUrl: '/api/link/github/listRepositories/:clientToken',
            argsForCall: [{"userId": ":clientToken"}],
            id: "githubRepo"
        },
        githubIssueNumber: {
            type: "list",
            toCall: true,
            callUrl: '/api/link/github/listRepositoryIssues/:clientToken/:repo',
            argsForCall: [{"userId": ":clientToken"}, {"githubRepo": ":repo"}],
            id: "githubIssueNumber"
        },
        githubPullNumber: {
            type: "list",
            toCall: true,
            callUrl: '/api/link/github/listPullRequests/:clientToken/:repo',
            argsForCall: [{"userId": ":clientToken"}, {"githubRepo": ":repo"}],
            id: "githubPullNumber"
        },
    },
    twitter: {

    },
    basic: {
        name: {
            type: "text",
            label: "Name of action/reaction Link",
            id: "arName"
        },
        text: {
            type: "text",
            label: "TODEFINE",
            id: "text"
        }
    }
}

export default ARconfigs;