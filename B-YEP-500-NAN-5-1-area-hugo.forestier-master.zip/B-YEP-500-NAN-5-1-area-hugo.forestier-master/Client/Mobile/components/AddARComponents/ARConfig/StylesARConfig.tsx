import { StyleSheet } from 'react-native';

export const StylesARConfig = StyleSheet.create({
    configFieldContainer: {
        flexDirection: 'column-reverse',
        justifyContent: 'center',
        textAlign: 'center',
        width: '100%',
        backgroundColor: '#202020',
    },
    configContainer: {
        width: '100%',
        justifyContent: 'space-between',
        alignItems: 'center',
        color: 'white',
        backgroundColor: '#202020',
    },
    configNextButton: {
        position: "absolute",
        bottom: 10,
        right: 10,
    },
    titleText: {
        color: 'white',
        fontSize: 25,
    },
    buttonStyle: {
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white',
        borderRadius: 10,
        padding: 10,
        borderColor: 'grey',
        borderWidth: 1,
    },
});