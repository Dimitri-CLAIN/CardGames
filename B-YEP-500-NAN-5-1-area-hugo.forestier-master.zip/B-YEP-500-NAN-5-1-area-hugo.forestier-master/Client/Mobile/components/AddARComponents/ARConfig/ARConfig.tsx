import React, { useState, useEffect, useContext } from 'react';

import { View, Text } from '../../Themed';

import { StylesARConfig } from './StylesARConfig';

import { TouchableOpacity } from 'react-native';

import CustomList from '../CustomList/CustomList';
import ARconfigs from './ARConfigs.js';
import CustomTextInput from '../CustomTextInput/CustomTextInput';
import ConfigContext from '../ARConfigContext/ARConfigContext.js';

import GLOBAL from '../../../global.js';

export const ARConfig = (props) => {
    const [myVariables, setMyVariables] = useState({})
    const { contextVariables, setContextVariables} = useContext(ConfigContext)
    const [ press, setPress ] = useState(false);

    function createList(data, variables) {
        variables[data.id] = {}
        variables[data.id].dependency = []
        variables[data.id].value = null
        variables[data.id].element = null
        if (data.toCall === true) {
            for (var i = 0; i < data.argsForCall.length; i++) {
                if (Object.keys(data.argsForCall[i])[0] === "userId") {
                    data.argsForCall.userId = GLOBAL.user.uid
                } else {
                    for (let j in ARconfigs) {
                        for (let n in ARconfigs[j]) {
                            if (ARconfigs[j][n].id === Object.keys(data.argsForCall[i])[0]) {
                                variables[data.id].dependency.push(ARconfigs[j][n].id)
                                variables = createList(ARconfigs[j][n], variables)
                            }
                        }
                    }
                }
            }
        }
        variables[data.id].element = <CustomList data={data} variables={{...variables}} updateVariables={setMyVariables}/>
        return(variables)
    }

    function createTextInput(data, variables) {
        variables[data.id] = {}
        variables[data.id].dependency = []
        variables[data.id].value = null
        variables[data.id].element = null
        variables[data.id].element = <CustomTextInput data={data} variables={{...variables}} updateVariables={setMyVariables} />
        return variables;
    }

    function getFields() {
        var variables = {...contextVariables}
        for (var i = 0; i < props.fields.length; i++) {
            if (props.fields[i].type === "list") {
                variables = createList(props.fields[i], variables)
            } else if (props.fields[i].type === "text") {
                variables = createTextInput(props.fields[i], variables)
            }
        }
        setContextVariables(variables)
        setMyVariables(variables)
    }

    useEffect(() => {
        getFields()
        return() => {
            setContextVariables({})
        }
    }, [])

    function displayFields() {
        let display = []
        for (var i in contextVariables) {
            if (contextVariables[i].dependency.length === 0) {
                display.push(contextVariables[i].element)
            } else {
                let anyDependencyLeft = false
                for (var n = 0; n < contextVariables[i].dependency.length; n++) {
                    if (contextVariables[contextVariables[i].dependency[n]].value === null)
                        anyDependencyLeft = true
                }
                console.log('HEY')
                if (anyDependencyLeft === false)
                    display.push(contextVariables[i].element)
            }
        }
        return (display)
    }

    function next() {
        setPress(true);
        var someFieldNull = false
        for (var i in contextVariables) {
            if (contextVariables[i].value === null) {
                someFieldNull = true
            }
        }
        if (someFieldNull === true) {
            console.error("You need to complete all fields before continuing to the next step")
            return;
        }
        var toReturn = {
            name: props.cardName,
            config : {},
        }
        for (var i in contextVariables) {
            toReturn.config[i] = contextVariables[i].value
        }
        props.handler(toReturn)
        setPress(false);
    }

    return (
         <View style={StylesARConfig.configContainer}>
             <Text style={StylesARConfig.titleText}>Configuration</Text>
             <View  style={StylesARConfig.configFieldContainer}>
                 {displayFields()}
             </View>
             <TouchableOpacity style={StylesARConfig.buttonStyle} onPress={next}>
                 <Text style={{ fontSize: 20, color: '#202020'}}>Next</Text>
             </TouchableOpacity>
        </View>
);
}