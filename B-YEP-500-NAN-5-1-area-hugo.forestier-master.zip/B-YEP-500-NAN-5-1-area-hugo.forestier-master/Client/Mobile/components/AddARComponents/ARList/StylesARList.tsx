import { StyleSheet } from 'react-native';

export const StylesARList = StyleSheet.create({
    arlistContainer: {
        flexDirection: 'row',
        width: '100%',
        marginTop: 10,
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
        color: 'white',
        backgroundColor: '#202020',
        fontSize: 25,
    },
    arlistCardContainer: {
        marginTop: 15,
        flexWrap: 'wrap',
        fontSize: 25,
    },
});