import React, { useState, useEffect, useContext } from 'react';

import { ScrollView, SafeAreaView } from 'react-native';
import { View, Text } from '../../Themed';

import { StylesARList } from './StylesARList';

import ARCard from '../ARCard/ARCard';
import axios from 'axios';
import GLOBAL from '../../../global.js';

const ARList = (props) => {
    const [ cards, setCards ] = useState([]);

    async function isLoggedIn(service) {
        console.log("SERVICE =>", service)
        if (service === "Gmail")
            service = "Google"
        var clientToken = undefined
        const url = 'http://' + GLOBAL.ip + `:8080/api/firebase/${GLOBAL.user.uid}/token/`;
        await axios.get(url)
            .then(res => {
                for (let element in res.data) {
                    for (let i in res.data[element]) {
                        console.log("CHECKING TOKEN =>", res.data[element][i])
                        var connection = res.data[element][i];
                        if (connection.Type === service) {
                            clientToken = connection.ClientToken;
                        }
                    }
                }
            })
            .catch((error) => {console.log(error, 0)});
        return clientToken;
    }

    useEffect(() => {
        display()
    }, [])

    useEffect(() => {
        display()
    }, [props.whichType])

    async function handler(platform, label, neededConfig) {
        var login = await isLoggedIn(platform)
        if (props.whichType === 0 && login !== undefined) {
            props.handler(4, null, neededConfig, label)
        } else if(props.whichType === 1 && login !== undefined) {
            props.handler(4, null, neededConfig, label)
        } else {
            props.handler(3, platform, neededConfig, label)
        }
    }

    function display() {
        if (props.whichType === 0) {
            const url = 'http://' + GLOBAL.ip + ':8080/api/generic/link/getActions'
            axios.get(url)
                .then(res => {
                    let cards = [];
                    for (let card in res.data[0]) {
                        cards.push(<ARCard platform={res.data[0][card].platform} label={card} handler={handler} config={res.data[0][card].neededConfig}/>);
                    }
                    setCards(cards);
                    return cards;
                })
                .catch((error) => {console.log(error, 1)});
        } else if (props.whichType === 1) { // call back end list de tous les REActions
            const url = 'http://' + GLOBAL.ip + `:8080/api/generic/link/getREactionsFrom/${props.choosedAction}`
            axios.get(url)
                .then(res => {
                    let cards = [];
                    for (let card in res.data) {
                        cards.push(<ARCard platform={res.data[card].platform} label={card} handler={handler} config={res.data[card].neededConfig} />);
                    }
                    setCards(cards);
                    return cards;
                })// Add configuration !
                    .catch((error) => {console.log(error, 2)});
        }
    }

    return (
        <SafeAreaView style={{ justifyContent: 'center', alignItems: 'center', flex:1 }}>
            <Text style={StylesARList.arlistContainer}>List of {!props.whichType ? "action" : "reaction"}</Text>
            <ScrollView style={StylesARList.arlistCardContainer}>
                {cards}
            </ScrollView>
            <View style={{ backgroundColor: '#202020'}}>
                <Text style={{color: '#202020', marginTop: 18 }}>Hello</Text>
            </View>
        </SafeAreaView>
    );
}

export default ARList;