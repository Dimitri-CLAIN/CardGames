import React, { useEffect } from 'react';
import {Text, View} from "../Themed";
import {StylesHome} from "./HomeStyles";
import {Image, Switch, TouchableOpacity} from "react-native";
import GLOBAL from "../../global.js"
import axios from "axios"

export const Item = ({ style, item, onPressSettings, onPressTicket, onToggleSwitch, color }) => {
    const whatLogo = (text) => {
        if (text === 'Trello') {
            return (require('../../images/trello-log.png'));
        } else if (text === 'GitHub') {
            return (require('../../images/github-logo.png'));
        } else if (text === 'Twitter') {
            return (require('../../images/twitter-logo.png'))
        } else if (text === 'Gmail') {
            return (require('../../images/gmail-logo.png'))
        }
        return (require('../../images/logo-not-found.png'))
    };
    const [action, setAction] = React.useState(require('../../images/logo-not-found.png'));
    const [reaction, setReaction] = React.useState(require('../../images/logo-not-found.png'));


    useEffect(() => {
        async function GetPlatforms() {
            var platformAction = await axios.get("http://" + GLOBAL.ip + ':8080/api/generic/link/getPlatformAction', {
            params: {
                action: item[0].Action.name
            }
            });
            var platformREaction = await axios.get("http://" + GLOBAL.ip + ':8080/api/generic/link/getPlatformREaction', {
                params: {
                    reaction: item[0].REaction.name
                }
            })
            setAction(whatLogo(platformAction.data))
            setReaction(whatLogo(platformREaction.data))
        }
        GetPlatforms()
    }, []);

    return (
        <View style={StylesHome.item}>
            <TouchableOpacity
                style={[StylesHome.itemBigButton, color]}
                onPress={onPressTicket}
            >
                <Text style={StylesHome.itemTitle}>{item[0].ARname}</Text>
                <View
                    style={[StylesHome.itemImages, color]}
                >
                    <Image style={{ width: 50, height: 50 }} source={action}/>
                    <Image style={[StylesHome.submitButtonSeparator, { width: 25, height: 25 }]} source={require('../../images/arrow-right.png')}/>
                    <Image style={{ width: 50, height: 50 }} source={reaction}/>
                </View>
                <View style={[StylesHome.itemTexts, color]}>
                    <Text style={StylesHome.itemText}>{item[0].Action.name}</Text>
                    <Text style={StylesHome.itemText}>{'>'}</Text>
                    <Text style={StylesHome.itemText}>{item[0].REaction.name}</Text>
                </View>
            </TouchableOpacity>
            <View style={StylesHome.itemButtons}>
                <TouchableOpacity
                    style={StylesHome.itemSettingsButton}
                    onPress={onPressSettings}
                >
                    <Image style={{width: 20, height: 20}}
                           source={require('../../images/settings_icon.png')}/>
                </TouchableOpacity>
                <Switch
                    style={StylesHome.itemSwitchButton}
                    trackColor={{false: 'red', true: 'lightgreen'}}
                    thumbColor={'white'}
                    onValueChange={onToggleSwitch}
                    value={item.toggle}
                />
            </View>
        </View>
    );
};
