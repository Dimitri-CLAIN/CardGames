import React, { Component, createContext } from 'react'
import GLOBAL from '../global.js'

export const LoginContext = createContext();

class LoginContextProvider extends Component {

    constructor(props) {
        super(props);
        this.state = {
            Login_data: [
                {
                    LoginKey: "Trello",
                    url: "https://trello.com/1/authorize?",
                    args: {
                        expiration: "never",
                        name:"Area",
                        scope: "read,write,account",
                        return_url: "http://localhost:8081/",
                        callback_method: "fragment",
                        response_type: "token",
                        key: "3078e1294a43c6ac75348ecf15dce4cf"
                    }
                }, {
                    LoginKey: "Github",
                    url: "https://github.com/login/oauth/authorize?",
                    args: {
                        client_id: "80b5848ec7a4c1a8e63a",
                        redirect_uri: "http://localhost:8081/",
                        scope: "repo, admin:repo_hook, admin:org, admin:ublic_key, gist, notifications, user, delete_repo, write:discussion, write:packages, read:packages, delete:packages, admin:gpg_key, workflow",
                        state:"THISISTHESTATELINE"
                    }
                }, {
                    LoginKey: 'GitHub',
                    url: "https://github.com/login/oauth/access_token?",
                    args: {
                        client_id: "80b5848ec7a4c1a8e63a",
                        client_secret: "d188d304b85bc12705b3d66e572d0efde7e71bcd",
                        redirect_uri: "http://localhost:8081/",
                    }
                }, {
                    LoginKey: 'Twitter',
                    url: "https://" + GLOBAL.ip + ":8080/auth/twitter",
                }],
            Tokens: [{Site: "Trello", Token: undefined},
                     {Site: "GitHub", Token: undefined}],
            currentUser: null,
        };
    }

    componentDidMount = () => {
        const {currentUser} = this.context;
        this.setState({currentUser: currentUser})
    }

    update_Tokens =  (LoginKey, Token) => {
        for (var i = 0; i !== this.state.Tokens.length; i++) {
            if (this.state.Tokens[i].Site === LoginKey) {
                var tokencpy = this.state.Tokens;
                tokencpy[i].Token = Token;
                this.setState({Token: tokencpy});
            }
            console.table(this.state.Tokens);
        }
    }

    render() {
        return(
            <LoginContext.Provider value={{...this.state, update_Tokens:this.update_Tokens}}>
                {this.props.children}
            </LoginContext.Provider>
        );
    }
}
export default LoginContextProvider;