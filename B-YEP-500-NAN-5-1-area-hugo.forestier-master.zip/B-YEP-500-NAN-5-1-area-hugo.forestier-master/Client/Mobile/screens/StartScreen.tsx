import * as React from 'react';

import { Image, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import { Text, View } from '../components/Themed';
import { TextInput } from 'react-native-gesture-handler';

import GLOBAL from '../global.js';
import axios from 'axios';

export default function StartScreen({ navigation }) {
    const [ip, setIp] = React.useState(GLOBAL.ip);
    const [press, setPress] = React.useState(false);
    const [error, setError] = React.useState('');

    const getTest = async (address: String) => {
        try {
            const response = await axios.get(address);
            if (response.data === 'Holala you past the test') {
                navigation.replace('Login');
            }
        } catch (error) {
            setError(error.message);
            return (error.message);
        }
        return ('error');
    }

    const onPress = () => {
        setPress(true);
        setError('');
        getTest('http://' + GLOBAL.ip + ':8080/test');
        setPress(false);
    };

    return (
        <View
            style={{
                backgroundColor: '#202020',
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: 37,
                height: '100%',
                flex: 1,
            }}
        >
            <Image source={require('../images/area-logo.png')}/>
            <Text
                style={{
                    color: 'white',
                    backgroundColor: '#202020',
                    fontSize: 20,
                    fontWeight: 'bold',
                    marginTop: 20,
                }}
            >
                Enter the ip address
            </Text>
            <TextInput
                style={{
                    borderRadius: 10,
                    backgroundColor: 'grey',
                    color: 'white',
                    marginTop: 20,
                    width: Dimensions.get('screen').width / 2,
                    height: 30,
                    textAlign: 'center',
                }}
                placeholder="Ip Address"
                value={ip}
                onChangeText={(text) => {
                        if (text != ip) {
                            setIp(text)
                            GLOBAL.ip = text;
                        }
                    }
                }
            />
            <Text style={{ marginTop: 20, color: 'red',}} >{error}</Text>
            <TouchableOpacity
                style={{
                    borderRadius: 10,
                    padding: 5,
                    backgroundColor: 'grey',
                    justifyContent: 'center',
                    alignItems: 'center',
                }}
                onPress={onPress}
            >
                <Text style={{ fontSize: 20, color: press ? 'white' : '#202020'}}>Enter in Application</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({

});