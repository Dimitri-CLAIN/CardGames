import * as React from 'react';
import { Image, TouchableOpacity } from "react-native";

import { Text, View } from '../components/Themed';
import { isValidEmail } from '../components/isValid';
import { StylesAuth } from '../components/AuthComponents/AuthStyles';
import { AuthComponent } from "../components/AddARComponents/AuthComponent";
import ConfigContext from '../components/AddARComponents/ARConfigContext/ARConfigContext.js';

import LoginContextProvider from "../Context/contextLogin.js";

import GLOBAL from '../global.js';

import {useCallback, useEffect, useState} from 'react';
import axios from "axios";

export default function ConfigScreen({ navigation }) {
    const [github, setGithub] = React.useState(false);
    const [google, setGoogle] = React.useState(GLOBAL.googleSignIn);
    const [trello, setTrello] = React.useState(false);
    const [twitter, setTwitter] = React.useState(false);
    const [error, setError] = React.useState('');
    const [serviceToLogInto, setServiceToLogInto] = React.useState('');
    const [displayView, setDisplayView] = React.useState(false);

    const [contextVariables, setContextVariables] = useState({});
    const value = { contextVariables, setContextVariables };

    async function isLoggedIn(servive) {
        var clientToken = undefined
        const url = 'http://' + GLOBAL.ip + `:8080/api/firebase/${GLOBAL.user.uid}/token/`;
        await axios.get(url)
            .then(res => {
                console.log(res.data)
                for (let element in res.data) {
                    for (let i in res.data[element]) {
                        var connection = res.data[element][i];
                        if (connection.Type === servive) {
                            clientToken = connection.ClientToken;
                        }
                    }
                }
            })
            .catch((error) => {console.log(error, 0)});
        return clientToken;
    }

    useEffect(() => { const temp = async () => {
            var tokenGoogle = await isLoggedIn('Google');
            var tokenTrello = await isLoggedIn('Trello');
            var tokenTwitter = await isLoggedIn('Twitter');
            var tokenGithub = await isLoggedIn('Github');
            if (tokenGoogle !== undefined)
                setGoogle(true);
            if (tokenTrello !== undefined)
                setTrello(true);
            if (tokenGithub !== undefined)
                setGithub(true);
            if (tokenTwitter !== undefined)
                setTwitter(true);
            }
            temp();
    }, [])

    const loginPlatform = (platform) => {
            setServiceToLogInto(platform);
            setDisplayView(true);
    };

    const isWebViewUsed = () => {
        if (displayView) {
            console.log(serviceToLogInto)
            return (
               <LoginContextProvider>
                    <AuthComponent
                        loginKey={serviceToLogInto}
                        handler={(code) => {
                            if (code === 1) {
                                if (serviceToLogInto == 'Trello') {
                                    setTrello(true);
                                } else if (serviceToLogInto == 'Github') {
                                    setGithub(true);
                                } else if (serviceToLogInto == 'Twitter') {
                                    setTwitter(true);
                                } else if (serviceToLogInto == 'Google') {
                                    setGoogle(true);
                                } else
                                    setError('Connection Abort : ' + serviceToLogInto)
                                setDisplayView(false)
                            }
                        }}
                    />
                </LoginContextProvider>
            );
        } else {
            return (
                <View style={StylesAuth.container}>
                    <TouchableOpacity
                        style={StylesAuth.buttonBackStyle}
                        onPress={() => (navigation.replace('Home'))}
                    >
                        <Image  style={{ width: 20, height: 20 }}  source={require('../images/arrow-left.png')}/>
                        <Image  style={{ width: 20, height: 20 }}  source={require('../images/arrow-left.png')}/>
                    </TouchableOpacity>
                    <View style={StylesAuth.container}>
                        <TouchableOpacity
                            style={[google ? StylesAuth.buttonLoginStyleOff : StylesAuth.buttonLoginStyleOn, {flexDirection: 'row'}]}
                            disabled={google}
                            onPress={() => (loginPlatform('Google'))}
                        >
                            <Image style={{ width: 50, height: 50 }}
                                   source={require('../images/google-icon.png')}/>
                            <Text style={[google ? {color : 'white'} : {color : 'black'}, { marginHorizontal: 10, fontSize: 20}]}
                            >{google ? "Connected" : "Not connected"}</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={[trello ? StylesAuth.buttonLoginStyleOff : StylesAuth.buttonLoginStyleOn, {flexDirection: 'row'}]}
                            disabled={trello}
                            onPress={() => (loginPlatform('Trello'))}
                        >
                            <Image style={{ width: 50, height: 50 }}
                                   source={require('../images/trello-log.png')}/>
                            <Text style={[trello ? {color : 'white'} : {color : 'black'}, { marginHorizontal: 10, fontSize: 20}]}
                            >{trello ? "Connected" : "Not connected"}</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={[twitter ? StylesAuth.buttonLoginStyleOff : StylesAuth.buttonLoginStyleOn, {flexDirection: 'row'}]}
                            disabled={twitter}
                            onPress={() => (loginPlatform('Twitter'))}
                        >
                            <Image style={{ width: 50, height: 50 }} source={require('../images/twitter-logo.png')}/>
                            <Text style={[twitter ? {color : 'white'} : {color : 'black'}, { marginHorizontal: 10, fontSize: 20}]}
                            >{twitter ? "Connected" : "Not connected"}</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={[github ? StylesAuth.buttonLoginStyleOff : StylesAuth.buttonLoginStyleOn, {flexDirection: 'row'}]}
                            disabled={github}
                            onPress={() => (loginPlatform('Github'))}
                        >
                            <Image style={{ width: 50, height: 50 }} source={require('../images/github-logo.png')}/>
                            <Text style={[github ? {color : 'white'} : {color : 'black'}, { marginHorizontal: 10, fontSize: 20}]}
                            >{github ? "Connected" : "Not connected"}</Text>
                        </TouchableOpacity>
                    </View>
                <Text style={StylesAuth.textError}>
                    {error}
                </Text>
            </View>
            );
        }
    };

    return (
        isWebViewUsed()
    );
}