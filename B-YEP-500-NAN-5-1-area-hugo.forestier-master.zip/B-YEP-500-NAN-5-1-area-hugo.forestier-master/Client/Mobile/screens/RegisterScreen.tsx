import * as React from 'react';
import { Button, ScrollView, Image, TouchableOpacity } from 'react-native';

import EditScreenInfo from '../components/EditScreenInfo';
import { Text, View } from '../components/Themed';
import { isValidEmail } from '../components/isValid';
import { StylesAuth } from '../components/AuthComponents/AuthStyles';

import * as firebase from 'firebase';
import firebaseConfig from "../FireBaseConfig.json";
import { TextInput } from 'react-native-gesture-handler';

import GLOBAL from '../global.js';

import {useCallback, useEffect} from 'react';

export default function RegisterScreen({ navigation }) {
    // Global State
    const [press, setPress] = React.useState(false);
    const [email, setEmail] = React.useState(null);
    const [password, setPassword] = React.useState(null);
    const [passwordConf, setPasswordConf] = React.useState(null);
    const [error, setError] = React.useState(null);

    if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig)
    } else {
        firebase.app(); // if already initialized, use that one
    }

    useEffect(() => {
        firebase.auth().onAuthStateChanged((user:any) => {
            if (user != null) {
                GLOBAL.user = user;
                navigation.replace('Home');
            } else {
                GLOBAL.user = user;
            }
        });
    }, []);

    async function RegisterWithEmail() {
        setPress(true);
        if (!email) {
            setError("Email address required")
            return
        } else if (!isValidEmail(email)) {
            setError("Invalid email address")
            return
        } else if (!password && password.trim() && password.length > 6) {
            setError("Weak password, minimum 5 chars")
            return
        } else if (password != passwordConf) {
            setError("Passwords are not the same")
            return
        }

        firebase
            .auth()
            .createUserWithEmailAndPassword(email, password)
            .catch((error) => {
                if (error.code === 'auth/email-already-in-use') {
                    setError('Email address already in use !');
                } else if (error.code === 'auth/invalid-email') {
                    setError('Invalid email address');
                } else {
                    setError(error.message);
                }
            })
        setPress(false);
    }

    return (
        <ScrollView style={StylesAuth.containerScrollView}>
            <View style={StylesAuth.container}>
                <Image source={require('../images/area-logo.png')}/>
                <View style={StylesAuth.inputsView}>
                    <Text style={StylesAuth.title}>Register Now.</Text>
                    <TextInput
                        style={StylesAuth.textInput}
                        onChangeText={(text) => {if (text != email) setEmail(text)}}
                        value={email}
                        placeholder={'Email Address'}
                        placeholderTextColor='lightgrey'
                    />
                    <TextInput
                        style={StylesAuth.textInput}
                        placeholder={'Password'}
                        placeholderTextColor='lightgrey'
                        onChangeText={(text) => {if (text != password) setPassword(text)}}
                        value={password}
                        autoCompleteType={'password'}
                        secureTextEntry={true}
                    />
                    <TextInput
                        style={StylesAuth.textInput}
                        placeholder={'Password Confirmation'}
                        placeholderTextColor='lightgrey'
                        onChangeText={(text) => {if (text != passwordConf) setPasswordConf(text)}}
                        value={passwordConf}
                        autoCompleteType={'password'}
                        secureTextEntry={true}
                    />
                    <Text style={StylesAuth.littleText} onPress={() => (navigation.replace('Login'))}>
                        If you already have an account : Login Here
                    </Text>
                    <Text style={StylesAuth.textError}>{error}</Text>
                    <TouchableOpacity style={StylesAuth.buttonStyle} onPress={RegisterWithEmail}>
                        <Text style={{ fontSize: 20, color: press ? 'white' : '#202020'}}>CREATE ACCOUNT</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </ScrollView>
    );
};