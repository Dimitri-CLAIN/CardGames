import * as React from 'react';
import { Button, ScrollView, Image, TouchableOpacity } from 'react-native';

import { Text, View } from '../components/Themed';
import { isValidEmail } from '../components/isValid';
import { StylesAuth } from '../components/AuthComponents/AuthStyles';

import * as firebase from 'firebase';
import firebaseConfig from "../FireBaseConfig.json";
import { TextInput } from 'react-native-gesture-handler';

import GLOBAL from '../global.js';

import { useCallback, useEffect } from 'react';

export default function LoginScreen({ navigation }) {
    const [email, setEmail] = React.useState(null);
    const [password, setPassword] = React.useState(null);
    const [error, setError] = React.useState(null);
    const [press, setPress] = React.useState(false);

    if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig)
    } else {
        firebase.app(); // if already initialized, use that one
    }

    const onAuthStateChanged = (user:any) => {
        if (user != null) {
            GLOBAL.user = user;
            navigation.replace('Home');
        } else {
            GLOBAL.user = null;
        }
    };

    useEffect(() => {
        const subscribe = firebase.auth().onAuthStateChanged(onAuthStateChanged);
        return subscribe;
    }, [])

    async function loginWithEmail() {
        setPress(true);
        if (!email) {
            setError("Email required")
            setPress(false);
            return
        } else if (!isValidEmail(email)) {
            setError("Invalid Email")
            setPress(false);
            return
        } else if (!password && password.trim() && password.length > 6) {
            setError("Weak password, minimum 5 chars")
            setPress(false);
            return
        };

        firebase
            .auth()
            .signInWithEmailAndPassword(email, password)
            .catch(error => {
                setError(error.message);
            });
        setPress(false);
    };

    const loginWithGoogle = () => {
        setError('Google Connection is not implemented yet');
    };

    return (
        <ScrollView style={StylesAuth.containerScrollView}>
            <View style={StylesAuth.container}>
                <Image source={require('../images/area-logo.png')}/>
                <View style={StylesAuth.inputsView}>
                    <Text style={StylesAuth.title}>Login Now.</Text>
                    <TextInput
                        style={StylesAuth.textInput}
                        placeholder='Email Address'
                        placeholderTextColor='lightgrey'
                        onChangeText={text => {if (text != email) setEmail(text)}}
                        value={email}
                    />
                    <TextInput
                        style={StylesAuth.textInput}
                        placeholder="Password"
                        placeholderTextColor='lightgrey'
                        onChangeText={text => {if (text != password) setPassword(text)}}
                        value={password}
                        autoCompleteType={'password'}
                        secureTextEntry={true}
                    />
                    <Text style={StylesAuth.littleText} onPress={() => navigation.replace('Register')}>
                        Don't have an account ? Create One
                    </Text>
                    <Text style={StylesAuth.textError}>{error}</Text>
                    <TouchableOpacity style={StylesAuth.buttonStyle} onPress={loginWithEmail}>
                        <Text style={{ fontSize: 20, color: press ? 'white' : '#202020'}}>LOGIN</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={StylesAuth.buttonLoginStyleOn} onPress={loginWithGoogle}>
                        <Image style={{ width: 50, height: 50 }} source={require('../images/google-icon.png')}/>
                    </TouchableOpacity>
                </View>
            </View>
        </ScrollView>
    );
}