import * as React from 'react';

import { View, Text } from '../components/Themed';

import { StylesAddAR } from '../components/AddARComponents/StylesAddAR';

// import LoginContextProvider from '../Context/contextLogin.js'
import { AuthComponent } from "../components/AddARComponents/AuthComponent";
import ARList from '../components/AddARComponents/ARList/ARList';
import { useState } from 'react';
import { ARConfig } from '../components/AddARComponents/ARConfig/ARConfig';
import ConfigContext from '../components/AddARComponents/ARConfigContext/ARConfigContext.js';
import LoginContextProvider from "../Context/contextLogin";
import GLOBAL from '../global.js'
import axios from 'axios';
import ARConfigName
    from "../components/AddARComponents/ARConfigName/ARConfigName";
import { Image, TouchableOpacity } from "react-native";

export function AddAr({ navigation }) {
    const [actionOrReaction, setActionOrReaction] = useState(0)
    const [serviceToLogInto, setServiceToLogInto] = useState(null)
    const [lastStep, setLastStep] = useState(null)
    const [neededConfig, setneededConfig] = useState(null)
    const [selectedAction, setSelectedAction] = useState(null)
    const [currentStepName, setCurrentStepName] = useState(null)
    const [action, setAction] = useState(null)
    const [reaction, setReaction] = useState(null)
    const [alreadySent, setAlreadySent] = useState(false);
    const [linkName, setLinkName] = useState("Default Name")

    function handler(newValue, service, neededConfig, selectedCardLabel) {
        if (actionOrReaction === 0) {
            setSelectedAction(selectedCardLabel)
        }
        if (selectedCardLabel !== null)
            setCurrentStepName(selectedCardLabel)
        if (newValue >= 3) {
            setLastStep(actionOrReaction)
        }
        if (newValue === 3) {
            setServiceToLogInto(service)
        }
        if (neededConfig !== null)
            setneededConfig(neededConfig)
        setActionOrReaction(newValue)
    }

    function createWebhook(service, action) {
        var createWebhookUrl = null;
        var body = {};
        if (service === 'Trello') {
            createWebhookUrl = 'http://' + GLOBAL.ip + `:8080/api/trello/createWebhookCard/${GLOBAL.user.uid}`; // TODO rendre modulable !
            var idModel = null;
            if (action.config.trelloBoardMember !== undefined) {
                idModel = action.config.trelloBoardMember;
            } else if (action.config.trelloCard !== undefined) {
                idModel = action.config.trelloCard;
            } else if (action.config.trelloBoard !== undefined)
                idModel = action.config.trelloBoard;
            body = {
                idModel: idModel,
                desc: `Webhook for ${action.name}`
            };
        }
        axios.post(createWebhookUrl, body)
            .then(res => {
                console.log(res);
            })
            .catch(err => {
                console.log(err);
                console.error('Error while creating the webhook!');
            })
    }

    function whatToDisplay() {
        let toDisplay = []
        if (actionOrReaction < 2 && actionOrReaction >= 0) {
            toDisplay.push(<ARList whichType={actionOrReaction} handler={handler} choosedAction={selectedAction}/>)
        } else if (actionOrReaction === 3) {
            toDisplay.push(
                <LoginContextProvider>
                    <AuthComponent
                        loginKey={serviceToLogInto}
                        handler={(code) => {
                            if (code === 1) {
                                if (lastStep === 0 && neededConfig === null)
                                    setActionOrReaction(1)
                                else if (lastStep === 1 && neededConfig === null)
                                    setActionOrReaction(5)
                                else
                                    setActionOrReaction(4)
                            } else if (code === 0)
                                setActionOrReaction(lastStep);
                        }}
                    />
                </LoginContextProvider>
            );
        } else if (actionOrReaction === -1) {
            if (alreadySent) {
                return
            } else {
                setAlreadySent(true)
            }
            const params = new URLSearchParams()
            params.append('activated', true)
            params.append('action', JSON.stringify(action))
            params.append('reaction', JSON.stringify(reaction))
            params.append('arname', linkName)
            const config = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                }
            }
            createWebhook("Trello", action)
            const url = 'http://' + GLOBAL.ip + `:8080/api/generic/link/create/${GLOBAL.user.uid}`
            axios.post(url, params, config)
                .then(res => {
                    navigation.replace("Home");
                })
                .catch(error => {
                    console.error("Error while creating the action reaction. Try again in a few minutes")
                })
        } else if (actionOrReaction === 4) {
            toDisplay.push(
                <ARConfig fields={neededConfig} cardName={currentStepName} handler={(data) => {
                    if (lastStep === 0) {
                        setActionOrReaction(1)
                        setAction(data)
                    } else if (lastStep === 1) {
                        setActionOrReaction(5)
                        setReaction(data)
                    }
                }}/>
            );
        } else if (actionOrReaction === 5) {
            toDisplay.push(
                <ARConfigName onFinish={(value:any) => {
                    setLinkName(value)
                    setActionOrReaction(-1)
                }} />
            )
        }
        return (toDisplay);
    }

    const [contextVariables, setContextVariables] = useState({});
    const value = { contextVariables, setContextVariables };

    return (
        <View style={StylesAddAR.container}>
            <View style={StylesAddAR.buttonView}>
                <TouchableOpacity
                    style={StylesAddAR.buttonStyle}
                    onPress={() => (navigation.replace('Home'))}
                >
                    <Image  style={{ width: 20, height: 20 }}  source={require('../images/arrow-left.png')}/>
                    <Image  style={{ width: 20, height: 20 }}  source={require('../images/arrow-left.png')}/>
                </TouchableOpacity>
            </View>
            <ConfigContext.Provider value={value}>
                {whatToDisplay()}
            </ConfigContext.Provider>
        </View>
    );
}

export default AddAr;