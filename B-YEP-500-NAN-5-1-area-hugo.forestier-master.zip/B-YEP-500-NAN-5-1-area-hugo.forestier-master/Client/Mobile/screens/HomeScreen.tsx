import * as React from 'react';

import {
    Dimensions,
    Button,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    FlatList,
    Switch,
    Image,
    BackHandler,
} from 'react-native';

import { useFocusEffect } from '@react-navigation/native';

import { Text, View } from '../components/Themed';
import * as firebase from 'firebase';

import GLOBAL from '../global.js';

import { useEffect } from 'react';

import { StylesHome } from "../components/HomeComponents/HomeStyles";
import { Item } from "../components/HomeComponents/Item";
import axios from "axios";

export default function HomeScreen({ navigation }) {
    const [selectedId, setSelectedId] = React.useState(null);
    const [data, setData] = React.useState(new Array<JSON>());
    const [pressLog, setPressLog] = React.useState(false);
    const [pressAdd, setPressAdd] = React.useState(false);
    const [pressSet, setPressSet] = React.useState(false);
    const [profilePick, setProfilePick] = React.useState(require('../images/profile_pick.png'));
    const [error, setError] = React.useState(null);
    firebase.app(); // if already initialized, use that one

    const setDataFromJson = (res) => {
        let tmpData = []
        if (res.data === null || res.data === undefined) {
            return ('null');
        } else {
            let count = 0
            for (let i in res.data) {
                let tmpJson = res.data[i];
                tmpJson["id"] = count;
                count++;
                tmpData.push(tmpJson);
            }
        }
        if (data != tmpData)
            setData(tmpData);
    };

    useEffect(() => {
        if (GLOBAL.user.photoURL !== null) {
            setProfilePick({ uri: GLOBAL.user.photoURL });
        }
        const address = 'http://' + GLOBAL.ip + ':8080/api/generic/link/get';
        const id = GLOBAL.user.uid;
        axios.get(address, { params: { id: id } })
            .then((response) => (setDataFromJson(response)))
            .catch((error) => (setError(error.message)));
    }, []);

    const logout = () => {
        setPressLog(true);
        GLOBAL.user = null;
        firebase
            .auth()
            .signOut();
        setPressLog(false);
        navigation.replace('Login');
    }

    BackHandler.addEventListener('hardwareBackPress', function () {
        return (true);
    });

    const renderItem = ({ item }) => {
        const backgroundColor = item.id === selectedId ? "lightgrey" : "grey";
        let dataCopy = JSON.parse(JSON.stringify(data));
        const onToggleSwitch = () => {
            dataCopy[Number(item.id)].activated = !item.activated;
            setData(dataCopy);
        };
        const onPressSettings = () => {
            console.log('Settings Items', item.id);
        }

        return (
            <Item
                style={StylesHome.item}
                item={item}
                onPressSettings={onPressSettings}
                onPressTicket={() => setSelectedId(item.id)}
                onToggleSwitch={onToggleSwitch}
                color={{ backgroundColor }}
            />
        );
    };
    const addService = () => {
        setPressAdd(true);
        setPressAdd(false);
        navigation.replace('AddAR');
    }
    const settings = () => {
        setPressSet(true);
        setPressSet(false);
        navigation.replace('Config')
    }

    const changeProfilePick = () => {
        console.log('change pick');
    }

    return (
        <View style={StylesHome.container}>
            <FlatList
                style={StylesHome.flatListContainer}
                data={data}
                renderItem={renderItem}
                keyExtractor={(item) => item.id}
                extraData={selectedId}
                ListHeaderComponent={
                    <View style={{backgroundColor: '#202020'}}>
                        <View style={StylesHome.profileContainer}>
                            <TouchableOpacity style={StylesHome.profilePick} onPress={changeProfilePick}>
                                <Image style={{ width: 100, height: 100, borderRadius: 50, }} source={profilePick}/>
                            </TouchableOpacity>
                            <Text style={StylesHome.profileName}>
                                {String((GLOBAL.user != null) ? GLOBAL.user.email.split('@')[0].replace('.', ' ') : '')}
                            </Text>
                            <Text style={StylesHome.textError}>{error}</Text>
                            <TouchableOpacity style={StylesHome.logoutButton} onPress={logout}>
                                <Text style={{ color: pressLog ? '#202020' : 'white'}}>LOGOUT</Text>
                            </TouchableOpacity>
                        </View>
                        <View style={StylesHome.rightButton}>
                            <TouchableOpacity style={StylesHome.settingsButton} onPress={settings}>
                                <Image style={{ width: 40, height: 40 }} source={require('../images/settings_icon.png')}/>
                            </TouchableOpacity>
                            <TouchableOpacity style={StylesHome.addButton} onPress={addService}>
                                <Text style={{ fontSize: 30, color: pressAdd ? '#202020' : 'white'}}>+</Text>
                            </TouchableOpacity>
                        </View>
                        <Image style={{ width: 161, height: 53.5, position: 'absolute' }} source={require('../images/area-logo.png')}/>
                    </View>
                }
                ListFooterComponent={
                    <View style={{ backgroundColor: '#202020' }}>
                        <Text style={{ color: '#202020'}}>Holla</Text>
                    </View>
                }
            />
        </View>
    );
}