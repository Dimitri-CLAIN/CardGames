import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import * as React from 'react';
import { ColorSchemeName } from 'react-native';

import NotFoundScreen from '../screens/NotFoundScreen';
import StartScreen from '../screens/StartScreen';
import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import HomeScreen from '../screens/HomeScreen';
import AddAR from '../screens/AddAR';
import ConfigScreen from '../screens/ConfigScreen'

import LinkingConfiguration from './LinkingConfiguration';

export default function Navigation({ colorScheme }: { colorScheme: ColorSchemeName }) {
    return (
        <NavigationContainer
            linking={LinkingConfiguration}
            theme={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
            <RootNavigator />
        </NavigationContainer>
    );
}

const Stack = createStackNavigator();

function RootNavigator() {
    return (
        <Stack.Navigator
            initialRootName="Start"
            screenOptions={{ headerShown: false }}
        >
            <Stack.Screen name="Start" component={StartScreen} options={{ title: 'Start' }}/>
            <Stack.Screen name="Login" component={LoginScreen} options={{ title: 'Login' }}/>
            <Stack.Screen name="Register" component={RegisterScreen} options={{ title: 'Register' }}/>
            <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Home' }}/>
            <Stack.Screen name="Config" component={ConfigScreen} options={{ title: 'Config' }}/>
            <Stack.Screen name="AddAR" component={AddAR} options={{ title: 'AddAR' }}/>
            <Stack.Screen name="NotFound" component={NotFoundScreen} options={{ title: 'Oops!' }} />
        </Stack.Navigator>
    );
}
