# B-DOP-500-NAN-5-1-mymarvin-marc-olivier.lauret

# Docker
    # Build
        docker build -t jenkins:jcasc .
    # Run
        docker run --name jenkins --rm -p 8080:8080 --env USER_CHOCOLATEEN_PASSWORD=hugo --env USER_VAUGIE_G_PASSWORD=garance --env USER_I_DONT_KNOW_PASSWORD=jeremy --env USER_NASSO_PASSWORD=nassim jenkins:jcasc
    # Auto Build and Run
        "install your distribution's inotify-tools package"
        while inotifywait -e close_write my_marvin.yml; do sudo docker build -t jenkins:jcasc . && sudo docker run --name jenkins --rm -p 8080:8080 --env USER_CHOCOLATEEN_PASSWORD=hugo --env USER_VAUGIE_G_PASSWORD=garance --env USER_I_DONT_KNOW_PASSWORD=jeremy --env USER_NASSO_PASSWORD=nassim jenkins:jcasc ; done

Go to http://localhost:8080/ to see your jenkins