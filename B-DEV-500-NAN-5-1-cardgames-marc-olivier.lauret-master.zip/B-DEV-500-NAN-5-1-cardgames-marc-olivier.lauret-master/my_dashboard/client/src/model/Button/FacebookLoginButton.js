import React, { Component } from 'react';
import FacebookLogin from 'react-facebook-login';

/**
* @author DimitriClain
* @function FacebookLoginButton
**/

const CLIENT_ID = "3544221988976684";

class FacebookLoginButton extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isLogined: false,
      accessToken: ''
    };
  }

  responseFacebook = (response) => {
    this.props.externConnection("email");
  }

  render() {
    return(
      <div>
        <FacebookLogin
          appId={ CLIENT_ID }
          fields="name,email,picture"
          scope="public_profile,user_friends"
          callback={ this.responseFacebook }
        />
      </div>
    );
  }
}

export default FacebookLoginButton