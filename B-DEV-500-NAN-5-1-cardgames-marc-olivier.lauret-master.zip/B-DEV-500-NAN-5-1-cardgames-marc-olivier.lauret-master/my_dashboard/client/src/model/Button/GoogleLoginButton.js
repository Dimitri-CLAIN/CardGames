import React, { Component } from 'react'
import GoogleLogin from 'react-google-login';

/**
* @author DimitriClain
* @function GoogleLoginButton
**/

const CLIENT_ID = "788662944219-qr7hi1h7i6ee466fpg9qrc5kj3koq507.apps.googleusercontent.com";

class GoogleLoginButton extends Component {

  signin = (res) => {
    this.props.externConnection(res.profileObj.email, res.profileObj.name, res.profileObj.googleId);
  }

  render() {
    const responseGoogle = (response) => {
      this.signin(response);
    }
    return(
      <div>
        <GoogleLogin
          clientId={ CLIENT_ID }
          buttonText='Login with Google'
          onSuccess={ responseGoogle }
          onFailure={ responseGoogle }
        />
      </div>
    );
  }
}

export default GoogleLoginButton