import React from 'react'

/**
* @author DimitriClain
* @function LogoutButton
**/

const LogoutButton = (props) => {
  return(
    <div>LogoutButton</div>
  )

}

export default LogoutButton