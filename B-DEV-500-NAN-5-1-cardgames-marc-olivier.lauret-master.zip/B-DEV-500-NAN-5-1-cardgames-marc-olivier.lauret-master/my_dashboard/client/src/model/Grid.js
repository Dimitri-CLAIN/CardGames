import React from "react";
import { WidthProvider, Responsive } from "react-grid-layout";
import _ from "lodash";
import Weather from "../model/Widgets/Weather";
import YTVideo from "../model/Widgets/YTVideo";
import YTChannel from "../model/Widgets/YTChannel";
import Imgur from "../model/Widgets/Imgur";
import ImgurPost from "../model/Widgets/ImgurPost";

const ResponsiveReactGridLayout = WidthProvider(Responsive);

/**
 * This layout demonstrates how to use a grid with a dynamic number of elements.
 */
export default class AddRemoveLayout extends React.PureComponent {
  static defaultProps = {
    className: "layout",
    cols: { lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 },
    rowHeight: 100
  };

  constructor(props) {
    super(props);

    this.state = {
      items: [],
      newCounter: 0
    };

    this.GetWeatherParams();
    this.GetImgurParams();
    this.GetYoutubeVideoParams();
    this.GetYoutubeChannelParams();
    this.onAddYTVideo = this.onAddYTVideo.bind(this);
    this.onAddYTChannel = this.onAddYTChannel.bind(this);
    this.onAddImgur = this.onAddImgur.bind(this);
    this.onAddImgurPost = this.onAddImgurPost.bind(this);
    this.onAddWeather = this.onAddWeather.bind(this);
    this.onBreakpointChange = this.onBreakpointChange.bind(this);
  }
  // TODO:
  // App is listening on port 8080
  // server_1  | /usr/app/server/sqlReq.js:217
  // server_1  |             response.status(200).json({code: 200, id: results.rows[0].imgurToken});
  // server_1  |                                                                       ^
  // server_1  |
  // server_1  | TypeError: Cannot read property 'imgurToken' of undefined
  // server_1  |     at /usr/app/server/sqlReq.js:217:71

  GetImgurParams() {
    fetch('http://localhost:8080/api/imgurParams/' + localStorage.getItem("CLIENT_ID"), {
        headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
        },
        method: 'GET',
        mode: 'cors',
        cache: 'default'
    })
    .then(res => res.json())
    .then(res => {
        if (res.code === 200) {
          if ("imgurToken" in res.id && res.id.imgurToken !== undefined && res.id.imgurToken !== null) {
            this.onAddImgur();
            this.onAddImgurPost();
          }
        }
    });
  }

  GetWeatherParams() {
    fetch('http://localhost:8080/api/' + localStorage.getItem("CLIENT_ID") + '/weather', {
        headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
        },
        method: 'GET',
        mode: 'cors',
        cache: 'default'
    })
    .then(res => res.json())
    .then(res => {
            if (res.results.length > 0) {
                var weatherState = {
                  Settings: false,
                  city: res.results[0].city,
                  language: res.results[0].language,
                  units: res.results[0].units
                };
                this.onAddWeather(weatherState);
            }
        }
    );
  }

  GetYoutubeVideoParams() {
    fetch('http://localhost:8080/api/youtube/info/video/' + localStorage.getItem("CLIENT_ID"), {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'GET',
        })
        .then(res => res.json())
        .then(res => {
          if (res.id !== undefined && res.id.videoname !== undefined && res.id.videoname.length !== 0) {
            this.onAddYTVideo();
        }
      })
  }

  GetYoutubeChannelParams() {
    fetch('http://localhost:8080/api/youtube/info/channel/' + localStorage.getItem("CLIENT_ID"), {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'GET',
        })
        .then(res => res.json())
        .then(res => {
            if (res.id !== undefined && res.id.channelname !== undefined && res.id.channelname.length !== 0) {
              this.onAddYTChannel();
            }
        })
  }

  createElement(el) {
    const removeStyle = {
      position: "absolute",
      right: "2px",
      top: 0,
      cursor: "pointer"
    };
    const i = el.i;
    return (
      <div key={i} data-grid={el} className={el.type}>
        {
          el.data
        }
        <span
          className="remove"
          style={removeStyle}
          onClick={this.onRemoveItem.bind(this, i)}
        >
          x
        </span>
      </div>
    );
  }

  onAddYTVideo() {
    this.setState({
      items: this.state.items.concat({
        i: "n" + this.state.newCounter,
        x: (this.state.items.length * 2) % (this.state.cols || 12),
        y: Infinity,
        w: 2,
        h: 2,
        data: <YTVideo/>,
        type: "YTVideoWidget"
      }),
      newCounter: this.state.newCounter + 1
    });
  }

  onAddYTChannel() {
    this.setState({
      items: this.state.items.concat({
        i: "n" + this.state.newCounter,
        x: (this.state.items.length * 2) % (this.state.cols || 12),
        y: Infinity,
        w: 2,
        h: 2,
        data: <YTChannel/>,
        type: "YTChannelWidget"
      }),
      newCounter: this.state.newCounter + 1
    });
  }

  onBreakpointChange(breakpoint, cols) {
    this.setState({
      breakpoint: breakpoint,
      cols: cols
    });
  }

  onRemoveItem(i) {
    this.setState({ items: _.reject(this.state.items, { i: i }) });
  }

  onAddWeather(weatherState) {
    this.setState({
      items: this.state.items.concat({
        i: "n" + this.state.newCounter,
        x: (this.state.items.length * 2) % (this.state.cols || 12),
        y: Infinity,
        w: 2,
        h: 2,
        data: <Weather
            Settings={weatherState.Settings}
            city={weatherState.city}
            language={weatherState.language}
            units={weatherState.units}
          />,
        type: "WeatherWidget"
      }),
      newCounter: this.state.newCounter + 1
    });
  }

  onAddImgur() {
    this.setState({
      items: this.state.items.concat({
        i: "n" + this.state.newCounter,
        x: (this.state.items.length * 2) % (this.state.cols || 12),
        y: Infinity,
        w: 2,
        h: 2,
        data: <Imgur/>,
        type: "ImgurWidget"
      }),
      newCounter: this.state.newCounter + 1
    });
  }

  onAddImgurPost() {
    this.setState({
      items: this.state.items.concat({
        i: "n" + this.state.newCounter,
        x: (this.state.items.length * 2) % (this.state.cols || 12),
        y: Infinity,
        w: 2,
        h: 2,
        data: <ImgurPost/>,
        type: "ImgurWidget"
      }),
      newCounter: this.state.newCounter + 1
    });
  }

  render() {
    var weatherState = {
      Settings: true,
      city: 'Paris',
      language: 'fr',
      units: 'metric'
    }
    return (
      <div className= "widgetdoard">
        <button onClick={this.onAddYTVideo}>Add Youtube Video Widget</button>
        <button onClick={this.onAddYTChannel}>Add Youtube Channel Widget</button>
        <button onClick={() => this.onAddWeather(weatherState)}>Add Weather Widget</button>
        <button onClick={this.onAddImgur}>Add My Imgur posts Widget</button>
        <button onClick={this.onAddImgurPost}>Add Imgur post Widget</button>
        <ResponsiveReactGridLayout
            onBreakpointChange={this.onBreakpointChange}
            {...this.props}
        >
            {_.map(this.state.items, el => this.createElement(el))}
        </ResponsiveReactGridLayout>
      </div>
    );
  }
}