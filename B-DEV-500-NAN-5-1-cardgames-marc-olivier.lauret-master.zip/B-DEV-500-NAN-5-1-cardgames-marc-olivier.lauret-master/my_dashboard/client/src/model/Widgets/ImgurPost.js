import React, { Component } from 'react';
import ImgurLogin from '../Button/Imgur/ImgurLogin';
import "../grid.css";

/**
* @author DimitriClain
* @function ImgurPost
**/

class ImgurPost extends Component {
    constructor(props) {
        super(props);
        this.state = {
            Settings: true,
            title: 'Title',
            description: 'Description',
            url: 'Url',
            accessToken: 'Null'
        };
    }

    getUserID() {
        return (localStorage.getItem("CLIENT_ID"));
    }

    authImgur = (data) => {
        this.setState({accessToken: data.access_token});
    }

    async SettingsStatus() {
        if (this.state.Settings === true) {
            await this.initImgurParameters(this.getUserID());
            this.setState({Settings: false});
            if (this.state.accessToken === 'Null') {
                await this.updateImgurParams(this.getUserID(), this.state.accessToken);
            }
        } else if (this.state.Settings === false)
            this.setState({Settings: true});
    }

    initImgurParameters(userId) {
        fetch('http://localhost:8080/api/imgurParams/' + userId, {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'GET',
            mode: 'cors',
            cache: 'default'
        })
        .then(res => res.json())
        .then(res => {
            console.log(res);
            if (res.code === 200 && res.id !== null) {
                this.setState({accessToken: res.id});
            } else {
                this.setState({Settings: true, accessToken: 'Null'})
            }
        });
    }

    updateImgurParams(userId, accessToken) {
        fetch('http://localhost:8080/api/imgurParams/' + userId, {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'PUT',
            body: JSON.stringify({
                id: accessToken
            })
        })
        .then(res => res.json())
        .then(res => {
            console.log(res.message);
        });
    }

    getPostOnImgur(imageUrl, title, description, accessToken) {
        fetch('http://localhost:8080/api/imgur/posts/' + accessToken, {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'POST',
            body: JSON.stringify({
                imageUrl: imageUrl,
                title: title,
                description: description
            })
        })
        .then(res => res.json())
        .then(res => {
            alert(res.message);
        });
    }

    handleChange(event, type) {
        if (type === "title") {
            this.setState({title: event.target.value});
        }
        if (type === "description") {
            this.setState({description: event.target.value});
        }
        if (type === "url") {
            this.setState({url: event.target.value});
        }
    }

    renderImgurButton() {
        if (this.state.accessToken === 'Null')
            return (
            <div>
                <p>Please click on the Imgur button until it disappears</p>
                <ImgurLogin clientId='d7a68321a1386ac' onSuccess={this.authImgur}/>
            </div>);
        else
            return (<p>You are connected to Imgur, click on done.</p>);
    }

    render() {
        if (this.state.Settings === false) {
            return (
                <div>
                    <button onClick={() => this.SettingsStatus()}>Settings</button>
                    <div className="form-group">
                        <label>Title</label>
                        <input type="title" className="form-control" placeholder="Enter a title for the post"
                            value= {this.state.title} onChange={(e) => this.handleChange(e, "title")}
                        />
                    </div>
                    <br/>
                    <div className="form-group">
                        <label>Url</label>
                        <input type="url" className="form-control" placeholder="Enter a image url"
                            value= {this.state.url} onChange={(e) => this.handleChange(e, "url")}
                        />
                    </div>
                    <br/>
                    <div className="form-group">
                        <label>Description</label>
                        <input type="description" className="form-control" placeholder="Enter a image description"
                            value= {this.state.description} onChange={(e) => this.handleChange(e, "description")}
                        />
                    </div>
                    <br/>
                    <button className="btn btn-dark btn-lg btn-block" onClick={() => this.getPostOnImgur(this.state.url, this.state.title, this.state.description, this.state.accessToken)}>Post</button>
                </div>
            );
        } else {
            return (
                <div className="ImgurWidget">
                    <button onClick={() => this.SettingsStatus()}>Done</button>
                    {this.renderImgurButton()}
                </div>
            )
        }
    }
}

export default ImgurPost;