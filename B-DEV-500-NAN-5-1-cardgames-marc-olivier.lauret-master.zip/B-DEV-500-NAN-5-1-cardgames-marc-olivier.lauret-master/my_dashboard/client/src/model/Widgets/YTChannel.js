import React, { Component } from 'react';

class YTChannel extends Component {
    constructor(props) {
        super(props);
        this.state = {
            Settings: true,
            ChannelName: "",
            subscribers: 0,
            totalViews: 0,
            videoNb: 0
        };
    }

    componentDidMount() {
        this.getChanneldata()
    }

    getUserID() {
        return (localStorage.getItem("CLIENT_ID"));
    }

    async getChanneldata() {
        await fetch('http://localhost:8080/api/youtube/info/channel/' + this.getUserID(), {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'GET',
        })
        .then(res => res.json())
        .then(res => {
            if (res.id !== undefined && res.id.channelname !== undefined) {
                this.setState({ChannelName: res.id.channelname});
                this.getChannelInfo();
            }
        })
    }

    async setChannel() {
        var cname = this.state.ChannelName.replace('/',' ');
        await fetch('http://localhost:8080/api/' + this.getUserID() + '/youtubeChannel', {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'PUT',
            body: JSON.stringify({
                user_id: this.getUserID(),
                channelName: cname
            }),
        })
        .then(res => res.json())
        .then(res => {
            this.getChannelInfo()
        });
    }

    getChannelInfo() {
        fetch('http://localhost:8080/api/youtube/channel/' + this.state.ChannelName, {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'GET',
            mode: 'cors',
            cache: 'default'
        })
        .then(res => res.json())
        .then(res => {
            if (res.items !== undefined && res.items.length > 0)
                this.setState({subscribers: res.items[0].statistics.subscriberCount, totalViews: res.items[0].statistics.viewCount, videoNb: res.items[0].statistics.videoCount})
            if (this.state.subscribers === undefined)
                this.setState({subscribers: "Not Public"})
        });
    }

    SettingsStatus() {
        if (this.state.Settings === true) {
            this.setState({Settings: false});
            this.setChannel()
        }
        else if (this.state.Settings === false)
            this.setState({Settings: true});
    }

    handleChange(event) {
        this.setState({ChannelName: event.target.value});
    }

    render() {
        if (this.state.Settings === false) {
            return (
                <div>
                    <p>{this.state.ChannelName}</p>
                    <p>{"Subscribers: " + this.state.subscribers}</p>
                    <p>{"Number of Videos: " + this.state.videoNb}</p>
                    <p>{"Total of views: " + this.state.totalViews}</p>
                    <button onClick={() => this.SettingsStatus()}>Settings</button>
                </div>
            );
        }
        else {
            return (
                <div>
                    <div className="form-group">
                        <label>Channel name:</label>
                        <input type="text" className="form-control" placeholder="Enter a Youtube channel Name"
                            value= {this.state.ChannelName} onChange={(e) => this.handleChange(e)}
                        />
                    </div>
                    <button onClick={() => this.SettingsStatus()}>Done</button>
                </div>
            )
        }
    }
}

export default YTChannel;