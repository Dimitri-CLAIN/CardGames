import React, { Component } from 'react';
import Carousel from 'nuka-carousel';
import "../grid.css";
import ImgurLogin from '../Button/Imgur/ImgurLogin';

/**
* @author DimitriClain
* @function Imgur
**/

class Imgur extends Component {
    constructor(props) {
        super(props);
        this.state = {
            Settings: true,
            myPosts: [],
            isRealoding: false,
            accessToken: 'Null'
        };
    }

    getUserID() {
        return (localStorage.getItem("CLIENT_ID"));
    }

    authImgur = (data) => {
        this.setState({accessToken: data.access_token});
    }

    async SettingsStatus() {
        if (this.state.Settings === true) {
            await this.initImgurParameters(this.getUserID());
            this.setState({Settings: false});
            if (this.state.accessToken === 'Null') {
                await this.updateImgurParams(this.getUserID(), this.state.accessToken);
            }
        } else if (this.state.Settings === false)
            this.setState({Settings: true});
    }

    initImgurParameters(userId) {
        fetch('http://localhost:8080/api/imgurParams/' + userId, {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'GET',
            mode: 'cors',
            cache: 'default'
        })
        .then(res => res.json())
        .then(res => {
            console.log(res);
            if (res.code === 200 && res.id) {
                this.setState({accessToken: res.id});
            } else {
                this.setState({Settings: true})
            }
            console.log(this.state);
        });
    }

    updateImgurParams(userId, accessToken) {
        fetch('http://localhost:8080/api/imgurParams/' + userId, {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'PUT',
            body: JSON.stringify({
                id: accessToken
            })
        })
        .then(res => res.json())
        .then(res => {
            console.log(res.message);
        });
    }

    getMyImgurPosts(accessToken) {
        fetch('http://localhost:8080/api/imgur/posts/' + accessToken, {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'GET',
            mode: 'cors',
            cache: 'default'
        })
        .then(res => res.json())
        .then(res => {
            if (res.code === 200) {
                this.setState({myPosts: []});
                res.res.data.forEach((element, index) => {
                    this.state.myPosts.push({
                        title: element.title,
                        src: element.link,
                        alt: element.description
                    });
                });
                this.setState({isRealoding: true});
            }
        });
    }

    reload() {
        this.setState({isRealoding: false});
    }

    renderMyPosts(title, src, alt) {
        return(
            <img title={title} src={src} alt={alt}/>
        );
    }

    renderImgurButton() {
        if (this.state.accessToken === 'Null')
            return (
            <div>
                <p>Please click on the Imgur button until it disappears</p>
                <ImgurLogin clientId='d7a68321a1386ac' onSuccess={this.authImgur}/>
            </div>);
        else
            return (<p>You are connected to Imgur, click on done.</p>);
    }

    render() {
        if (this.state.Settings === false && this.state.isRealoding === false) {
            return (
                <div>
                    <button onClick={() => this.SettingsStatus()}>Settings</button>
                    <button className="btn btn-dark btn-lg btn-block" onClick={() => this.getMyImgurPosts(this.state.accessToken)}>Get my posts</button>
                    <Carousel dragging={false}>
                        {this.state.myPosts.map(element => {
                            return this.renderMyPosts(element.title, element.src, element.alt);
                        })}
                    </Carousel>
                </div>
            );
        } else if (this.state.isRealoding === true) {
            return (
                <div>
                    <p>Loading...</p>
                    {this.reload()}
                </div>
            );
        } else {
            return (
                <div className="ImgurWidget">
                    <button onClick={() => this.SettingsStatus()}>Done</button>
                    {this.renderImgurButton()}
                </div>
            )
        }
    }
}

export default Imgur;