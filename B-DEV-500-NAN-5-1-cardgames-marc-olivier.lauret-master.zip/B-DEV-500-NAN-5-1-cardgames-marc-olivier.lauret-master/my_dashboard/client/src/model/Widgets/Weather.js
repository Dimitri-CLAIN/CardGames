import React, { Component } from 'react';

/**
* @author DimitriClain
* @function Weather
**/

class Weather extends Component {
    constructor(props) {
        super(props);
        this.state = {
            Settings: props.Settings,
            city: props.city,
            language: props.language,
            units: props.units,
            data_city: "",
            data_temp: "",
            data_meteo: "",
            timer: 120
        };
        this.changeTimer = this.changeTimer.bind(this);
    }

    //this.changeTimer = this.changeTimer.bind(this);

    componentDidMount() {
        this.createWeather();
        this.GetParams(this.getUserID())
        this.interval = setInterval(() => this.updateWidget(), this.state.timer * 1000);
    }

    componentWillUnmount() {
        clearInterval(this.interval);
    }

    async Update_bd() {
        const data = {
            city: this.state.city,
            language: this.state.language,
            units: this.state.units
        };
        fetch('http://localhost:8080/api/weather/' + await this.GetWeatherWidget(), {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'PUT',
            body: JSON.stringify(data)
        })
        .then(res => res.json())
    }

    getUserID() {
        return (localStorage.getItem("CLIENT_ID"));
    }

    async GetWeatherWidget() {
        var id = '';
        await fetch('http://localhost:8080/api/' + this.getUserID() + '/weatherId', {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'GET',
            mode: 'cors',
            cache: 'default'
        })
        .then(res => res.json())
        .then(res => {
            id = res.id;
        });
        return (id)
    }

    async SettingsStatus() {
        if (this.state.Settings === true) {
            this.interval = setInterval(() => this.updateWidget(), this.state.timer * 1000);
            await this.Update_bd();
            this.GetParams(this.getUserID())
            this.setState({Settings: false});
        }
        else if (this.state.Settings === false) {
            clearInterval(this.interval);
            this.setState({Settings: true, city: "Paris", units: "metric", language: "fr"});
        }
    }

    updateUser(id, widget) {
        fetch('http://localhost:8080/api/' + id + '/weather', {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'POST',
            body: JSON.stringify({id: widget.id})
        })
        .then(res => res.json())
    }

    createWeather() {
        fetch('http://localhost:8080/api/weather/id', {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'POST',
            body: JSON.stringify({
                city: this.state.city,
                language: this.state.language,
                units: this.state.units
            })
        })
        .then(res => res.json())
        .then(res =>  {
            this.updateUser(this.getUserID(), res);
        });
    }



    GetParams(id) {
        fetch('http://localhost:8080/api/' + id + '/weather', {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'GET',
            mode: 'cors',
            cache: 'default'
        })
        .then(res => res.json())
        .then(res => {
                if (res.results.length > 0) {
                    this.city = res.results[0].city;
                    this.language = res.results[0].language;
                    this.units = res.results[0].units;
                    this.updateWidget();
                }
            }
        );
    }

    updateWidget() {
        const url = 'http://localhost:8080/api/weather/' + this.city + '/' + this.language + '/' + this.units;
        fetch(url, {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'GET',
            mode: 'cors',
            cache: 'default'
        })
        .then(res => res.json())
        .then(res => {
            this.setState({
                data_city: res.name,
                data_meteo: res.weather[0].description,
                data_temp: res.main.temp
            })
        });
    }

    changeTimer(e) {
        this.setState({timer: e.target.value});
    }

    render() {
        if (this.state.Settings === false) {
            var sign;
            if (this.state.units === 'metric')
                sign = '°C';
            else
                sign = '°F';
            return (
                <div>
                    {this.state.data_city}
                    <br/>
                    {this.state.data_temp + sign}
                    <br/>
                    {this.state.data_meteo}
                    <br/>
                    <button onClick={() => this.SettingsStatus()}>Settings</button>
                </div>
            );
        }
        else {
            return (
                <div>
                    <label for="city-select">City:</label>
                    <select className="city">
                        <option value="Paris" onClick={() => this.setState({city: "Paris"})}>Paris</option>
                        <option value="Nantes" onClick={() => this.setState({city: "Nantes"})}>Nantes</option>
                        <option value="Bordeaux" onClick={() => this.setState({city: "Bordeaux"})}>Bordeaux</option>
                        <option value="Marseille" onClick={() => this.setState({city: "Marseille"})}>Marseille</option>
                        <option value="Strasbourg" onClick={() => this.setState({city: "Strasbourg"})}>Strasbourg</option>
                        <option value="Rennes" onClick={() => this.setState({city: "Rennes"})}>Rennes</option>
                    </select>
                    <br/>
                    <label for="language-select">Language:</label>
                    <select className="city">
                        <option value="fr" onClick={() => this.setState({language: "fr"})}>Français</option>
                        <option value="en" onClick={() => this.setState({language: "en"})}>English</option>
                    </select>
                    <br/>
                    <label for="Units-select">Units:</label>
                    <select className="Units">
                        <option value="metric" onClick={() => this.setState({units: "metric"})}>Metric</option>
                        <option value="imperial" onClick={() => this.setState({units: "imperial"})}>Imperial</option>
                    </select>
                    <br/>
                    <label for="Units-select">Timer (seconds):</label>
                    <input type="number" value={this.state.timer} onChange={this.changeTimer} />
                    <br/>
                    <button onClick={() => this.SettingsStatus()}>Done</button>
                </div>
            )
        }
    }
}

export default Weather;