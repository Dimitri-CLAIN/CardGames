import React, { Component } from 'react';

class YTVideo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            Settings: true,
            VideoName: "",
            Comments: "",
            Views: 0,
            Likes: 0
        };
    }

    componentDidMount() {
        this.getVideo();
    }

    getUserID() {
        return (localStorage.getItem("CLIENT_ID"));
    }

    async getVideo() {
        await fetch('http://localhost:8080/api/youtube/info/video/' + this.getUserID(), {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'GET',
        })
        .then(res => res.json())
        .then(res => {
            if (res.id !== undefined && res.id.videoname !== undefined) {
                this.setState({VideoName: res.id.videoname});
                this.getVideoComments();
            }
        })
    }

    async setVideo() {
        await fetch('http://localhost:8080/api/' + this.getUserID() + '/youtubeVideo', {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'PUT',
            body: JSON.stringify({
                user_id: this.getUserID(),
                videoName: this.state.VideoName.replace('/',' ')
            }),
        })
        .then(res => res.json())
        .then(res => {
            this.getVideoComments()
        });
    }

    getVideoComments() {
        var vname = this.state.VideoName.replace('/',' ');
        if (vname.length === 0)
            return;
        fetch('http://localhost:8080/api/youtube/commentThreads/' + vname, {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'GET',
            mode: 'cors',
            cache: 'default'
        })
        .then(res => res.json())
        .then(res => {
            if (res.items !== undefined && res.items.length > 0)
                this.setState({Comments: res.items[0].snippet.topLevelComment.snippet.textOriginal})
            else
                this.setState({Comments: "This video has no comments."})
        });
        fetch('http://localhost:8080/api/youtube/statistics/' + vname, {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'GET',
            mode: 'cors',
            cache: 'default'
        })
        .then(res => res.json())
        .then(res => {
            if (res.items !== undefined && res.items.length > 0)
                this.setState({Likes: res.items[0].statistics.likeCount, Views: res.items[0].statistics.viewCount});
        });
    }

    SettingsStatus() {
        if (this.state.Settings === true) {
            this.setState({Settings: false});
            this.setVideo()
        }
        else if (this.state.Settings === false)
            this.setState({Settings: true});
    }

    handleChange(event) {
        this.setState({VideoName: event.target.value});
    }

    render() {
        if (this.state.Settings === false) {
            return (
                <div>
                    <p>{this.state.VideoName}</p>
                    <p>{"Views: " + this.state.Views}</p>
                    <p>{"Likes:" + this.state.Likes}</p>
                    <p>{"Last comment:\n" + this.state.Comments}</p>
                    <button onClick={() => this.SettingsStatus()}>Settings</button>
                </div>
            );
        }
        else {
            return (
                <div>
                    <div className="form-group">
                        <label>Video name:</label>
                        <input type="text" className="form-control" placeholder="Enter a Youtube Video Name"
                            value= {this.state.VideoName} onChange={(e) => this.handleChange(e)}
                        />
                    </div>
                    <button onClick={() => this.SettingsStatus()}>Done</button>
                </div>
            )
        }
    }
}

export default YTVideo;