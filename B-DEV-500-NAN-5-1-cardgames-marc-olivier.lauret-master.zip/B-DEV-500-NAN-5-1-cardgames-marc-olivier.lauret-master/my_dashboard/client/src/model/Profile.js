import React from 'react'

/**
* @author DimitriClain
* @function Profile
**/

const Profile = (props) => {
  return(
    <div>Profile</div>
  )

}

export default Profile