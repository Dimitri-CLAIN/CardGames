import React, { Component } from 'react';
import GoogleLoginButton from './Button/GoogleLoginButton';

/**
* @author DimitriClain
* @function Login
**/

export default class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            username: '',
            email: '',
            password: '',
            loginstatus: 0
        };
    }

    addUserToServer = (username, email, password) => {
        var user = {username, email, password};

        fetch('http://localhost:8080/api/users', {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'post',
            body: JSON.stringify(user)
        })
        .then(res => res.json())
        .then(res => {
            if (res.code === 201) {
                localStorage.setItem("CLIENT_ID", res.id);
                window.location.reload();
            }
            else {
                this.setState({loginstatus: res.code})
                console.log("FAILURE");
            }
        })
      }

    externConnection = (email, name, id) =>  {
        this.setState({username: name, email: email, password: id});
        fetch('http://localhost:8080/api/users/externLogin', {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'POST',
            body: JSON.stringify({email: email})
        })
        .then(res => res.json())
        .then(res => {
            if (res.code === 200)
                this.handleLogin(res.id);
            else {
                this.addUserToServer(name, email, id);
            }
        })
    }

    handleChange(event, type) {
        if (type === "email") {
            this.setState({email: event.target.value});
        }
        if (type === "password") {
            this.setState({password: event.target.value});
        }
    }

    handleLogin(id) {
        localStorage.setItem("CLIENT_ID", id);
        window.location.reload();
    }

    sendLogin() {
        fetch('http://localhost:8080/api/users/login', {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'post',
            body: JSON.stringify(this.state)
        })
        .then(res => res.json())
        .then(res => {
            if (res.code === 200)
                this.handleLogin(res.id);
            else
                this.setState({loginstatus: res.code})
        })
    }

    loginErrorDisplay() {
        if (this.state.loginstatus === 406)
            return (<div className="loginError"><p className="loginErrorMessage">Incorrect password</p></div>)
        if (this.state.loginstatus === 404)
            return (<div className="loginError"><p className="loginErrorMessage">Account not found</p></div>)
    }

    render() {
        return (
            <div>
                <h3>Log in</h3>

                <div className="form-group">
                    <label>Email</label>
                    <input type="email" className="form-control" placeholder="Enter email"
                        value= {this.state.email} onChange={(e) => this.handleChange(e, "email")}
                    />
                </div>
                <br/>
                <div className="form-group">
                    <label>Password</label>
                    <input type="password" className="form-control" placeholder="Enter password"
                        value= {this.state.password} onChange={(e) => this.handleChange(e, "password")}
                    />
                </div>
                <button className="btn btn-dark btn-lg btn-block" onClick={() => this.sendLogin()}>Sign in</button>
                <p className="unregister text-right">
                    Not registered ?
                    <br/>
                    <button onClick={() => this.props.history.push("/signup/")}>sign up</button>
                </p>
                <GoogleLoginButton externConnection = {this.externConnection}/>
                {this.loginErrorDisplay()}
            </div>
        );
    }
}