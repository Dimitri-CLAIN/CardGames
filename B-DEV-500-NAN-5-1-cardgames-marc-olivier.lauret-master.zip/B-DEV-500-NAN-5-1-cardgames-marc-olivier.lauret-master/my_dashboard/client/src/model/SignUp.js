import React, { Component } from 'react';

/**
* @author DimitriClain
* @function SignUp
**/

export default class SignUp extends Component {
    constructor(props) {
        super(props);
        this.state = {
            username: '',
            email: '',
            password: '',
            loginstatus: 0
        };
    }

    add_user_to_server = (username, email, password) => {
        var user = {username, email, password};

        fetch('http://localhost:8080/api/users', {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            method: 'post',
            body: JSON.stringify(user)
        })
        .then(res => res.json())
        .then(res => {
            if (res.code === 201) {
                this.props.history.push("/login/");
                window.location.reload();
            }
            else {
                this.setState({loginstatus: res.code})
                console.log("FAILURE");
            }
        })
      }

    loginErrorDisplay() {
        if (this.state.loginstatus === 501)
            return (<div className="loginError"><p className="loginErrorMessage">Unable to create the account with the given email address. Please try another email address.</p></div>)
        else if (this.state.loginstatus === 500)
        return (<div className="loginError"><p className="loginErrorMessage">An error occurred while creating an account.</p></div>)
    }

    handleChange(event, type) {
        if (type === "username") {
            this.setState({username:event.target.value});
        }
        if (type === "email") {
            this.setState({email:event.target.value});
        }
        if (type === "password") {
            this.setState({password:event.target.value});
        }
    }

    render() {
        return (
            <div>
                <h3>Register</h3>

                <div className="form-group">
                    <label>User name</label>
                    <input type="text" className="form-control" placeholder="User name"
                        value= {this.state.username} onChange={(e) => this.handleChange(e, "username")}
                    />
                </div>

                <div className="form-group">
                    <label>Email</label>
                    <input type="email" className="form-control" placeholder="Enter email"
                        value= {this.state.email} onChange={(e) => this.handleChange(e, "email")}
                    />
                </div>

                <div className="form-group">
                    <label>Password</label>
                    <input type="password" className="form-control" placeholder="Enter password"
                        value= {this.state.password} onChange={(e) => this.handleChange(e, "password")}
                    />
                </div>
                <button type="submit" className="btn btn-dark btn-lg btn-block" onClick= {()=>this.add_user_to_server(this.state.username, this.state.email, this.state.password)}>Register</button>
                <p className="forgot-password text-right">
                    Already registered ?
                    <br/>
                    <button onClick={() => this.props.history.push("/login/")}>log in</button>
                </p>
                {this.loginErrorDisplay()}
            </div>
        );
    }
}