import React, { Component } from 'react';
import AddRemoveLayout from '../model/Grid';

class HomePage extends Component {

  constructor(props){
    super(props);
    this.state = {
    }
  }

  logout() {
    localStorage.removeItem("CLIENT_ID");
    window.location.reload();
  }

  render() {
    return (
      <div className= "HomePage">
        <h1>HOMEPAGE</h1>
        <button onClick={() => this.logout()}>logout</button>
        <AddRemoveLayout/>
      </div>
    );
  }
}

export default HomePage;