import React, { Component } from 'react';
import Login from "../model/Login";
import SignUp from "../model/SignUp";
import Error from "../controller/Error";
import { Route, Switch } from 'react-router-dom';
import { Redirect } from 'react-router-dom';

class NotLogIn extends Component {
  constructor(props){
    super(props);
    this.state = {
    }
  }

  render() {
    return (
          <div className="inner">
            <Redirect to={"/login"}/>
             <Switch>
               <Route exact path='/login' render={(props) => <Login {...props}/>}/>
               <Route exact path='/signup' render={(props) => <SignUp {...props}/>}/>
               <Route path='/' render={(props) => <Error urlredirection= {"/login"} {...props}/>}/>
             </Switch>
           </div>
    );
  }
}

export default NotLogIn;