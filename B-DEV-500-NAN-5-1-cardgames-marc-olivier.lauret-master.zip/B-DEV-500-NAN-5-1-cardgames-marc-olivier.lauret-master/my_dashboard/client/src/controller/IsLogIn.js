import React, { Component } from 'react';
import Error from "../controller/Error";
import { Route, Switch } from 'react-router-dom';
import HomePage from '../view/HomePage';
import { Redirect } from 'react-router-dom';

class NotLogIn extends Component {
  constructor(props){
    super(props);
    this.state = {
    }
  }

  render() {
    return (
          <div className="home">
              <Redirect to={"/dashboard"}/>
             <Switch>
               <Route exact path='/dashboard' render={(props) => <HomePage {...props}/>}/>
               <Route path='/' render={(props) => <Error urlredirection= {"/dashboard"} {...props}/>}/>
             </Switch>
           </div>
    );
  }
}

export default NotLogIn;