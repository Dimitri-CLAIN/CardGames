import React, { Component } from 'react';
import PublicRoute from "./controller/PublicRoute";
import PrivateRoute from "./controller/PrivateRoute"



import './App.css';
import NotLogIn from './controller/NotLogIn';
import IsLogIn from './controller/IsLogIn';

class App extends Component {
  constructor(props){
    super(props);
    this.state = {
      reloading: false
    }
  }

  getUserID() {
    console.log(localStorage.getItem("CLIENT_ID"));
}


  render() {
    return (
      <div className="App">
        <div className= "outer">
          <PrivateRoute component={IsLogIn}/>
          <PublicRoute restricted={true} component={NotLogIn}/>
        </div>
      </div>
    );
  }
}

export default App;