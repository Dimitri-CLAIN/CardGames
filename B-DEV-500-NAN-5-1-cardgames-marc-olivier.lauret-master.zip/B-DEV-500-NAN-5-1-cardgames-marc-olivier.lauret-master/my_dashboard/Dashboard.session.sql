  SELECT weatherid FROM users WHERE id= '04db2236-ae88-4dc1-a202-bcf8001e2ead'
