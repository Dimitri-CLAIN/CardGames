const bcrypt = require('bcryptjs');
const Pool = require('pg').Pool;

const pool = new Pool({
    user: 'postgres',
    host: 'mydb',
    database: 'Dashboard',
    password: 'postgres',
    port: 5432,
})

// Basic User //

exports.addUser = function(request, response) {
    const { username, email, password } = request.body;
    try {
        const hashPass = bcrypt.hashSync(password, 10);

        pool.query('INSERT INTO users (username, email, password, videoName, channelName) values ($1, $2, $3, $4, $5) RETURNING id',
        [username, email, hashPass, "", ""], (error, results) => {
            if (error)
                response.status(500).json({code: 500, message: 'An error occured in the registration'});
            else
                response.status(201).json({code: 201, message: 'user added.', id: results.rows[0].id});
        });
    } catch {
        response.status(500).json({code: 500, message: 'An error occured in the register'});
    }
}

exports.getUsers = function(request, response) {
    pool.query('SELECT * FROM users ORDER BY id ASC',
        (error, results) => {
            if (error)
                response.status(500).json({code: 500, message: 'An error occured in the register'});
            response.status(200).json({code: 200, users: results.rows});
    });
}

exports.externLogin = function (request, response) {
    const { email } = request.body;

    pool.query('SELECT id, email FROM users WHERE email=$1', [email],
        (error, results) => {
            if (results.rows.length > 0) {
                const first = results.rows[0];
                response.status(200).json({code: 200, id: first.id});
            } else {
                response.status(404).json({code: 404, message: 'Email not found'});
            }
    });
}

exports.login = function (request, response) {
    const { email, password } = request.body;

    pool.query('SELECT id, email, password FROM users WHERE email=$1', [email],
        (error, results) => {
            if(results.rows.length > 0) {
                const first = results.rows[0];
                if (bcrypt.compareSync(password, first.password))
                    response.status(200).json({code: 200, id: first.id});
                else
                    response.status(406).json({code: 406, message: 'Incorrect password'});
            } else {
                response.status(404).json({code: 404, message: 'Email not found'});
            }
    });
}

// Weather //

exports.createWeatherParams = function(request, response) {
    const { city, language, units } = request.body;

    pool.query('INSERT INTO weatherParams (city, language, units) values ($1, $2, $3) RETURNING id',
        [city, language, units], (error, results) => {
            if (error)
                response.status(500).json({code: 500, message: 'An error occured in the creation of wheather params'});
            else {
                response.status(201).json({code: 201, message: 'Add wheather params', id: results.rows[0].id});
            }
        }
    );
}

exports.getUserWeatherId = function(request, response) {
    const userId = request.params.userId;
    pool.query('SELECT weatherid FROM users WHERE id=$1', [userId], (error, results) => {
        if (error)
            response.status(500).json({code: 500, message: 'Unable to get the Weather Id'});
        else
            response.status(200).json({code: 200, id: results.rows[0].weatherid});
        }
    );
}

exports.updateWeatherParamsClientId = function(request, response) {
    const userId = request.params.userId;
    const { id } = request.body;

    pool.query('UPDATE users SET weatherId=$1 WHERE id=$2',
        [id, userId], (error, results) => {
            if (error)
                response.status(500).json({code: 500, message: 'An error occured when update wheather params id in user'});
            else
                response.status(200).json({code: 200, message: 'Update wheather id successfully'});
        }
    );
}

exports.updateWeatherParamsById = function(request, response) {
    const id = request.params.id;
    const { city, language, units } = request.body;

    pool.query('UPDATE weatherparams SET city=$1, language=$2, units=$3 WHERE id=$4',
        [city, language, units, id], (error, results) => {
            if (error)
                response.status(500).json({code: 500, message: 'An error occured when update wheather params'});
            else
                response.status(200).json({code: 200, message: 'Update wheather params successfully'});
        }
    );
}

exports.getWeatherParamsById = function(request, response) {
    const userId = request.params.userId;

    pool.query('SELECT weatherparams.city, weatherparams.language, weatherparams.units FROM users INNER JOIN weatherparams ON users.weatherid = weatherparams.id WHERE users.id = $1',
    [userId], (error, results) => {
        if (error)
            response.status(500).json({code: 500, message: 'An error occured in the recovery of wheather params'});
        else
            response.status(201).json({code: 201, message: 'Get wheather params', results: results.rows});
    });
}

// Youtube //

exports.setYoutubeVideoParamas = function(request, response) {
    const {videoName, user_id} = request.body;

    pool.query('UPDATE users SET videoName=$1 WHERE id=$2', [videoName, user_id], (error, results) => {
        if (error)
            response.status(500).json({code: 500, message: 'An error occured: cannot set the Youtube Video param'});
        else {
            response.status(201).json({code: 201, message: 'Add youtube video param'});
        }
    })
}

exports.setYoutubeChannelParamas = function(request, response) {
    const {channelName, user_id} = request.body;

    pool.query('UPDATE users SET channelName=$1 WHERE id=$2', [channelName, user_id], (error, results) => {
        if (error)
            response.status(500).json({code: 500, message: 'An error occured: cannot set the Youtube Channel param'});
        else {
            response.status(201).json({code: 201, message: 'Add youtube channel param'});
        }
    })
}

exports.getYoutubeChannelInfo = function(request, response) {
    const userId = request.params.userId;

    pool.query('SELECT channelName FROM users WHERE id=$1', [userId], (error, results) => {
        if (error)
            response.status(500).json({code: 500, message: 'Unable to get the Youtube Channel Name'});
        else
            response.status(200).json({code: 200, id: results.rows[0]});
    });
}

exports.getYoutubeVideoInfo = function(request, response) {
    const userId = request.params.userId;

    pool.query('SELECT videoName FROM users WHERE id=$1', [userId], (error, results) => {
        if (error)
            response.status(500).json({code: 500, message: 'Unable to get the Youtube Video Name'});
        else
            response.status(200).json({code: 200, id: results.rows[0]});
    });
}

exports.updateYoutubeParamsClientId = function(request, response) {
    const userId = request.params.userId;
    const { id } = request.body;

    pool.query('UPDATE users SET youtubeId=$1 WHERE id=$2',
        [id, userId], (error, results) => {
            if (error)
                response.status(500).json({code: 500, message: 'An error occured when update youtube params id in user'});
            else
                response.status(200).json({code: 200, message: 'Update youtube id successfully'});
        }
    );
}

exports.updateYoutubeParamsById = function(request, response) {
    const id = request.params.id;
    const { videoName, channelName } = request.body;

    pool.query('UPDATE youtubeParams SET videoName=$1, channelName=$2 WHERE id=$3',
        [videoName, channelName, id], (error, results) => {
            if (error)
                response.status(500).json({code: 500, message: 'An error occured when update youtube params'});
            else
                response.status(200).json({code: 200, message: 'Update youtube params successfully'});
        }
    );
}

exports.getYoutubeParamsByClientId = function(request, response) {
    const userId = request.params.userId;

    pool.query('SELECT youtubeparams.videoName, youtubeparams.channelName FROM users INNER JOIN youtubeparams ON users.youtubeid = youtubeparams.id WHERE users.id = $1',
    [userId], (error, results) => {
        if (error)
            response.status(500).json({code: 500, message: 'An error occured in the recovery of youtube params'});
        else
            response.status(201).json({code: 201, message: 'Get youtube params', results: results.rows});
    });
}

// IMGUR //

exports.updateImgurTokenFromClient = function(request, response) {
    const userId = request.params.userId;
    const { id } = request.body;

    pool.query('UPDATE users SET imgurToken=$1 WHERE id=$2',
        [id, userId], (error, results) => {
            if (error)
                response.status(500).json({code: 500, message: 'An error occured when update imgur params id in user'});
            else
                response.status(200).json({code: 200, message: 'Update imgur id successfully'});
        }
    );
}

exports.getImgurTokenFromClient = function(request, response) {
    const userId = request.params.userId;

    pool.query('SELECT imgurToken FROM users WHERE id=$1', [userId], (error, results) => {
        if (error)
            response.status(500).json({code: 500, message: 'Unable to get the Imgur token'});
        else
            response.status(200).json({code: 200, id: results.rows[0]});
    });
}
