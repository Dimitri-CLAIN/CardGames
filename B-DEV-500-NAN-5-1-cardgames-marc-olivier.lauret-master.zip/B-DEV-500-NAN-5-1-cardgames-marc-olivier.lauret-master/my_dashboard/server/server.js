const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const sqlReq = require('./sqlReq.js');

const { getWeather } = require('./API/Weather/weather');
const { getVideoStatistics, getVideoCommentThreads, getYoutubeChannel } = require('./API/Youtube/youtubeStatistics');
const { getMyImgurPosts, postImgurImage } = require('./API/Imgur/imgur.js');
const about = require('./API/about');

const app = express();
app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
app.use(cors());

app.route('/api/debug')
  .get(sqlReq.getUsers);

app.route('/api/users')
    .get(sqlReq.getUsers)
    .post(sqlReq.addUser);

app.route('/api/users/login')
  .post(sqlReq.login);

app.route('/api/users/externLogin')
  .post(sqlReq.externLogin);

app.route('/api/:userId/weather')
  .get(sqlReq.getWeatherParamsById)
  .post(sqlReq.updateWeatherParamsClientId);

app.route('/api/:userId/weatherId')
  .get(sqlReq.getUserWeatherId);

app.route('/api/weather/:id')
  .post(sqlReq.createWeatherParams)
  .put(sqlReq.updateWeatherParamsById);

app.route('/api/weather/:city/:language/:units')
  .get(getWeather);

              /* YOUTUBE API */
app.route('/api/:userId/youtubeParams')
  .get(sqlReq.getYoutubeParamsByClientId)
  .put(sqlReq.updateYoutubeParamsClientId);

app.route('/api/:userId/youtubeVideo')
  .put(sqlReq.setYoutubeVideoParamas)

app.route('/api/:userId/youtubeChannel')
  .put(sqlReq.setYoutubeChannelParamas)

app.route('/api/youtubeParams/:id')
  .put(sqlReq.updateYoutubeParamsById);

app.route('/api/youtube/statistics/:videoName')
  .get(getVideoStatistics);

app.route('/api/youtube/commentThreads/:videoName')
  .get(getVideoCommentThreads);

app.route('/api/youtube/info/video/:userId')
 .get(sqlReq.getYoutubeVideoInfo);

app.route('/api/youtube/info/channel/:userId')
 .get(sqlReq.getYoutubeChannelInfo);

app.route('/api/youtube/channel/:channelName')
  .get(getYoutubeChannel);
              //// TODO: save les params

              /* IMGUR API */

app.route('/api/imgurParams/:userId')
  .put(sqlReq.updateImgurTokenFromClient)
  .get(sqlReq.getImgurTokenFromClient);

app.route('/api/imgur/posts/:accessToken')
  .get(getMyImgurPosts)
  .post(postImgurImage);

              /* ABOUT API */
app.route('/about.json')
  .get(about.getAbout);

const port = process.env.PORT || 8080;
app.listen(port);

console.log('App is listening on port ' + port);