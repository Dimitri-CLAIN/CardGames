const fetch = require('node-fetch');
const FormData = require('form-data');

exports.postImgurImage = function (request, response) {
    const { imageUrl, title, description } = request.body;
    const bearer = 'Bearer ' + request.params.accessToken;
    var formdata = new FormData();

    formdata.append("image", imageUrl);
    formdata.append("title", title);
    formdata.append("description", description);

    var requestOptions = {
        method: 'POST',
        headers: {
            'Authorization': bearer
        },
        body: formdata,
        redirect: 'follow'
    };

    fetch("https://api.imgur.com/3/image", requestOptions)
    .then(res => res.json())
    .then(resJson => {
        if (resJson.status === 200)
            response.status(200).json({code: 200, message: 'Successfully post', res: resJson});
        else
            response.status(resJson.data.status).json({code: resJson.data.status, message: resJson.data.error});
    })
    .catch(function (err) {
        console.error(err.message);
        response.status(400).json({code: 400, message: err.message});
    });
}

exports.getMyImgurPosts = function (request, response) {
    var requestOptions = {
        method: 'GET',
        headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json',
            'Authorization': "Bearer " + request.params.accessToken
        }
    };

    fetch("https://api.imgur.com/3/account/me/images", requestOptions)
    .then(res => res.json())
    .then(result => {
        if (result.status === 200) {
            response.status(200).json({code: 200, message: 'Successfully get my posts',res: result});
        }
    });
}