const fetch = require("node-fetch");

async function getYoutubeSearch(target, type) {
    const url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=' + target + '&key=AIzaSyAtfgOg774PILMOiVl43-W5t7IRaEm5e2A';
    var id = "-1";
    await fetch(url)
    .then(res => res.json())
    .then(
        res => {
            if (res.items.length != 0) {
                for (let n = 0; n < res.items.length; n++) {
                    if (type == "youtube#channel" && res.items[n].id.kind == "youtube#channel") {
                        id = res.items[n].id.channelId;
                        break
                    } else if (type == "youtube#video" && res.items[n].id.kind == "youtube#video") {
                        id = res.items[n].id.videoId;
                        break
                    }
                }
            }
        }
    );
    return id;
}

exports.getVideoStatistics = async function (request, response) {
    const videoName = request.params.videoName;
    getYoutubeSearch(videoName, "youtube#video").then(videoId => {
        const url = 'https://www.googleapis.com/youtube/v3/videos?part=statistics&id=' + videoId + '&key=AIzaSyAtfgOg774PILMOiVl43-W5t7IRaEm5e2A';//process.env.CLIENT_YOUTUBE_API_KEY
        fetch(url)
        .then(res => res.json())
        .then(
            res => {
                if (res.cod == '404')
                    response.status(404).json(res);
                else {
                    response.status(200).json(res);
                }
            }
        );
    });
}

exports.getVideoCommentThreads = function (request, response) {
    const videoName = request.params.videoName;
    getYoutubeSearch(videoName, "youtube#video").then(videoId => {
        const url = 'https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&videoId=' + videoId + '&key=AIzaSyAtfgOg774PILMOiVl43-W5t7IRaEm5e2A';

        fetch(url)
        .then(res => res.json())
        .then(
            (res) => {
                if (res.cod == '404')
                    response.status(404).json(res);
                else {
                    response.status(200).json(res);
                }
            }
        );
    });
}

exports.getYoutubeChannel = function (request, response) {
    const channelName = request.params.channelName;
    getYoutubeSearch(channelName, "youtube#channel").then(channelId => {
        const url = 'https://www.googleapis.com/youtube/v3/channels?part=snippet%2Cstatistics&id=' + channelId + '&key=AIzaSyAtfgOg774PILMOiVl43-W5t7IRaEm5e2A';

        fetch(url)
        .then(res => res.json())
        .then(
            (res) => {
                if (res.cod == '404')
                    response.status(404).json(res);
                else {
                    response.status(200).json(res);
                }
            }
        );
    });
}
