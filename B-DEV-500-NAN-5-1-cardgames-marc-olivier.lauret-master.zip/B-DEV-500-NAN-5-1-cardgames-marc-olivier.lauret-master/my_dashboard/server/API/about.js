const fetch = require("node-fetch");

exports.getAbout = function(request, response) {
    const aboutJson = {
        client: {"host": '127.0.0.1'},
        server: {
            current_time: '1531680780',
            services: [
                {
                    name: 'weather',
                    widgets: [
                        {
                            name: "weatherAPI",
                            description: "Display current weather for a city",
                            params: [
                                {
                                    name: "city",
                                    type: "string"
                                },
                                {
                                    name: "language",
                                    type: "string"
                                },
                                {
                                    name: "units",
                                    type: "string"
                                }
                            ]
                        }
                    ]
                },
                {
                    name: 'Youtube',
                    widgets: [
                        {
                            name: "YoutubeChannel",
                            description: "Display some information about a youtube channel",
                            params: [
                                {
                                    name: "ChannelName",
                                    type: "String"
                                }
                            ]
                        }
                    ]
                },
                {
                    name: 'Youtube',
                    widgets: [
                        {
                            name: "YoutubeVideo",
                            description: "Display some information about a youtube video",
                            params: [
                                {
                                    name: "VideoName",
                                    type: "String"
                                }
                            ]
                        }
                    ]
                },
                {
                    name: 'Imgur',
                    widgets: [
                        {
                            name: "MyImgurPosts",
                            description: "Display all my imgur posts",
                            params: [
                                {
                                    name: "Imugr connexion",
                                    type: "Button"
                                }
                            ]
                        },
                        {
                            name: "MakeImgurPost",
                            description: "Make a post in Imgur",
                            params: [
                                {
                                    name: "Imugr connexion",
                                    type: "Button"
                                },
                                {
                                    name: "Title",
                                    type: "String"
                                },
                                {
                                    name: "Description",
                                    type: "String"
                                },
                                {
                                    name: "Image url",
                                    type: "String"
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    };
    response.status(200).json(aboutJson);
}