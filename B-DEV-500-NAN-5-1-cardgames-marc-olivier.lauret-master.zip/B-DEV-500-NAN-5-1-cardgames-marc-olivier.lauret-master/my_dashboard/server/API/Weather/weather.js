const fetch = require("node-fetch");

exports.getWeather = function (request, response) {
    const city = request.params.city;
    const language = request.params.language;
    const units = request.params.units;

    var url = 'http://api.openweathermap.org/data/2.5/weather?q=' + city
            + '&lang=' + language
            + '&units=' + units
            + '&appid=' + '038b2f13636805c3d5418d923185bc58'/* process.env.WEATHER_API_CLIENT_KEY */; // TODO: Global var

    fetch(url)
        .then(res => res.json())
        .then((res) => {
            if (res.cod == '404')
                response.status(404).json(res);
            else
                response.status(200).json(res);
        });
}