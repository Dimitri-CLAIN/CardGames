# Dashboard

## Installation
You need to install docker compose -> https://github.com/Yelp/docker-compose/blob/master/docs/install.md
### `Start with Docker compose`
    ``` docker-compose up --build --force-recreate ```
### `Delete all dockers`
    ``` docker rm -f $(docker ps -a -q) ```
### `Delete the local database`
    ``` docker volume rm my_dashboard_db-data ```

## Services
### `Youtube`
    Widgets
        Call to youtube statisics api.

### `Weather`
    Widgets
        - Call to openweathermap api to get some information about the current weather.
            Took three parameters: city, language and units.
