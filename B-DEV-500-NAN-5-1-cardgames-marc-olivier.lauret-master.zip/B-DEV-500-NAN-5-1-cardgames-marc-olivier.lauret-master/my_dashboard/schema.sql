CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS weatherParams (
  id uuid DEFAULT uuid_generate_v4 (),
  city VARCHAR(100) NOT NULL,
  language VARCHAR(100) NOT NULL,
  units VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS ImgurParams (
  id uuid DEFAULT uuid_generate_v4 (),
  username VARCHAR(100) NOT NULL,
  password VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
  id uuid DEFAULT uuid_generate_v4 (),
  username VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(100) NOT NULL,
  weatherId uuid,
  imgurId uuid,
  videoName VARCHAR(250) NOT NULL,
  channelName VARCHAR(250) NOT NULL,
  imgurToken VARCHAR(200)
);
